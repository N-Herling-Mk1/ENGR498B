<!--
MY Name: Nathan Herling 
File name addQuote.php 
-
************************************
* Nathan Herling 
* CSC 337, Fall 2022
* The University of Arizona
* Week 13, HW 1 - also Week 13, HW 2. - Week 14, HW1 - Week 15, HW1. - Week 15, HW2.
************************************
* Project Data:
* [all files]: controller.php, DatabaseAdaptor.php, DatabaseAdaptorTest.php,
* [n=9      ]  styles.css, view.php, addQuote.php, login.php, logout.php, register.php.
************************************
Notes:
I had no idea you could add .html code to a .php page... in the beginning.. I do now!
This is a .php file ... with no .php code ... shocked face... :0
-->
<?php 
//Pg. 16 - the COOKIES and SESSIONS lecture: * We will put session_start() at the top of every .php file
session_start(); // <-- 
?>
<!DOCTYPE html>
<html>
<head>
<title>Quotation Service</title>
<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>

	<h1 style="margin-left:1%">
		<b>Add a Quote</b>
	</h1>

	<div id="reWriteDivOnAddQuotePage" class="outlineDivAddQuote">
	<!-- post calls the name attribute by its value -->
		<form action="controller.php" method="post">
			<br> <!-- the quote field  -->
			<textarea name="quote" placeholder="Enter new quote..." class="addQuoteTextField"  required></textarea>
			<br><br>
			<!-- the author field  --> 
			<input type="text"  name="author" placeholder="Author..." class="AddAuthorField" required></input>
			<br><br>    
			<!-- the submit button  -->
			<input type="submit" name="AddQuoteBtn" value="Add Quote"  class="AddQuoteBtn"></input>
			<br><br>
		</form>
	</div>


<script>
//Scripts doing script stuff...
</script>
	