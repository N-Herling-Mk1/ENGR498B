<!--
MY Name: Nathan Herling 
 -->
<?php
/* 
 * File Name: controller.php
 */
// This file contains a bridge between the view and the model and redirects
// back to the proper page with after processing whatever form this code
// absorbs (we'll learn that command later when we have several pages.
// This is the C in MVC, the Controller.
//
// Authors: Rick Mercer and Nathan Herling
//
/*
 * ***********************************
 * Nathan Herling
 * CSC 337, Fall 2022
 * The University of Arizona
 * Week 13, HW 1 - also Week 13, HW 2. - Week 14, HW1 - Week 15, HW1. - Week 15, HW2.
 * File: view.php
 * [all files]: controller.php, DatabaseAdaptor.php, DatabaseAdaptorTest.php,
 * [n=9 ] styles.css, view.php, addQuote.php, login.php, logout.php, register.php.
 * ***********************************
 * -
 * Notes:
 * I had no idea you could add html to a php file until now.
 * [x] -> i'm going to santize my inputs here and quite possibly in DatabaseAdapter.php (ha)
 *     ... it'll deinitely get done!
 */
session_start(); // <-- Need it now, boy-howdy.

require_once './DatabaseAdaptor.php';

$theDBA = new DatabaseAdaptor();

/*
 * --------------------------------------------- for debugging.
 *
 * echo "| Here is POST" . "<br>" . PHP_EOL;
 * print_r($_POST);
 * echo "<br>END - POST <br>";
 *
 * echo "| Here is GET" . "<br>" . PHP_EOL;
 * print_r($_GET);
 * echo "<br>END - GET <br>";
 */
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> This section is or handling all the $_POST[], $_SESSION[] checks >>>>>
// Selection based off of $_POST, $POST is attached to the name attribute
if (isset($_POST['ID'])) {
    /*
     * -------------------------------------- fir debugging
     * /* If you want this to work - you'll need to comment out: header("Location:view.php")
     */
    /*
     * echo "******************<br>";
     * echo "You headed to: getChangeRating() <br>";
     * echo "POST ID: ".$_POST['ID']."|POST VALUE: ".$_POST['Btn']."<br>";
     * echo "******************<br>";
     */
    // echo "<h1>You're here (1)</h1>";
    // print_r($_POST); //$_POST is global .. I don't need to pass it.
    getChangeRating($theDBA);
    header("Location:view.php");
}

// -- you hit the 'add quote button'
if (isset($_POST['AddQuoteBtn'])) {
    // echo "<h1>You're here (2)</h1>";
    // print_r($_POST); //$_POST is global .. I don't need to pass it.
    getAddQuote($theDBA); // I'm assuming we have freedom with this name.
    header("Location:view.php");
}

// -- you hit the 'register user button'
// -- error catch: if user and login name already exist, send them back to Register page.
if (isset($_POST['usrRegisterBtn'])) {
    // print_r($_POST); //$_POST is global .. I don't need to pass it.
    // Here is the contents of $_POST[]
    // [userNameRegisterFile] => Steve [userPWRegisterFile] => 123!
    
    $flag = true; // - get the current list of users iterate through it and check if the user name is already present
    for($i=0; $i<count($theDBA->getAllUsers());$i++){
        if($_POST['userNameRegisterFile']===$theDBA->getAllUsers()[$i]['username']){
            //echo "Found: ".$_POST['userNameRegisterFile']." Pick again <br>";
            $flag=false;
            break;
        }
    }
    //echo print_r($theDBA->getAllUsers());
    //The condition for a new register: not in the credintials database and not in the current user names.
    //Adding htmlspecialchars(..)
    if (!$theDBA->verifyCredentials(htmlspecialchars($_POST['userNameRegisterFile']), 
                                    htmlspecialchars($_POST['userPWRegisterFile'])) And $flag ) {

        $theDBA->addUser(htmlspecialchars($_POST['userNameRegisterFile'])       //add htmlspecialchars(..)
            , htmlspecialchars($_POST['userPWRegisterFile']));
        header("Location:view.php"); // <-- ok, so commenting this out/in is really helpful to check the contents of the $_POST[]
    } else {
        //Go bak to the register page.
        $_SESSION['inValidRegister']='yes';
        header("Location:register.php"); // <-- ok, so commenting this out/in is really helpful to check the contents of the $_POST[]
        
    }
}//end_if_block

// -- you hit the 'log in button'
// -- error catch: if invalid user info., send them back to Login page.
if (isset($_POST['usrLogInBtn'])) {
    print_r($_POST); // $_POST is global .. I don't need to pass it.
                     // Here is the contents of $_POST[]
                     // [userNameLogInFile] => RicoSuave [userPWLogInFile] => 123! [usrLogInBtn] => Login
    echo "Value of credintial check: " . $theDBA->verifyCredentials(htmlspecialchars($_POST['userNameLogInFile'])
                                                                   , htmlspecialchars($_POST['userPWLogInFile'])) . "<br>";
    //add htmlspecialchars(..)
    if ($theDBA->verifyCredentials(htmlspecialchars($_POST['userNameLogInFile']),
                                   htmlspecialchars($_POST['userPWLogInFile']))) {
        $_SESSION['user'] = $_POST['userNameLogInFile'];
        // echo "You are in TRUE<br>";
        //Go to the view
        header("Location:view.php"); // <-- ok, so commenting this out/in is really helpful to check the contents of the $_POST[]
                                     // echo "<p>User name set: ".$_SESSION['user']."<br>"; //ok, this worked.
                                     // $theDBA->addUser($_POST['userNameRegisterFile'], $_POST['userPWRegisterFile']);
    } else {
        // echo "You are in FALSE<br>";
        //Go to back to the login page.
        $_SESSION['inValidUserAndOrPW']='yes';
        header("Location:login.php"); // <-- ok, so commenting this out/in is really helpful to check the contents of the $_POST[]
    }
}//end_if_block

// Selection based off of $_GET[] .. this is sent via AJAX call in view.php <script> .. </script>
if (isset($_GET['todo']) && $_GET['todo'] === 'getQuotes') {
    $arr = $theDBA->getAllQuotations(); // Here the $arr gets all the quotes.
    unset($_GET['todo']);

    echo getQuotesAsHTML($arr);
}//end_if_block
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> end global array check area >>>>>>>>>>>>>>>>>>>>>>
//>>>>>>>>>>>>>>>>
/*
 * This is apparently the wrong starter code as we need:
 * <form action="controller.php" method="post">'
 * <input type="hidden" name="ID" value="'.$quote["id"].'"</input>'
 */

/*
 * getQuotesAsHTML
 * params: $arr [the associative array for the quotations database]
 * returns: an echo'd html string
 * -
 * Synopsis:
 *
 */
function getQuotesAsHTML($arr)
{
    // TODO 6: Many things. You should have at least two quotes in table quotes.
    // Layout each quote using a combo of PHP code and HTML strings that includes
    // HTML for buttons along with the actual quote and the author, ~15 PHP statements.
    // You will need to add css rules to styles.css.
    // https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_button_form
    $result = '';

    // ------------------------------------------------------------------------
    foreach ($arr as $quote) {
        /*
         * ---- ALL of this works ----
         * ------------------------------------------------------------------------------------------------------- debugging
         * $temp = $quote['id'];
         * $temp = strval($temp);
         * echo $quote['quote']."|".$quote['id']."|".$quote['rating']."<br>";
         * echo $theDBA->justProveHere($quote['id']);
         * echo "Lower 1 <br>";
         * $theDBA->lowerRating($quote['id']); //I don't get the 'array to string conversion error' if I do this.
         * --------------------------------------------------------------------------------------------------------
         */
        // echo "<br>";

        // echo $quote['quote']."|".$quote['id']."|".$quote['rating']."<br>"; //--- you guessed it: debuggging

        $result .= '<div class="container" >';
        $result .= '"' . $quote['quote'] . '"<br><br>';
        $result .= '<span class="quoteTxtSpan">--' . $quote['author'] . '</span><br><br>';

        // --- here is the container for the form.
        // I think I'm putting things in a form.
        $result .= '<form action="controller.php" method="post" class="formBox" id="formDiv">' . '<input type="hidden" name="ID" value="' . $quote['id'] . '">';

        // --- here is the [+] button on the left. $theDBA->raiseRating
        $result .= '<input type="submit" name="Btn" value="+" class="voteBtnLeft"></input>' . PHP_EOL;
        // --- here is the current rating.
        $result .= $quote['rating'] . PHP_EOL;
        // --- here is the [-] button on the right.
        $result .= '<input type="submit" name="Btn" value="-" class="voteBtnRight"></input>' . PHP_EOL;
        // --- here is the [delete] button.
        // --- this needs to be modified to account for the [delete] only being visibile if someone is
        // --- registered and logged in.
        if (isset($_SESSION['user'])) {
            $result .= '<input type="submit" name="Btn" value="Delete"  class="delBtn"></input>' . PHP_EOL;
        }

        $result .= '</form>';
        $result .= '</div>' . PHP_EOL; // end container

        // Add more code below. You will need to hold the buttons in an HTML <form>
        // This is kind of like adding onclick in Best Reads Two
    } // end_foreach_loop
    return $result;
}

// end_method

/*
 * getChangeRating()
 * params: $theDBA
 * returns: none
 * -
 * Synopsis:
 * This is supposed to update depending on: rating and +/-
 * OK, so reads $_POST['Btn'] to make the decision about what to do: +/- and next 'delete'
 * 'delete' isn't next .. it's HERE!!! [11/22/22]
 * -
 * Week 15 - hw 2 htmlspecialchars(..) adding it here..
 */
function getChangeRating($theDBA)
{
    /*
     * echo "******************<br>";
     * echo "You headed to: getChangeRating() <br>";
     * echo "| POST ID: ".$_POST['ID']."|POST VALUE: ".$_POST['Btn']."<br>";
     * echo "******************<br>";
     */
    switch ($_POST['Btn']) {
        case "-": // minus button hit
            $theDBA->lowerRating(htmlspecialchars($_POST['ID']));
            break;
        case "+": // plus button hit
            $theDBA->raiseRating(htmlspecialchars($_POST['ID']));
            break;
        case "Delete": // delete button hit
            $theDBA->getRemoveQuote(htmlspecialchars($_POST['ID']));
            break;
        default:
            echo "Problem in getChangeRating()| value received: " . $_POST['Btn'] . "<br>";
            break;
    } // end_switch
}

// end_method

/*
 * getAddQuote($theDBA)
 * params: $theDBA
 * returns: none
 * -
 * Synopsis: alers the database: 'quotations' by adding a new author/quote.
 * NOTE: author and quote will be in the global $_POST[] array.
 * Their names are: [quote] => "Howard Roark laughed.." [author]=> "Ayn Rand"
 * Calls: addQuote($quote, $author) from DatabaseAdaptor.php
 * Note:
 * Week 15 - hw2.
 * I'm not sure if I should add the htmlspecialchars here or in the method.
 */
function getAddQuote($theDBA)
{
    $theDBA->addQuote(htmlspecialchars($_POST['quote']), htmlspecialchars($_POST['author']));
} // end_method

?>