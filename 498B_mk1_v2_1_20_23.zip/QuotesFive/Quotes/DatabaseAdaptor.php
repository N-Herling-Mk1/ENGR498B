<!--
MY Name: Nathan Herling 
 -->
<?php
/*
 * File Name: DatabaseAdaptor.php
 * 
 */
// This class has a constructor to connect to a database. The given
// code assumes you have created a database named 'quotes' inside MariaDB.
//
// Call function startByScratch() to drop quotes if it exists and then create
// a new database named quotes and add the two tables (design done for you).
// The function startByScratch() is only used for testing code at the bottom.
// 
// Authors: Rick Mercer and Nathan Herling
//
/*
************************************
* Nathan Herling 
* CSC 337, Fall 2022
* The University of Arizona
* Week 13, HW 1 - also Week 13, HW 2. - Week 14, HW1 - Week 15, HW1. - Week 15, HW2.
************************************
* Project Data:
* [all files]: controller.php, DatabaseAdaptor.php, DatabaseAdaptorTest.php,
* [n=9      ]  styles.css, view.php, addQuote.php, login.php, logout.php, register.php.
************************************
Notes:
I had no idea you could add .html code to a .php page... in the beginning.. I do now!
Notes (W15-HW2):
[things added]
[x] htmlspecialchars($str)
[x] bindParam  https://www.php.net/manual/en/pdostatement.bindparam.php
[x] if user pw is involved use a hash function: password_hash(), and password_verify() to decode/match.
 */
class DatabaseAdaptor {
  private $DB; // The instance variable used in every method below
  // Connect to an existing data based named 'quotes'
  public function __construct() {
    $dataBase ='mysql:dbname=quotes;charset=utf8;host=127.0.0.1';       //<--- name has already been changed.
    $user ='root';                                                      //when the DB doesn't exist - you get
    $password =''; // Empty string with XAMPP install                   //via CLI
    try {                                                               //Error establishing Connection
        $this->DB = new PDO ( $dataBase, $user, $password );
        $this->DB->setAttribute ( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
    } catch ( PDOException $e ) {
        echo ('Error establishing Connection');
        exit ();
    }
  }
    
// This function exists only for testing purposes. Do not call it any other time.
//********************************
// The function Rick gave us [well, method, I think...]
//********************************
public function startFromScratch() {
  $stmt = $this->DB->prepare("DROP DATABASE IF EXISTS quotes;");        //Drop quotes
  $stmt->execute();
       
  // This will fail unless you created database quotes inside MariaDB.
  $stmt = $this->DB->prepare("create database quotes;");                //re-create quotes
  $stmt->execute();

  $stmt = $this->DB->prepare("use quotes;");                            //switch to quotes
  $stmt->execute();
        
  //Creates the Table 'quotations'
  //with the fields: id, datetime, quote, author, rating, flagged.
  $update = " CREATE TABLE quotations ( " .
            " id int(20) NOT NULL AUTO_INCREMENT, added datetime, quote varchar(2000), " .
            " author varchar(100), rating int(11), flagged tinyint(1), PRIMARY KEY (id));";       
  $stmt = $this->DB->prepare($update);
  $stmt->execute();
                
  //Creates the Table 'users'
  //with the fields: id, username, password 
  $update = "CREATE TABLE users ( ". 
            "id int(6) unsigned AUTO_INCREMENT, username varchar(64),
            password varchar(255), PRIMARY KEY (id) );";    
  $stmt = $this->DB->prepare($update);
  $stmt->execute();
  
}//end_function
    

// ^^^^^^^ Keep all code above for testing  ^^^^^^^^^


/////////////////////////////////////////////////////////////
// Complete these five 'straightfoward' functions and run as a CLI application
// ... as we settle into the 'straightforward' vector Calculus component of the course
// [ha] ...

    /*--------------------------------------------------------- (1/5)
     * getAllQuotations()
     * params: NONE
     * returns: DB query
     * -
     * Synopsis:
     * In the DB 'quotes' - the table 'quotations' - return? idk.
     * This needs a better explanation.  I'll go check the assert statement.
     * OK, addQuote(..,..) is called first and creates things in the
     * quotation table.
     * From problem spec
     * Return a PHP array of all columns in the table quotations
     * ----
     * Week 13 - day 2 modification
     * Put them is descending order by rating.
     * Week 15 - no input chars, no use for (W15-HW2): htmlspecialchars($str)
     * Week 15 - no input param, no bindParam(..)
     */
    public function getAllQuotations() {
        //Does this work in CLI mode? --- yes!
        //echo "You are in: getAllQuotations()\n";                    //---- debugging
        //Construct the SQL command.
        $searchString="SELECT * FROM quotations ";
        $searchString.="ORDER BY rating DESC;";                       //--- add command to order by descending.
        //echo "Here is the command we made:".$searchString."\n";     //---- debugging
        //(1)
        $stmt = $this->DB->prepare($searchString);
        //(2)
        $stmt->execute();
        //(3)
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }//end_function
    
    /*--------------------------------------------------------- (2/5)
     * getAllUsers()
     * params: none
     * returns: DB query
     * -
     * Synopsis:
     * In DataBaseAdaptorTest.php, users are added before this is called.
     * Should return associative array with [user name] and [id]
     * From problem spec
     * Return a PHP array of all columns in table users
     * Week 15 - no string input no need for: htmlspecialchars($str)
     * Week 15 - Week 15 - no input param, no bindParam(..)
     */
    public function getAllUsers(){
        //Does this work in CLI mode? --- yes!
        //echo "You are in: getAllUsers()\n";                           //---- debugging
        //Construct the SQL command.
        $searchString="SELECT * FROM users";
        //echo "Here is the command we made:".$searchString."\n";       //---- debugging
        //(1)
        $stmt = $this->DB->prepare($searchString);
        //(2)
        $stmt->execute();
        //(3)
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }//end_function
    
    /*--------------------------------------------------------- (3/5)
     * addQuote($quote, $author)
     * params: $quote, $author
     * returns: DB query
     * -
     * Synopsis:
     * looks like this: $theDBA->addQuote('one', 'A');
     * From problem spec
     * (1) Insert string $quote to the quotations table with the string 
     *     $author to be the author of the quote. Set rating and flagged 
     *     to default values of 0. The time it field is set to the value now().
     * (2) Do not INSERT anything into the ID column. The first column name after 
     *     INSERT must be added.  The first VALUE should be now(). With auto-increment 
     *     turned on, MariaDB will add the next available unique integer ID automatically. 
     * <<<NOTE:> I discovered that any string entered with an apostrophe ' causes an error>>> [11/22/22]
     * Week 15 - notes
     * htmlspecialchars($str) - since I'm binding to the parameter, I think I need to input the already modified parameter.
     * prepare+bindParam() https://www.php.net/manual/en/pdostatement.bindparam.php (works)
     */
    public function addQuote($quote, $author) {
        //$quote = htmlspecialchars($quote);                                  //---week 15, HW2 requirement - do this at method call to make myself feel better
        //$author = htmlspecialchars($author);                                //---week 15, HW2 requirement -
        //Does this work in CLI mode? --- yes!
        //echo "You are in: addQuote(..,..)\n";                            //---- debugging
        ///echo "You entered:|Quote|".$quote."|Author|".$author."\n";      //---- debugging
        //Construct the SQL command.
        $searchString="INSERT INTO quotations (added, quote, author, rating, flagged) ".
            "VALUES (NOW(),:quote_,:author_,0, 0)";
        echo "Here is the command we made:".$searchString."\n";           //---- debugging
        //strval($quote)
        //strval($author)
        //(1)
        $stmt = $this->DB->prepare($searchString);
        //(1b)
        $stmt->bindParam(':quote_',$quote);
        $stmt->bindParam(':author_',$author);
        //(2)
        $stmt->execute();
        //(3)
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }//end_function

    /*--------------------------------------------------------- (4/5)
     * addUser($accountname, $psw)
     * params: $accountname, $psw
     * returns: DB query
     * -
     * Synopsis:
     * looks like it adds user,pw
     * $theDBA->addUser("Sammi", "1234");
     * From problem spec
     * Insert a new user to table users. You will need to examine the INSERT in 
     * - function startFromScratch() of DataBaseAdaptor
     * -- note:
     * https://www.w3schools.com/sql/sql_autoincrement.asp
     * Week 15, hw 2
     * (1) htmlspecialchars($str) - I'm doing this where there's a method call - not here since I'm guessing
     *                          'parameter bind' means I'm referencing the original parameters.
     * (2) prepare+bindParam() https://www.php.net/manual/en/pdostatement.bindparam.php [works]
     * (3) salt/hash pw: https://www.php.net/manual/en/function.password-hash.php    
     */
    public function addUser($accountname, $psw){
        //$accountname = htmlspecialchars($accountname);                  //---week 15, HW2 requirement
        //$psw = htmlspecialchars($psw);                                  //---week 15, HW2 requirement
        //Does this work in CLI mode? --- yes!
        echo "You are in: addUser(..,..)\n";                          //---- debugging
        echo "You entered: |".$accountname."|".$psw."\n";             //---- debugging
        //Construct the SQL command.
        //$psw = password_hash($psw,PASSWORD_DEFAULT);                    //<<----------------HASH
        $hash = password_hash(htmlspecialchars($psw), PASSWORD_DEFAULT);        //I'm paranoid, atm, re: htmlspecialchars(..)
        echo "Here is the hashed pw: ".$hash."\n";
        $searchString="INSERT INTO users (username, password)".
                      "VALUES (:accountname_,:hash_)";
        //echo "Here is the command we made:".$searchString."\n";   //---- debugging
        //(1)
        $stmt = $this->DB->prepare($searchString);
        //(1b)
        $stmt->bindParam(':accountname_',$accountname);
        $stmt->bindParam(':hash_',$hash);                           //store the hashed pw.                        
        //(2)
        $stmt->execute();
        //(3)
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }//end_function


    /*--------------------------------------------------------- (5/5)
     * verifyCredentials($accountName, $psw)
     * params: $accountName, $psw
     * returns: DB query
     * -
     * Synopsis:
     * Users and their passwords are added first in the DataBaseAdaptorTest.php file
     * Once added, we can call This method. ..
     * From problem spec
     * return true if the given string $accountName's password matches the given string $psw, 
     * - false if there no match or the user does not exist in table users
     * ******************************
     * Example print off of the associative array.
     * Array
    (
    [0] => Array
        (
            [id] => 1
            [username] => Sammi
            [password] => 1234
        )
    [1] => Array
        (
            [id] => 2
            [username] => Chris
            [password] => abcd
        )
    [2] => Array
        (
            [id] => 3
            [username] => Gabriel
            [password] => abc123
        )
        )
     * Week 15 - hw2
     * htmlspecialchars($str) - I'm doing this where there's a method call - not here since I'm guessing
     *                          'parameter bind' means I'm referencing the original parameters.     
     * (1) bindParam() https://www.php.net/manual/en/pdostatement.bindparam.php
     * (2)prepare+bindParam() https://www.php.net/manual/en/pdostatement.bindparam.php - not needed here as params not used in db call.
     * (3) Get the incoming pw, get the hash value.
     *  - find the account name's hashed pw.
     *  - compare the two (incoming,stored) - both hash values, to determine if accountName matches pw.     
     */
    public function verifyCredentials($accountName, $psw){
        echo "Input: ".$accountName."|".$psw."\n";
        
        //$accountName = htmlspecialchars($accountName);              //---week 15, HW2 requirement
        //$psw = htmlspecialchars($psw);                              //---week 15, HW2 requirement
        //Does this work in CLI mode? --- yes!
        //echo "You are in: verifyCredentials(..,..)\n";            //---- debugging
        //echo "You entered: |".$accountName."|".$psw."\n";
        //Get the associative array from the command to get all rows in users.
        $searchString="SELECT * FROM users";
        //echo  "Here is the command we made:".$searchString."\n";  //---- debugging
        //(1)
        $stmt = $this->DB->prepare($searchString);
        //(2)
        $stmt->execute();
        //(3)
        $array = $stmt->fetchAll(PDO::FETCH_ASSOC);
        //echo "Here is the table contents:\n";                     //---- debugging
        //echo print_r($array);
        
        //I need the actual (hashed) pw from the user...
        for($i=0;$i<count($array);$i++){
            if($array[$i]['username']===strval($accountName)){
                $hashed_USR_PW = $array[$i]['password'];
                break;
            }
        }
        //check the incoming pw vs. the hashed_USR_PW
        $locVerify = password_verify(htmlspecialchars($psw), $hashed_USR_PW);            //Test if hashes to pw
        //I need to get the user's pw...
        echo "rev-Hash: ".$locVerify."\n";
        
        //Both conditions have to be true.
        for($i=0;$i<count($array);$i++){
            //if($array[$i]['username']===strval($accountName) AND $array[$i]['password']===strval($psw)){//previous design.
            if($array[$i]['username']===strval($accountName) AND $locVerify){   //new design.
                return true;
            }
        }
        
        return false;
    }//end_function

    
    //   .........................................................................
    //   ........ Week 13 - day 2 Modification + a HAT Week 15 - day 2............  
    //   .........................................................................
    //                        ____
    //                        |  |
    //                        |**|
    //                       ------
    //    ||                  -  -
    //    ||                  0  0
    //  ------                  O
    //  \    /                \_|_/
    //   \  /                   |
    //    \/                  _/ \_

    /* ------------------------------------------- addition (1/2)
     * raiseRating()
     * params: ID [id of the rating from 'quotations' database you want to raise.
     * returns: DB querry.
     * -
     * input an id from the database, will increment the rating by 1 
     * .. updating it in the database..
     * >> SAME 3 steps of DB update >>
     * Week 15, hw 2.
     * (1) htmlspecialchars($str) - done in controller.
     * (2) bindParam() https://www.php.net/manual/en/pdostatement.bindparam.php [works]
     * (3) no pw, no hash
     */
    public function raiseRating($ID){
        //$ID = htmlspecialchars($ID);                                    //---week 15, HW2 requirement
        echo "You've made it to: raiseRating() ID=".$ID."\n";
        $dbCommand="";
        $dbCommand.="UPDATE quotations ".
                      "SET rating=rating+1 ". 
                      "WHERE id=:ID_";
        echo "Here is the command [raise] we made:".$dbCommand."\n";   //---- debugging
        //(1)
        $stmt = $this->DB->prepare($dbCommand);
        //(1b)
        $stmt->bindParam(':ID_',$ID);
        //(2)
        $stmt->execute();
        //(3)
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    }//end_function

    /* ------------------------------------------- addition (2/2)
     * lowerRating()
     * params: ID [id of the rating from 'quotations' database you want to lower.
     * returns: DB querry.
     * -
     * input an id from the database, will decrement the rating by 1 
     * .. updating it in the database..
     * >> SAME 3 steps of DB update >>
     * Week 15, hw 2.
     * (1) htmlspecialchars($str) -- done in controller
     * (2) bindParam() https://www.php.net/manual/en/pdostatement.bindparam.php [works]
     * (3) no pw, no hash
     */
    public function lowerRating($ID){
        //$ID=htmlspecialchars($ID);                                      //---week 15, HW2 requirement
        echo "You've made it to: lowerRating() ID=".$ID."\n";
        $dbCommand="";
        $dbCommand.="UPDATE quotations ".
                    "SET rating=rating-1 ".
                    "WHERE id=:ID_";
        echo "Here is the command [lower] we made:".$dbCommand."\n";   //---- debugging
        //(1)
        $stmt = $this->DB->prepare($dbCommand);
        //(1b)
        $stmt->bindParam(':ID_',$ID);
        //(2)
        $stmt->execute();
        //(3)
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    }//end_function
    
    /*
     * justProveHere($ID)
     * params: user ID
     * returns: nothing
     * -
     * Synopsis: just echos that you arrived here and were able to pass the $ID.
     * Week 15, hw 2.
     * (1) htmlspecialchars($str) -- no need to do anything; but done here.     
     * (2) bindParam() https://www.php.net/manual/en/pdostatement.bindparam.php [we're good]
     * (3) no pw, no hash            
     */
    public function justProveHere($ID){
        $ID=htmlspecialchars($ID);
        echo "You're in justProveHere() Here is the ID: ".$ID;      //---week 15, HW2 requirement; why not?
        echo "<br>";
    }//end_method
    
    
 ////>>>>>>>>>>>>>> QUOTES 3 >>>>>>>>>>>>>>//
 
    /*
     * getRemoveQuote($ID)
     * params:
     * returns: DB query [action of removal]
     * -
     * SYNOPSIS:
     * input the ID of the author whose quote you want to remove.
     * only operates on the database: quotations
     * Week 15, hw 2.
     * htmlspecialchars($str) -- done in controller.
     * bindParam() https://www.php.net/manual/en/pdostatement.bindparam.php [works]
     * 
     */
    public function getRemoveQuote($ID){
        //$ID = htmlspecialchars($ID);                                        //---week 15, HW2 requirement
        //echo "You've made it to: getRemoveQuote($ID) ID=".$ID."<br>";
        $dbCommand="";
        $dbCommand.="DELETE FROM quotations ".
                    "WHERE id=:ID_";
        //echo "Here is the command [lower] we made:".$dbCommand."\n";   //---- debugging
        //(1)
        $stmt = $this->DB->prepare($dbCommand);
        //(1b)
        $stmt->bindParam(':ID_',$ID);
        //(2)
        $stmt->execute();
        //(3)
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    }//end_method
    
}//End_class_DatabaseAdaptor


?>
