<!-- 
My Name: Nathan Herling
File name logout.php 
-
************************************
* Nathan Herling 
* CSC 337, Fall 2022
* The University of Arizona
* Week 13, HW 1 - also Week 13, HW 2. - Week 14, HW1 - Week 15, HW1. - Week 15, HW2.
************************************
* Project Data:
* [all files]: controller.php, DatabaseAdaptor.php, DatabaseAdaptorTest.php,
* [n=9      ]  styles.css, view.php, addQuote.php, login.php, logout.php, register.php.
************************************
Notes:
I had no idea you could add .html code to a .php page... in the beginning.. I do now!
-->
<?php
//Pg. 16 - the COOKIES and SESSIONS lecture: * We will put session_start() at the top of every .php file
session_start(); // <-- 
//I think this is all I need to log a user out.
unset($_SESSION['user']);
header("Location:view.php");
?>