<!-- 
MY Name: Nathan Herling
File name view.php 
-
This is the home page for Final Project, Quotation Service. 
It is a PHP file because later on you will add PHP code to this file.
    
Authors: Rick Mercer and Nathan Herling

************************************
* Nathan Herling 
* CSC 337, Fall 2022
* The University of Arizona
* Week 13, HW 1 - also Week 13, HW 2. - Week 14, HW1 - Week 15, HW1. - Week 15, HW2.
* File: view.php
* [all files]: controller.php, DatabaseAdaptor.php, DatabaseAdaptorTest.php,
* [n=9      ]  styles.css, view.php, addQuote.php, login.php, logout.php, register.php.
************************************
-
Notes:
I had no idea you could add html to a php file until now.
-
Notes (W15-HW1):
The view top banner will now have two states:
(1) 3 buttons, [Register][Login][Add Quote], for when the user IS NOT logged in.
(2) 4 buttons, [Register][Login][Add Quote][Logout], for when the user IS logged in.
The individual qutoe panels will now have two states:
(1) [+]score[-], for when the user IS NOT logged in.
(2) [+]score[-][Delete], for when the user IS logged in.
Notes (W15-HW2):
[things added]
[x] htmlspecialchars($str)

-->

<!DOCTYPE html>
<html>
<head>
<title>Quotation Service</title>
<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body onload="showQuotes()">

<h1><b>Quotations</b></h1>
<?php 
session_start();

//Some sort of 'if' condition to disply differences when logged in -add [logout]
if( isset($_SESSION['user'])){
    echo '&nbsp; <a href="./register.php" ><button class="topOfPageBtn2">Register</button></a>';
    echo '&nbsp; <a href="./login.php" ><button class="topOfPageBtn2">Login</button></a>';
    echo '&nbsp; <a href="./addQuote.php" ><button class="topOfPageBtn2">Add Quote</button></a>';
    echo '&nbsp; <a href="./logout.php" ><button class="topOfPageBtn2">Logout</button></a>';
    echo "<br><br><h2>Hello <span style='font-style: oblique'>".$_SESSION['user']."</span></h2><br>";
}else{
    echo '&nbsp; <a href="https://gesundme.com/" ><button class="topOfPageBtn">Register</button></a>';
    echo '&nbsp; <a href="./login.php" ><button class="topOfPageBtn">Login</button></a>';
    echo '&nbsp; <a href="./addQuote.php" ><button class="topOfPageBtn">Add Quote</button></a>';
}


?>
<div id="quotes">
<!-- ..Here is where 'the stuff' will be printed.. -->
</div>



<script>
var element = document.getElementById("quotes");

/*
* showQuotes()
* params: none
* returns: none
* -
* Need an AJAX call here to the controller.php
* controller has this method: getQuotesAsHTML($arr)
*/
//*******************************************
    // TODO 6: Due Sunday 20-Nov
    // Complete this function using an AJAX call to controller.php
  	// You will need query parameter "?todo=getQuotes" in the open message.
  	// Echo back one big string to here that has all styled quotations.
  	// Write all of the complex code to layout the array of quotes 
  	// inside function getQuotesAsHTML inside controller.php
//*******************************************
function showQuotes() {
	//alert('view.php under construction');
		let ajax = new XMLHttpRequest();
		// Arguments: method (GET) and url with query param(s)
		ajax.open("GET", "controller.php?todo="+"getQuotes");	//hey, look.  We ARE using GET ?checkBox=" + checkBox

		ajax.send();
		let retStr = "";
		// This high order anonymous function will execute when the server responds (a callback)
		ajax.onreadystatechange = function() {
			//for information purposes:
			console.log("State: " + ajax.readyState);
			if (ajax.readyState == 4 && ajax.status == 200) {
				//This is how we turn a JSON array into a JS array.

				retStr = ajax.responseText;
				console.log("Here is the inner HTML**: " + retStr);

				element.innerHTML = retStr;

			} else {
				//At the moment, I have no way to test this.
				//I'm assuming \n characters will function as desired and strings work like this...
				//Below does work, but it throws alerts unnecessarily atm.
				//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
			}
		}; // End anonymous high order function

} // End function showQuotes


</script>

</body>
</html>