<!-- 
MY Name: Nathan Herling
File name register.php 
-
************************************
* Nathan Herling 
* CSC 337, Fall 2022
* The University of Arizona
* Week 13, HW 1 - also Week 13, HW 2. - Week 14, HW1 - Week 15, HW1. - Week 15, HW2.
************************************
* Project Data:
* [all files]: controller.php, DatabaseAdaptor.php, DatabaseAdaptorTest.php,
* [n=9      ]  styles.css, view.php, addQuote.php, login.php, logout.php, register.php.
************************************
Notes:
I had no idea you could add .html code to a .php page... in the beginning.. I do now!
-->
<?php 
//Pg. 16 - the COOKIES and SESSIONS lecture: * We will put session_start() at the top of every .php file
session_start(); // <-- 
?>
<!DOCTYPE html>
<html>
<head>
<title>Quotation Service</title>
<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<!-- made this <h3> due to the rubric -->
	<h3 style="margin-left:1%">
		<b>Register</b>
	</h3>

	<div id="reWriteDivOnRegisterPage" class="outlineDivReg_Login_pgs">
	<!-- post calls the name attribute by its value -->
	<!-- posts to the controller, via the names I give them -->
		<form action="controller.php" method="post">
			<br> <!-- username field  -->
			<input type="text" name="userNameRegisterFile" placeholder="Username" class="registerInputField" required></input>
			<br><br><br>
			<!-- password field  --> 
			<input type="password"  name="userPWRegisterFile" placeholder="Password" class="registerInputField" required></input>
			<br><br><br>    
			<!-- the submit button  value='what you want the button to say' -->
			<input type="submit" name="usrRegisterBtn" value="Register"  class="regiserBtn"></input>
			<br><br><br>
			<?php 
			if(isset($_SESSION['inValidRegister'])){
			    //echo print_r($_SESSION);
			     echo "<h3>User name taken</h3>";
			     unset($_SESSION['inValidRegister']);
			     //echo print_r($_SESSION);
			}
			?>
		</form>
	</div>


<script>
//Scripts doing script stuff...
</script>
	