<?php
/*
 * File: ErrorThrowClass.php
 * -
 * Throw errors via text file output.
 * 
 */

class ErrorThrowClass{
    
    /*
     * getThrowErrorAsTxtFile($errorMessage,$fileName)
     * params: message you want displayed, name of the file you intend to write to
     * -
     * Synopsis:
     * put in params, recommending error files start with letter 'z'
     * 
     */
    function getThrowErrorAsTxtFile($errorMessage,$fileName){
        $myfile = fopen($fileName, "w") or die(">>Unable to open file! ".$fileName);
        fwrite($myfile, $errorMessage);
        fclose($myfile);
        
    }//end_method
    
}//end_class
?>