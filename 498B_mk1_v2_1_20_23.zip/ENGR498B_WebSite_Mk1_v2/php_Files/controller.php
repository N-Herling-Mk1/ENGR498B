
<?php

/* >>>>>>>>>>>>>>>>>>>>>
 * >>>>>>>>>>>>>>>>>>>>>>>>
 * UNDER CONSTRUCTION ...
 * >>>>>>>>>>>>>>>>>>>>>>>>
 * >>>>>>>>>>>>>>>>>>>>>>>>>>>
 */
// This file contains a bridge between the view and the model and redirects
// back to the proper page with after processing whatever form this code
// absorbs (we'll learn that command later when we have several pages.
// This is the C in MVC, the Controller.
//
/*
 * ENGR498B
 * Nathan Herling
 * The University of Arizona Spring 2023
 * ***********************************
 *  
 * -
 * Notes:
 * Adapted from: final project CSC 337
 * I had no idea you could add html to a php file until now.
 * [x] -> i'm going to santize my inputs here and quite possibly in DatabaseAdapter.php (ha)
 *     ... it'll deinitely get done!
 */
session_start(); // <-- Need it now, boy-howdy.

/*
 The require_once keyword is used to embed PHP code from another file.
 If the file is not found, a fatal error is thrown and the program stops.
 If the file was already included previously, this statement will not include it again.
 */
require_once './DatabaseAdaptor.php';
require_once './questionLoadClass.php';
require_once './questionSmartClass.php';

$theDBA = new DatabaseAdaptor();
$smartClassObject = new questionSmartClass();
// print_r($_GET);
// if(isset($_GET['qMemory'])){
//     echo "<br> Setting memory file <br>";
//     getSetMemoryFile();
//     unset($_GET['qMemory']);
// }
// Selection based off of $_GET[] .. this is sent via AJAX call in view.php <script> .. </script>
// These are for the buttons [last] [submit] [prev]
if (isset($_GET['todo'])){
    //$arr = $theDBA->getAllQuotations(); // Here the $arr gets all the quotes.
    //$retStr = "";
    //$retStr = $_GET['todo'];
    
    switch($_GET['todo']){
        case "first":
            //initialize the questionnaire.
            //$theDBA->getPopulateDB();
            //get the first question.
            //$questionLoadClass->currentQuestion();
            echo "<div>First up!</div>";
            getInitializsmartClassObject($smartClassObject);//getInitializeIntelliFiles()
            echo getCurrentQuestion($theDBA,$smartClassObject);
            break;
        case "getPrevQuestion_Btn":
            echo "<div>[Prev]</div>";
            get_decrement_QuestionNumber($theDBA);
            echo getCurrentQuestion($theDBA,$smartClassObject);
            break;
        case "getNextQuestion_Btn":
            //$questionLoadClass->get_increment_QuestionNumber();
            echo "<div>[Next]</div>";
            get_increment_QuestionNumber($theDBA);
            echo getCurrentQuestion($theDBA,$smartClassObject);
            break;
        case "submit_Btn":
            echo "<div>[Submit]</div>";
            //getCurrentQuestion($theDBA);
            break;
        default:
            //I know I can make it here under correct conditions.
            echo"<div>Setting memory file</div>";
            getSetMemoryFile($theDBA,$smartClassObject,$_GET['todo']);
            //header("Location:quizView.php");
            //echo getCurrentQuestion($theDBA,$smartClassObject);
    }
    unset($_GET['todo']);
}//end_if_block


if (isset($_GET ['checkBoxArray'])) {
    //$retStr="You are >here>";
    $questionArray = json_decode($_GET ['checkBoxArray']);
    foreach($questionArray as $element) {
        $tempArr=explode(":",$element);
        if($tempArr[1]==='true'){    //if true, call method to create that database.
            //echo "Checkd true\n";
            $theDBA->getCreateDB($tempArr[0]);
        }
    }
    //echo $questionArray['0'];
    //echo $retStr.print_r($questionArray);
}//end_if_block
    

//>>>>>>>>>>>>>>>>>>>>>>> end global array check area >>>>>>>>>>>>>>>>>>>>>>


/*
 * This is apparently the wrong starter code as we need:
 * <form action="controller.php" method="post">'
 * <input type="hidden" name="ID" value="'.$quote["id"].'"</input>'
 */

/*
 * getCurrentQuestion()
 * params : theDBA (object), smartClassObject(object)
 * returns: formatted html code to display the current question. 
 * -
 * Synopsis:
 * >> ATM >> We'll just hardcode the DB to use - then, I'll add the new dashboard later.
 * (1) Be able to load the current questionnaire from the DB.
 */
function getCurrentQuestion($theDBA,$smartClassObject){
    $DB_TO_USE = 'Magnesium (Mg)';
    $theDBA->getOpenDB($DB_TO_USE);
    //$theDBA->getSwitchCurrDB($DB_TO_USE);
    //Here is the current question from the questionnaire.
    $currentQuestionNumber = $theDBA->getCurrDBQuestionNumber();                                //current question number.
    //echo "Here in: getCurrentQuestion(theDBA) curr question: ".$currentQuestionNumber."\n";
    //Now that you have the current question number, you need to go get that question.
    $currentQuestion = $theDBA->getQuestionGivenNumber($currentQuestionNumber);                 //The current question.
    //echo "<div>Question #".$currentQuestionNumber." : ".$currentQuestion."</div>";  

    //branch check will be 2-bits, bit[0]=t/f bit[1]=number to branch to.
    $branchCheck = $smartClassObject->getCheckIfBranch($currentQuestionNumber,$theDBA);     //do I need to branch?
    $memoryCheck = $smartClassObject->getCheckIfMemory($currentQuestionNumber,$theDBA,$branchCheck);//do I have memory for this q?
    //I'll need - an array with the question options, either a number or -1 for question memory.
    //$actionCase = getCurrentQuesstion_Helper($branchCheck[0],$memoryCheck[0]);
    //echo "<br>Action case: ".$actionCase."\n";
    $btnFields = $smartClassObject->getButtonFields($currentQuestion,$branchCheck);
    $catChecked = $smartClassObject->getCatChecked($memoryCheck);
    //
    $htmlBlock="";
    $htmlBlock .= $smartClassObject->getCreateQuestionDiv($currentQuestion);
    //echo "<br>>>>>>><br>";
    $htmlBlock .=$smartClassObject->getCreateIndividualizedRadioBtns($btnFields,$catChecked);
    return $htmlBlock;                            //spits out the correct format html
}//end_method



/*
 * 
 * 
 * 
 * -
 * Synopsis:
 * So, you've decided to set your memory file..
 * To set the memory file. I'll need:
 * (1) question number
 * (2) branch location
 * (3) the option within the branch. -- how do I know the current branch I'm in?
 */
function getSetMemoryFile($theDBA,$smartClassObject,$memoryClue){
    $DB_TO_USE = 'Magnesium (Mg)';
    $theDBA->getOpenDB($DB_TO_USE);
    //$theDBA->getSwitchCurrDB($DB_TO_USE);
    //Here is the current question from the questionnaire.
    $currentQuestionNumber = $theDBA->getCurrDBQuestionNumber();                                //current question number.
    $branchCheck = $smartClassObject->getCheckIfBranch($currentQuestionNumber,$theDBA);     //do I need to branch?
    echo "Memory information<br>";
    echo "Curr Q number:".$currentQuestionNumber."<br>";
    echo "Curr Branch  :".$branchCheck."<br>";
    echo "Mem  Clue    :".$memoryClue."<br>";
    //get Question Option location based on Question number and branch.
    $memLocation = $smartClassObject->getQuestOptionBasedOnQnumAndBranch($currentQuestionNumber,$branchCheck,$memoryClue,$theDBA);
    //I have the question option, the questionNumber, and theDBA (memory file)
    $smartClassObject->getReWriteMemoryFile($currentQuestionNumber,$branchCheck,$theDBA,$memLocation);
    
    
    
}//end_method

/*
 * getCurrentQuesstion_Helper()
 * params:
 * returns:
 * -
 * Synopsis:
 * Meant to be a mini-controller with the bits for: branchCheck,memoryCheck.
 * branchCheck|memoryCheck |  Action |
 * -----------+------------+---------+
 *     0      |    0       |  ret 0  |  
 *     0      |    1       |  ret 1  |
 *     1      |    0       |  ret 2  |
 *     1      |    1       |  ret 3  |     
 * -----------+------------+---------+
 */
function getCurrentQuesstion_Helper($branchCheck,$memoryCheck){
    if(!$branchCheck && !$memoryCheck){      //00
        return 0;
    }
    elseif(!$branchCheck && $memoryCheck){   //01
        return 1;
    }elseif($branchCheck && !$memoryCheck){  //10
        return 2;
    }else{                                   //11
        return 3;
    }
}//end_method

/*
 * get_decrement_QuestionNumber(..)
 * params : $theDBA
 * returns: nothing
 * -
 * Synopsis:
 * For the current DB [feature to be added], go to the session_data table.
 * Check the current question number against the bounds: [1,total_q]
 * if curr_q>=2, decrement.
 * else don't change it.
 */
function get_decrement_QuestionNumber($theDBA){
    $DB_TO_USE = 'Magnesium (Mg)';
    $theDBA->getOpenDB($DB_TO_USE);
    //
    $currentQuestionNumber = $theDBA->getCurrDBQuestionNumber();
    if(intval($currentQuestionNumber)>=2){      //conditions of decrement
        $theDBA->get_decrement_QuestionNumberInDB();
    }
}//end_method

//get_totalQNumber_INDB()

/*
 * get_increment_QuestionNumber(..)
 * params : $theDBA
 * returns: nothing
 * -
 * Synopsis:
 * For the current DB [feature to be added], go to the session_data table.
 * Check the current question number against the bounds: [1,total_q]
 * if curr_q<total_1, increment.
 * else don't change it.
 */
function get_increment_QuestionNumber($theDBA){
    $DB_TO_USE = 'Magnesium (Mg)';
    $theDBA->getOpenDB($DB_TO_USE);
    //
    $currentQuestionNumber = $theDBA->getCurrDBQuestionNumber();
    $total_q = $theDBA->get_totalQNumber_INDB();
    if(intval($currentQuestionNumber)<intval($total_q)){      //conditions of decrement
        $theDBA->get_increment_QuestionNumberInDB();
    }
}//end_method



/*
 * getInitializsmartClassObject(..)
 * params : A smartClass object
 * returns: none
 * -
 * When the first question is selected, initialize the smartClass.txt file
 * 
 */
function getInitializsmartClassObject($smartClassObject){
    $DB_TO_USE = 'Magnesium (Mg)';
    $smartClassObject->set_dbTextFile_SmartClass($DB_TO_USE);//
    $smartClassObject->getInitializeIntelliFiles();
    
}//end_method

/*
 * getQuotesAsHTML
 * params: $arr [the associative array for the quotations database]
 * returns: an echo'd html string
 * -
 * Synopsis:
 *
 */
function getQuotesAsHTML($arr)
{
    // TODO 6: Many things. You should have at least two quotes in table quotes.
    // Layout each quote using a combo of PHP code and HTML strings that includes
    // HTML for buttons along with the actual quote and the author, ~15 PHP statements.
    // You will need to add css rules to styles.css.
    // https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_button_form
    $result = '';

    // ------------------------------------------------------------------------
    foreach ($arr as $quote) {
        /*
         * ---- ALL of this works ----
         * ------------------------------------------------------------------------------------------------------- debugging
         * $temp = $quote['id'];
         * $temp = strval($temp);
         * echo $quote['quote']."|".$quote['id']."|".$quote['rating']."<br>";
         * echo $theDBA->justProveHere($quote['id']);
         * echo "Lower 1 <br>";
         * $theDBA->lowerRating($quote['id']); //I don't get the 'array to string conversion error' if I do this.
         * --------------------------------------------------------------------------------------------------------
         */
        // echo "<br>";

        // echo $quote['quote']."|".$quote['id']."|".$quote['rating']."<br>"; //--- you guessed it: debuggging

        $result .= '<div class="container" >';
        $result .= '"' . $quote['quote'] . '"<br><br>';
        $result .= '<span class="quoteTxtSpan">--' . $quote['author'] . '</span><br><br>';

        // --- here is the container for the form.
        // I think I'm putting things in a form.
        $result .= '<form action="controller.php" method="post" class="formBox" id="formDiv">' . '<input type="hidden" name="ID" value="' . $quote['id'] . '">';

        // --- here is the [+] button on the left. $theDBA->raiseRating
        $result .= '<input type="submit" name="Btn" value="+" class="voteBtnLeft"></input>' . PHP_EOL;
        // --- here is the current rating.
        $result .= $quote['rating'] . PHP_EOL;
        // --- here is the [-] button on the right.
        $result .= '<input type="submit" name="Btn" value="-" class="voteBtnRight"></input>' . PHP_EOL;
        // --- here is the [delete] button.
        // --- this needs to be modified to account for the [delete] only being visibile if someone is
        // --- registered and logged in.
        if (isset($_SESSION['user'])) {
            $result .= '<input type="submit" name="Btn" value="Delete"  class="delBtn"></input>' . PHP_EOL;
        }

        $result .= '</form>';
        $result .= '</div>' . PHP_EOL; // end container

        // Add more code below. You will need to hold the buttons in an HTML <form>
        // This is kind of like adding onclick in Best Reads Two
    } // end_foreach_loop
    return $result;
}

// end_method

/*
 * getChangeRating()
 * params: $theDBA
 * returns: none
 * -
 * Synopsis:
 * This is supposed to update depending on: rating and +/-
 * OK, so reads $_POST['Btn'] to make the decision about what to do: +/- and next 'delete'
 * 'delete' isn't next .. it's HERE!!! [11/22/22]
 * -
 * Week 15 - hw 2 htmlspecialchars(..) adding it here..
 */
function getChangeRating($theDBA)
{
    /*
     * echo "******************<br>";
     * echo "You headed to: getChangeRating() <br>";
     * echo "| POST ID: ".$_POST['ID']."|POST VALUE: ".$_POST['Btn']."<br>";
     * echo "******************<br>";
     */
    switch ($_POST['Btn']) {
        case "-": // minus button hit
            $theDBA->lowerRating(htmlspecialchars($_POST['ID']));
            break;
        case "+": // plus button hit
            $theDBA->raiseRating(htmlspecialchars($_POST['ID']));
            break;
        case "Delete": // delete button hit
            $theDBA->getRemoveQuote(htmlspecialchars($_POST['ID']));
            break;
        default:
            echo "Problem in getChangeRating()| value received: " . $_POST['Btn'] . "<br>";
            break;
    } // end_switch
}

// end_method

/*
 * getAddQuote($theDBA)
 * params: $theDBA
 * returns: none
 * -
 * Synopsis: alers the database: 'quotations' by adding a new author/quote.
 * NOTE: author and quote will be in the global $_POST[] array.
 * Their names are: [quote] => "Howard Roark laughed.." [author]=> "Ayn Rand"
 * Calls: addQuote($quote, $author) from DatabaseAdaptor.php
 * Note:
 * Week 15 - hw2.
 * I'm not sure if I should add the htmlspecialchars here or in the method.
 */
function getAddQuote($theDBA)
{
    $theDBA->addQuote(htmlspecialchars($_POST['quote']), htmlspecialchars($_POST['author']));
} // end_method

?>