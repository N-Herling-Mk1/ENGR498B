<?php 
/*
 * Add .css to .php without separate file
 * https://www.sitepoint.com/community/t/how-add-css-style-to-php-code/246575/3
 * OG code for rainbow button
 * https://getcssscan.com/css-buttons-examples
 */
?>
<html>
<head>
<title>Number Maker</title>
<style>
.topOfPageBanner {
	height: 400px;
	width: 900px;
	background-position: center;
	background-repeat: no-repeat;
	background-image: url(
			'../Images/GESUND_mk4.png');
	margin-left: 15%;
	margin-top:0%;

}

.button-85 {
  padding: 0.6em 2em;
  border: none;
  outline: none;
  color: rgb(255, 255, 255);
  background: #111;
  /*
  Turned this off to get a hover effect.
  cursor: pointer;
  */
  position: relative;
  z-index: 0;
  border-radius: 50px;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  /*
  --- my additions
  */
  width: 400px;
  height:200px;
  margin-left:33%;
  font-size:4em;
}

.button-85:before {
  content: "";
  background: linear-gradient(
    45deg,
    #ff0000,
    #ff7300,
    #fffb00,
    #48ff00,
    #00ffd5,
    #002bff,
    #7a00ff,
    #ff00c8,
    #ff0000
  );
  position: absolute;
  top: -2px;
  left: -2px;
  background-size: 400%;
  z-index: -1;
  filter: blur(5px);
  -webkit-filter: blur(5px);
  width: calc(100% + 8px);
  height: calc(100% + 10px);
  animation: glowing-button-85 20s linear infinite;
  transition: opacity 0.3s ease-in-out;
  border-radius: 10px;
}

@keyframes glowing-button-85 {
  0% {
    background-position: 0 0;
  }
  50% {
    background-position: 400% 0;
  }
  100% {
    background-position: 0 0;
  }
}

.button-85:after {
  z-index: -1;
  content: "";
  position: absolute;
  width: 100%;
  height: 100%;
  background: #222;
  left: 0;
  top: 0;
  border-radius: 40px;
}

.button-85:hover{
  color: blue;

}
</style>
</head>

<?php 
/*
 * File: Controller_Questionnaire_Type.php
 * 
 * ENGR 498B
 * Nathan Herling
 * The Univ. of Arizona, Spring 2023
 * 
 * -
 * Synopsis:
 * Through: Controller_HTML_Writter.php
 * A call to this file will decide what view (and what questionnaire) to run.
 * 
 */

require_once './ErrorThrowClass.php';
require_once './Controller_DB_SET_GET_POP.php';
//$errorObject = new ErrorThrowClass();
$controller_DB_SET_GET_POP = new Controller_DB_SET_GET_POP();


$currentView = $controller_DB_SET_GET_POP->getCurrentView();

switch($currentView){
    case 'raphaelsView':
        $retStr=getTopOfPageHTML();
        echo $retStr.'&nbsp; <a href="../php_Files/View_RaphaelsQuiz.php" target="_blank" rel="noopener noreferrer"><button class="button-85">Take Quiz</button></a>';
        break;
    case 'nathansView':
        $retStr=getTopOfPageHTML();
        echo $retStr.'&nbsp; <a href="../php_Files/View_NathansQuiz.php" target="_blank" rel="noopener noreferrer"><button class="button-85">Take Quiz</button></a>';
        break;
    default:
        echo "Blerp.";
}//end_switch


/*
 * getTopOfPageHTML()
 * params: none
 * returns: html code
 * -
 * Synopsis: creates the top part of the page..
 */
function getTopOfPageHTML(){
    $retStr = "";
    $retStr.='<div class="topOfPageBanner"></div>';       
    
    return $retStr;
}//end_method

?>