<?php 
/*
 * File: Model_QSet_Nathan.php
 * 
 * ENGR498B
 * Nathan Herling
 * The U of A, Spring 2023
 * -
 * Will handle formatting of questions to html code
 * And will interact with Controller_DB_SET_GET_POP.php
 * 
 */
?>