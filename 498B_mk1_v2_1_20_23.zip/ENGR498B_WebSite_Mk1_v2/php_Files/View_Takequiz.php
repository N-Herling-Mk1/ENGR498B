<?php  
/*
File name View_Takequiz.php
-

************************************
* Nathan Herling 
* ENGR 498B, Spring 2023
* The University of Arizona
************************************
-
Notes:
.html,.js, + multiple php-blocks in a .php file.
*/
?>

<!DOCTYPE html>
<html>
<head>
<title>Take the Quiz!</title>
<link rel="stylesheet" type="text/css" href="../css_Files/quizPage.css">
</head>
<body onload=getCurrentQuestionnaireView()>
<?php 
session_start();
/*
 * session_start() creates a session or resumes the current one based on a session 
 * identifier passed via a GET or POST request, or passed via a cookie. 
 * When session_start() is called or when a session auto starts, 
 * PHP will call the open and read session save handlers.
 */

?>
	<!--************************* Top of the page banner *********************************-->
    <!-- Top Banner -->
	<div class="headerDiv"></div>
	<!--************************* Quiz Dashboard *********************************-->


    <!--************************ Question re-write block*********************************-->
	<!-- Where the questionnaire goes -->
	<div id="masterControlQuizPage">
		<!-- Questions will be generated here.. -->
		<div class="questionFormat" id="questionRewriteDiv"></div>

	</div>
	<!--*********************************************************************************-->
<script>
//The question reWrite block.
var questionReWrite_DIV = document.getElementById("questionRewriteDiv");


/*
* getCurrentQuestionnaireView()
* params: none
* returns: none
* -
* Need an AJAX call here to Controller_Questionnaire_Type.php
* Returns View+Questionnaire
* 
*/
function getCurrentQuestionnaireView() {
	console.log("Looking for the current Questionnaire View value.");

	let ajax = new XMLHttpRequest();
	// Arguments: method (GET) and url with query param(s)
	ajax.open("GET", "../php_Files/Controller_Questionnaire_Type.php?todo="+'get_current_view');	//sets 'todo', specifically with the value encoded in the element id

		ajax.send();
		let retStr = "";
		// This high order anonymous function will execute when the server responds (a callback)
		ajax.onreadystatechange = function() {
			//for information purposes:
			console.log("State: " + ajax.readyState);
			
			if (ajax.readyState == 4 && ajax.status == 200) {
				//Get the next question from the controller.
				retStr = ajax.responseText;
				//console.log("Here is the inner HTML**: " + retStr);
				//re-write the question div
				questionReWrite_DIV.innerHTML = retStr;

			} else {
				//At the moment, I have no way to test this.
				//I'm assuming \n characters will function as desired and strings work like this...
				//Below does work, but it throws alerts unnecessarily atm.
				//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
			}
		}; // End anonymous high order function
	
}//end_function



</script>

</body>
</html>