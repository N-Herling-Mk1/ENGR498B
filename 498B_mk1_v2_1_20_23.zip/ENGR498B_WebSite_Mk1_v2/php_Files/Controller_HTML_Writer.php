<?php
/*
 * File: Controller_HTMLWriter.php
 * -
 * This controller file will handle sending back formatted html
 * The source file will be: Model_file_Names.php
 * The controller need not be a class, it can just have methods.
 * -
 * The controller can talk to other files via the $_GET[] array.
 * -
 * How to use $_POST[] and radio buttons.
 * https://www.positronx.io/php-radio-buttons-tutorial/
 */
session_start(); // <-- Need it now, boy-howdy.

/*
 The require_once keyword is used to embed PHP code from another file.
 If the file is not found, a fatal error is thrown and the program stops.
 If the file was already included previously, this statement will not include it again.
 */
require_once './ErrorThrowClass.php';
require_once './Model_DATA_HUB.php';
require_once './Controller_DB_SET_GET_POP.php';

//getThrowErrorAsTxtFile($errorMessage,$fileName)
$errorObject = new ErrorThrowClass();
$model_DATA_HUB_OBJECT = new Model_DATA_HUB();
$controller_DB_SET_GET_POP = new Controller_DB_SET_GET_POP();


//------ mini controller (1) $_GET ------------------------>>
if (isset($_GET['todo'])){
    
    switch($_GET['todo']){
        case "initial_page_set":
            //echo "load_radio_buttons";
            echo getCreateSettingsForm($model_DATA_HUB_OBJECT);
            break;
        case "get_current_Master_Session_Settings":
            echo getCreateMasterSessionStatusTable($controller_DB_SET_GET_POP);
            break;
        case "get_current_view":
            getQuestionType();
        default:
            $fileName = "../txt_Files/x_controller_htmlWriter_error.txt";
            $message = "Unexpected input in:controller_htmlWriter switch statement.\n"
                       ."Value of". '$_GET[]'."=".$_GET['todo']."\n";
            $errorObject->getThrowErrorAsTxtFile($message, $fileName);
    }//end_switch_statement
    
    //unset the global array
    unset($_GET['todo']);
}//end_if_block
//------ end mini controller (1)---------------------------->>>


//------ mini controller (2) $_POST ------------------------>>
//A series of 'if' statements - for the radio buttons
//A switch ------------------ - for the select buttons
//Now I need to design the/a database controller 
if(count($_POST)!=0){
    //echo "<h3>Post is set.</h3>";
    //These will select off the name of the radio button block.
    if(isset($_POST['viewOptions'])){
        $controller_DB_SET_GET_POP->setCurrent_SessionView($_POST['viewOptions']);
        //echo "<p>View ---: ".$_POST['viewOptions']."<br>";
        
    }
    
    //These will select off the name of the radio button block.
    if(isset($_POST['DBOptions'])){
        $controller_DB_SET_GET_POP->setCurrent_SessionDB($_POST['DBOptions']);
        //echo "<p>Curr DB-: ".$_POST['DBOptions']."<br>";
    }
    
    //These will select off the name of the radio button block.
    if(isset($_POST['QuestionOptions'])){
        $controller_DB_SET_GET_POP->setCurrent_SessionQSet($_POST['QuestionOptions']);
        //echo "<p>Q options: ".$_POST['QuestionOptions']."<br>";
    }
    
    //Tested with all comb. works.
    if(isset($_POST['DB_UpdateOptions'])){
        //["magnesium_db","FolicAcid_db","vitmainB12_db","iron_db"];
        //print_r($_POST);
        //echo "Count: ".count($_POST['DB_UpdateOptions'])."<br>";
        for($i=0;$i<count($_POST['DB_UpdateOptions']);$i++){
            //echo $_POST['DB_UpdateOptions'][$i]."<br>";
            switch($_POST['DB_UpdateOptions'][$i]){
                case 'magnesium_db':
                    //echo "<p>Load/Reset: ".$_POST['DB_UpdateOptions'][$i]."<br>";
                    break;
                case 'FolicAcid_db':
                    //echo "<p>Load/Reset: ".$_POST['DB_UpdateOptions'][$i]."<br>";
                    break;
                case 'vitmainB12_db':
                    //echo "<p>Load/Reset: ".$_POST['DB_UpdateOptions'][$i]."<br>";
                    break;
                case 'iron_db':
                    //echo "<p>Load/Reset: ".$_POST['DB_UpdateOptions'][$i]."<br>";
                    break;
                default:
                    echo "<p>Oopsie with switch case..</p>";
            }//end_switch
        }//end_for_loop
        header("Location:View_OptionSetter.php");
    }//end_if_for_switch
    
    //Count must be 2, for you to have checked both boxes. --- checked works
    if(isset($_POST['immolateAndRebirth'])){
        if(count($_POST['immolateAndRebirth'])===2){
            //echo "<p>Engage Immolation<br>";
            $deathAndRebirth = new Controller_DB_SET_GET_POP();
            $deathAndRebirth->startFromScratch();
        }else{
            //echo "<p>No Immolation<br>";
        }
    }//end_check.
    header("Location:View_OptionSetter.php");
}//end_mini_controller
//------ end mini controller (2)---------------------------->>>


/*
 * getCreateSettingsForm()
 * params: $model_fileNameObject
 * returns: html code
 * -
 * Synopsis:
 * via instantiation of an object: Model_file_Names.php
 * This creates the form to send back to: View_OptionSetter.php
 * options:
 * 1. set the view
 * 2. set the current db
 * 3. set the current question set
 * - Act as a mini-controller..
 * Helper function: getCreateRadioBtonOptions(..)
 * -
 * encoding within the html is: /php_Files/Controller_HTML_Writer.php
 * (action - send the $_POST[] fields back to this file)
 * encoding within the html is:
 * onclick=getSend
 */
function getCreateSettingsForm($model_DATA_HUB_OBJECT){
    // - View options
    $localArr_ViewChoice_full = $model_DATA_HUB_OBJECT->getSetOfViewNames_full();
    $localArr_ViewChoice_id = $model_DATA_HUB_OBJECT->getSetOfViewNames_ids();
    // - Data base options
    $localArr_DBChoice_full = $model_DATA_HUB_OBJECT->getSetOfDataBaseNames_full();
    $localArr_DBChoice_id = $model_DATA_HUB_OBJECT->getSetOfDataBaseNames_ids();
    // - Questionnaire options
    $localArr_QChoice_full = $model_DATA_HUB_OBJECT->getSetOfQuestionnaireNames_full();
    $localArr_QChoice_id = $model_DATA_HUB_OBJECT->getSetOfQuestionnaireNames_ids();
    // - load/reset db options
    $localArr_DBOptions_full = $model_DATA_HUB_OBJECT->getSetOfLoadDBNames_full();
    $localArr_DBOptions_id = $model_DATA_HUB_OBJECT->getSetOfLoadDBNames_id();
    // - immolation inniative
    $localArr_ImmolateAndRebirth_full = $model_DATA_HUB_OBJECT->getSetOfImmolateAndRebirth_full();
    $localArr_ImmolateAndRebirth_id = $model_DATA_HUB_OBJECT->getSetOfImmolateAndRebirth_id();
    
    
    
    //Initial set up of the form.
    $retStr = '<form method="post" id="theForm" class="settingsForm" action="../php_Files/Controller_HTML_Writer.php"> '
              .'<br>';
    $retStr .= getCreateRadioBtonOptions($localArr_ViewChoice_full,$localArr_ViewChoice_id,"viewOptions","    Choose a View    ");
    $retStr .= getCreateRadioBtonOptions($localArr_DBChoice_full,$localArr_DBChoice_id,"DBOptions","Set Current Database  ");
    $retStr .= getCreateRadioBtonOptions($localArr_QChoice_full,$localArr_QChoice_id,"QuestionOptions","Choose a Question set ");
    $retStr .= getCreateCheckBoxOptions($localArr_DBOptions_full,$localArr_DBOptions_id,"DB_UpdateOptions","Load/Reset DB(s) ");
    $retStr .= getCreateImmolateAndRebirth($localArr_ImmolateAndRebirth_full,$localArr_ImmolateAndRebirth_id,"immolateAndRebirth","Complete Reset?");
    $retStr.="<br>";
    //Definitely Probably .. and abomination.  POST with action should do the trick..
    //$retStr.='<input type="submit" value="[Submit]" class="submitButtonDBselpage" onclick="getSendGET()">'
    $retStr.='<input type="submit" value="[Submit]" class="submitButtonDBselpage" on >'
            .'<br><br> '
            .'</form> ';
    echo $retStr;      

}//end_function

/*
 * getCreateRadioBtonOptions($localArr_full,$localArr_id)
 * params: parallel arrays, 
 *         name element - that I THINK is important for unique form identification.
 *         text - to go on top of the legend
 * returns: html code
 * -
 * Synopsis:
 * Creates a block of radio buttons, returns it.
 * Note:
 * Creating the array for multiple options with $_POST[]
 * https://www.w3docs.com/snippets/php/how-to-get-multiple-selected-values-of-the-select-box-in-php.html
 */
function getCreateRadioBtonOptions($localArr_full,$localArr_id,$name,$legendTitle){
    $retStr="";
    $retStr.='<fieldset class="legendLengthAndWidth"> '
           .'<legend class="legendFormat">'.strval($legendTitle).':</legend> '
           .'<br>';
            
    for($i=0;$i<count($localArr_full);$i++){
        $retStr.= '<input type="radio" name="'.strval($name).'"'
               .'id="'.strval($localArr_full[$i]).'" '
               .'value="'.strval($localArr_id[$i]).'" '
               .'class="radiobtnSize"> ';
        $retStr.='<label for="'.strval($localArr_id[$i]).'" '
               .'class="radioText"> '
               .strval(($localArr_full[$i]))." "
               .'</label><br>'.PHP_EOL;
    }//end_for_loop
    
    $retStr.="<br>";
    $retStr.='</fieldset> ';
    return $retStr;
}//end_method



/*
 * getCreateCheckBoxOptions()
 * params: parallel arrays, 
 *         name element - that I THINK is important for unique form identification.
 *         text - to go on top of the legend
 * returns: html code
 * -
 * Synopsis:
 * Create checkboxes for the form (via creating html code)
 */
function getCreateCheckBoxOptions($localArr_full,$localArr_id,$name,$legendTitle){
    $retStr="";
    $retStr.='<fieldset class="legendLengthAndWidth"> '
        .'<legend class="legendFormat">'.strval($legendTitle).':</legend> '
            .'<br>';
            
            for($i=0;$i<count($localArr_full);$i++){
                $retStr.= '<input type="checkbox" name="'.strval($name).'[]"'       //NOTE: have to make an array
                       .'id="'.strval($localArr_full[$i]).'" '
                       .'value="'.strval($localArr_id[$i]).'" '
                       .'class="customCheckBoxSize"> ';
                $retStr.='<label for="'.strval($localArr_id[$i]).'" '
                       .'class="dbCheckBoxChoiceText"> '
                       .strval(($localArr_full[$i]))." "
                       .'</label><br>'.PHP_EOL;
            }//end_for_loop
            
            $retStr.="<br>";
            $retStr.='</fieldset> ';
            return $retStr;    
}//end_method


/*
 * getCreateImmolateAndRebirth()
 * params: none
 * returns: none
 * -
 * Synopsis:
 * creates two check boxes.
 * [ ] Do you want to reset everything?
 * [ ] Are you sure?
 * --
 * Both will have to be checked for it to work.
 */
function getCreateImmolateAndRebirth($localArr_full,$localArr_id,$name,$legendTitle){
    $message = '<span class="immolateCheckBoxWarningText">[You must check both boxes]</span>';
    $retStr="";
    $retStr.='<fieldset class="legendLengthAndWidth"> '
           .'<legend class="legendFormat">'.strval($legendTitle).':</legend> '
           .'<br>'
           .$message.'<br>';
           for($i=0;$i<count($localArr_full);$i++){
                $retStr.= '<input type="checkbox" name="'.strval($name).'[]"'       //NOTE: have to make an array
                       .'id="'.strval($localArr_full[$i]).'" '
                       .'value="'.strval($localArr_id[$i]).'" '
                       .'class="customCheckBoxSize"> ';
                $retStr.='<label for="'.strval($localArr_id[$i]).'" '
                       .'class="immolateCheckBoxChoiceText"> '
                       .strval(($localArr_full[$i]))." "
                       .'</label><br>'.PHP_EOL;
            }//end_for_loop
            
            $retStr.="<br>";
            $retStr.='</fieldset> ';
            return $retStr;  
    
}//end_method


/*
 * getCreateMasterSessionStatusTable()
 * params: a $controller_DB_SET_GET_POP object
 * returns: html code
 * -
 * create a table to show the current settings in the master_session_db
 */
function getCreateMasterSessionStatusTable($controller_DB_SET_GET_POP){
    $retStr = "<table class='SessionVariableTable'>";
    
    //-first row: column titles
    $retStr.='<tr>'
        .'<th class="th_top_left">Database Field</th>'  //th_top_right
           .'<th class="th_top_right">Current Setting</th>'
           .'</tr>';
    //-second row
    $retStr.='<tr>'
           .'<td> Current Database </td>'
           .'<td class="td_right_Col">'.$controller_DB_SET_GET_POP->getCurrentDB().'</td>'
           .'</tr>';
    //-third row 
    $retStr.='<tr>'
           .'<td> Current Questionnaire </td>'
           .'<td class="td_right_Col">'.$controller_DB_SET_GET_POP->getCurrentQuestionSet().'</td>'
           .'</tr>';
    //-fourth row
     $retStr.='<tr>'
         .'<td class="td_bottom_left"> Current View </td>'
             .'<td class="td_bottom_right">'.$controller_DB_SET_GET_POP->getCurrentView().'</td>'
         .'</tr>';
     //- end table
     $retStr.='</table>';
     $retStr.=getBuseyAlertSystem();
     echo $retStr;
}//end_method


/*
 * getBuseyAlertSystem()
 * params: ?
 * returns: Busey
 * -
 * Synopsis:
 * Busey.
 * 
 */
function getBuseyAlertSystem(){
    
    $retStr='<div class="BuseyAlert">'
          .'<p class="BusyAlertText">Busey Alert System</p>'
          .'<img src="../Images/Busey_level_1.png" class="Busey1" alt="A-ok-joe">'
          .'<img src="../Images/Busey_level_2.png" class="Busey2"  alt="Pretty good">'
          .'<img src="../Images/Busey_level_3.png" class="Busey3"  alt="Going South">'
          .'<img src="../Images/Busey_level_4.png" class="Busey4"  alt="On fire"><br>'
          .'<span class="BusyText1">A ok, joe!</span>'
          .'<span class="BusyText2">Doing good</span>'
          .'<span class="BusyText3">Probably worry</span>'
          .'<span class="BusyText4">System on fire</span>'
          .'</div>';
    
    return $retStr;
}//end_method

?>