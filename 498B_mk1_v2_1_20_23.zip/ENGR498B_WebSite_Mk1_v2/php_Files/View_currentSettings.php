<?php
/*
*
* File: View_CurrentSettings.php
* Note: you can have more than one .php block per file..
* ENGR 498B
* Nathan Herling
* The University of Arizona, Fall 2023
* 
* Notes:
* Creating a 'new look' page - to display the current settings of the master_session_DB values
* with an accompanying 'warnings_mk1' <div>
*  
*/
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Populate a Database</title>
<link rel="stylesheet" type="text/css" href="../css_Files/view_CurrSettings.css">
</head>
<body onload=loadOptions()>
<?php 
session_start();
?>
    <!-- Top Banner -->
	<div class="headerDiv"></div>

	<div class="topLeftImage"></div>
    <!-- Large Text: Select A Database [class doesn't exist yet..]-->
	<div class="mediumTextTopOfPage">Master_Session_DB Settings</div>
	<div class="topRightImage"></div>
	<br>
		<!-- onsubmit="return false" keeps the form from resetting -->
		<!--I'm using onclick="getSendGET()", I don't know if I need method="post" -->
		<div id="reWriteDiv">

		</div>
		
</body>
<script>
//Create the code to change the inner html.
//I'll need to collect what boxes were clicked..
//There is probably a way to access them via a group from the form. Let's
//code to check them individually first.
//let checkBox_Mg = document.getElementById("magnesium");
//let checkBox_B12 = document.getElementById("vitaminB12");
//let checkBox_Fe = document.getElementById("iron");
//let checkBox_FolicAcid = document.getElementById("folicAcid");

//let theForm = document.getElementById("theForm");//.elements;

let reWriteDiv = document.getElementById("reWriteDiv");//div to re-write



/*
* loadOptions()
* params: none
* returns: html code
* Synopsis:
* talks to the file: Controller_HTML_Writer.php
* sends a GET request, and gets back the current database options to populate.
*/
function loadOptions(){
	console.log("In loadOptions()");
	let ajax = new XMLHttpRequest();
	// Arguments: method (GET) and url with query param(s)
	ajax.open("GET", "../php_Files/Controller_HTML_Writer.php?todo="+"get_current_Master_Session_Settings");	
	ajax.send();
	let retStr = "";
	// This high order anonymous function will execute when the server responds (a callback)
	ajax.onreadystatechange = function() {
		//for information purposes:
		console.log("State: " + ajax.readyState);
		if (ajax.readyState == 4 && ajax.status == 200) {
			//This is how we turn a JSON array into a JS array.

			retStr = ajax.responseText;
			//I am indeed making it to the correct place in the controller.
			//console.log("Here is the retStr**: " + retStr);
			//call to local function to rewrite div
			reWriteDiv.innerHTML = retStr;

		} else {
			//At the moment, I have no way to test this.
			//I'm assuming \n characters will function as desired and strings work like this...
			//Below does work, but it throws alerts unnecessarily atm.
			//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
		}
	}; // End anonymous high order function	

}//end_function
</script>
</html>