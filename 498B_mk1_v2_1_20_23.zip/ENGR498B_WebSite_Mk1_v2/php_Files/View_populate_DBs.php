<!-- 
File: View_populate_DBs.php

ENGR 498B
Nathan Herling
The University of Arizona, Fall 2023

Notes:
Helfpul with aligning the resized input/label
https://www.geeksforgeeks.org/how-to-align-checkboxes-and-their-labels-on-cross-browsers-using-css/
Command to stop the form from resetting
https://www.youtube.com/watch?v=jDfrY2UUSrc
 -->
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Populate a Database</title>
<link rel="stylesheet" type="text/css" href="../css_Files/popDBPage.css">
</head>
<body onload=loadOptions()>
<?php 
session_start();
?>
    <!-- Top Banner -->
	<div class="headerDiv"></div>

    <!-- Large Text: Select A Database [class doesn't exist yet..]-->
	<div class="mediumTextTopOfPage">Select one or more databases to update</div><br>
		<!-- onsubmit="return false" keeps the form from resetting -->
		<!--I'm using onclick="getSendGET()", I don't know if I need method="post" -->
		<div id="reWriteDiv">

		</div>
		
</body>
<script>
//Create the code to change the inner html.
//I'll need to collect what boxes were clicked..
//There is probably a way to access them via a group from the form. Let's
//code to check them individually first.
let checkBox_Mg = document.getElementById("magnesium");
let checkBox_B12 = document.getElementById("vitaminB12");
let checkBox_Fe = document.getElementById("iron");
let checkBox_FolicAcid = document.getElementById("folicAcid");

let theForm = document.getElementById("theForm");//.elements;

let reWriteDiv = document.getElementById("reWriteDiv");//div to re-write
let set_database = document.getElementsByName('checkboxArray'); //this stores the common elements with name='checkboxArray'


/*
* getSendGET()
* params: none
* returns: none
* -
* Synopsis:
* sends an AJAX 'GET' array to the Database_Controller.php
*
*/
function getSendGET(){
	//>>>>>
		let ajax = new XMLHttpRequest();
		// Arguments: method (GET) and url with query param(s)
		console.log(getConvertArrayToJSON());
		ajax.open("GET", "../php_Files/Controller_DB_SET_POP.php?set_database="+JSON.stringify(getConvertArrayToJSON()));	
		ajax.send();
		let retStr = "";
		// This high order anonymous function will execute when the server responds (a callback)
		ajax.onreadystatechange = function() {
			//for information purposes:
			console.log("State: " + ajax.readyState);
			if (ajax.readyState == 4 && ajax.status == 200) {
				//This is how we turn a JSON array into a JS array.

				retStr = ajax.responseText;
				//retStr="<p>Bip...</p>";
				//I am indeed making it to the correct place in the controller.
				console.log("Here is the retStr**: " + retStr);
				//call to local function to rewrite div
				reWriteDiv.innerHTML = getCalcDivString();

			} else {
				//At the moment, I have no way to test this.
				//I'm assuming \n characters will function as desired and strings work like this...
				//Below does work, but it throws alerts unnecessarily atm.
				//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
			}
		}; // End anonymous high order function	
	
}//end_function

/*
* getCalcDivString()
* params: none
* returns: formatted html
* -
* Synopsis:
* formatted output for a <div> element
* alerts user to which databases have been populated.
* getting elements from a form:
* https://www.geeksforgeeks.org/how-to-get-values-from-html-input-array-using-javascript/
*/
function getCalcDivString(){
	retStr="<div class='returnPrompt'><ul>";
	retStrPopulated="";
	retStrUnpoplulated="";
	console.log("There are "+set_database.length +" in your input array.");
	retStrPopulated+="The following databases <b>have</b> been populated:<br>";
	retStrUnpoplulated+="The following databases have <b>not</b> been populated:<br>";
	for( i=0;i< set_database.length;i++){
		if(set_database[i].checked){
			retStrPopulated+="<li><div class='green_BG'>"+set_database[i].value+"</div></li>";
		}else{
			retStrUnpoplulated+="<li><div class='red_BG'>"+set_database[i].value+"</div></li>";
		}
	}
	retStr+=retStrPopulated+"<br>";
	retStr+=retStrUnpoplulated;
	retStr+="</div></ul>";
	return retStr;

}//end_function


/*
* getConvertArrayToJSON()
* params: none
* returns: An array in JSON format
* Synopsis:
* attempting to 'stringify' the set_database wasn't working
* I'm making my own 'JSON LIKE' array and sending that
* Attempting to make an 'Associative Array' in php
* NOTE: it appears to be working.
*/
function getConvertArrayToJSON(){
// Sample JS object
//var obj = {"name": "Peter", "age": 22, "country": "United States"};
let retArray=[];
	for( i=0;i< set_database.length;i++){
		let retStr="";
		retStr+=set_database[i].value+":"+set_database[i].checked;
		retArray.push(retStr);
	}
	return retArray;
}//end_function


/*
* loadOptions()
* params: none
* returns: html code
* Synopsis:
* talks to the file: Controller_HTML_Writer.php
* sends a GET request, and gets back the current database options to populate.
*/
function loadOptions(){
		let ajax = new XMLHttpRequest();
		// Arguments: method (GET) and url with query param(s)
		console.log(getConvertArrayToJSON());
		ajax.open("GET", "../php_Files/Controller_HTMLWriter.php?todo="+"on_load_populate_a_DB");	
		ajax.send();
		let retStr = "";
		// This high order anonymous function will execute when the server responds (a callback)
		ajax.onreadystatechange = function() {
			//for information purposes:
			console.log("State: " + ajax.readyState);
			if (ajax.readyState == 4 && ajax.status == 200) {
				//This is how we turn a JSON array into a JS array.

				retStr = ajax.responseText;
				//I am indeed making it to the correct place in the controller.
				console.log("Here is the retStr**: " + retStr);
				//call to local function to rewrite div
				reWriteDiv.innerHTML = retStr;

			} else {
				//At the moment, I have no way to test this.
				//I'm assuming \n characters will function as desired and strings work like this...
				//Below does work, but it throws alerts unnecessarily atm.
				//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
			}
		}; // End anonymous high order function	

}//end_function
</script>
</html>