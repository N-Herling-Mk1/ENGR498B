<?php
/*
 * File: Database_Controller.php
 * -
 * The 'C' in MVC architecture.
 * -
 * All manipulations of the database that don't involve initializations should run through the controller.
 * 
 */

session_start(); // <-- Need it now, boy-howdy.

require_once './DatabaseAdaptor.php';
require_once './questionLoadClass.php';
require_once './questionSmartClass.php';

$theDBA = new DatabaseAdaptor();

/*
 * Handle all 'get posts' here.  Just assign each unique action a unique id.
 * 
 * 
 */
if (isset($_GET['todo'])){
    
    switch($_GET['todo']){
        case "first":
            //initialize the questionnaire.
            //$theDBA->getPopulateDB();
            //get the first question.
            //$questionLoadClass->currentQuestion();
            echo "<div>First up!</div>";
            getInitializsmartClassObject($smartClassObject);//getInitializeIntelliFiles()
            echo getCurrentQuestion($theDBA,$smartClassObject);
            break;
        case "getPrevQuestion_Btn":
            echo "<div>[Prev]</div>";
            get_decrement_QuestionNumber($theDBA);
            echo getCurrentQuestion($theDBA,$smartClassObject);
            break;
        case "getNextQuestion_Btn":
            //$questionLoadClass->get_increment_QuestionNumber();
            echo "<div>[Next]</div>";
            get_increment_QuestionNumber($theDBA);
            echo getCurrentQuestion($theDBA,$smartClassObject);
            break;
        case "submit_Btn":
            echo "<div>[Submit]</div>";
            //getCurrentQuestion($theDBA);
            break;
        case "set_database":
            echo "<div>[Set DataBase]</div>";
            $questionArray = json_decode($_GET ["set_database"]);
            foreach($questionArray as $element) {
                $tempArr=explode(":",$element);
                if($tempArr[1]==='true'){    //if true, call method to create that database.
                    //echo "Checkd true\n";
                    $theDBA->getCreateDB($tempArr[0]);
                }
            }//end_for
            
        default:
            //I know I can make it here under correct conditions.
            echo"<div>Setting memory file</div>";
            getSetMemoryFile($theDBA,$smartClassObject,$_GET['todo']);
            //header("Location:quizView.php");
            //echo getCurrentQuestion($theDBA,$smartClassObject);
    }
    unset($_GET['todo']);
}//end_if_block


if (isset($_GET ['checkBoxArray'])) {
    //$retStr="You are >here>";
    $questionArray = json_decode($_GET ['checkBoxArray']);
    foreach($questionArray as $element) {
        $tempArr=explode(":",$element);
        if($tempArr[1]==='true'){    //if true, call method to create that database.
            //echo "Checkd true\n";
            $theDBA->getCreateDB($tempArr[0]);
        }
    }
    //echo $questionArray['0'];
    //echo $retStr.print_r($questionArray);
}//end_if_block

?>