
<?php 
//--put a link here to: boilerPlate.html
//echo '&nbsp; <a href="https://www.freecodecamp.org/" target="_blank" rel="noopener noreferrer">Press Me</button></a>';
echo '&nbsp; <a href="../php_Files/View_RaphaelsQuiz.php" target="_blank" rel="noopener noreferrer"><button>Press Me</button></a>';
?>