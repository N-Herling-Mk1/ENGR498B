<?php
/*
 * File: Database_InitializeAll.php
 * -
 * To be used to Initialize/re-initialize all database(s), and database fields.
 * -
 * Synopsis:
 * Initialize all database(s), their column titles, and datafields.
 * 
 */





?>