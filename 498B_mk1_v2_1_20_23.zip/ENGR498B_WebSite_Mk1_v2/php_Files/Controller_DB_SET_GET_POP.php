<?php
/*
 * File: Controller_DB_SET_GET_POP.php
 * -
 * This will be the interaction point between .sql and .php
 */
require_once './Model_DATA_HUB.php';
//require_once './Database_Controller.php';
//require_once './questionLoadClass.php';
//require_once './questionSmartClass.php';
require_once './ErrorThrowClass.php';


class Controller_DB_SET_GET_POP{
    private $DATA_BASE_NAME;        //The name you want to set as the current database
    private $DB;                    //The object that functions as the database -- I can now access $DB anywhere in this class.

    public function getCreateDB($dbName){
        $this->setDBName($dbName);
        //echo "Opening DB name: ".$this->DATA_BASE_NAME."\n";
        $dataBase ='mysql:dbname='.strval($this->DATA_BASE_NAME).';charset=utf8;host=127.0.0.1';       //<--- name has already been changed.
        $user ='root';                                                      //when the DB doesn't exist - you get
        $password =''; // Empty string with XAMPP install                   //via CLI
        try {                                                               //Error establishing Connection
            $this->DB = new PDO ( $dataBase, $user, $password );
            $this->DB->setAttribute ( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
        } catch ( PDOException $e ) {
            echo ('Error establishing Connection');
            echo ($e);
            exit ();
        }
        //$this->getPopulateDB();
    }//end_method
    
    /*
     * startFromScratch()
     * params : none
     * returns: none
     * -
     * Synopsis:
     * Completely resets the Databases and their tables.
     * (So, you've decided to engage the death/rebirth innitiative..)
     * Helper methods:
     * getCreateDB_Questions_and_their_tables(..)
     */
    public function startFromScratch() {
        echo "You are in startFromScratch()<br>";
        // - declare all of these here - for the sense of organization.
        // - we'll send all of them to functions to create the tables.
        $Model_DATA_HUB = new Model_DATA_HUB();
        // - the question databases
        $ArrayDB_Names_Questions = $Model_DATA_HUB->getSetOfDBQuestionOptions();
        $ArrayDB_PhoenixArray = $Model_DATA_HUB->getPhoenixArray_Questions();//The Phoenix array holds all! [see:getPhoenixArray_()in, Model_DATA_HUB.php
        $tableNames_Qs = $Model_DATA_HUB->getSetOfDBTablesEachQuestion();
        //- the master session database
        $MasterSessionDB_Name = $Model_DATA_HUB->getNameOfMasterSessionDataDB();
        $MasterSessionDB_PhoenixArray = $Model_DATA_HUB->getPhoenixArray_MasterSession();
        $MasterSessionDB_tableNames = $Model_DATA_HUB->getSessionMasterDB_TableNames();
        
        //* First up, immolation. ------------- works

        //Deletes the masterSessionData_DB, and all the question Databases.
        $this->getImmolationInnitiative($ArrayDB_Names_Questions,$MasterSessionDB_Name);
        
        //This will create the question databases and their tables.
        $this->getCreateDB_Questions_and_their_tables($ArrayDB_Names_Questions,$ArrayDB_PhoenixArray,$tableNames_Qs);
        //This will create the master session database and its table.
        $this->getCreateDB_Questions_and_their_tables($MasterSessionDB_Name,$MasterSessionDB_PhoenixArray,$MasterSessionDB_tableNames);
        //initialize the master session database. --- just hard code it... (ha).
        $this->getInitialize_Master_Session_Database();
    }//end_function
    
    
    /*
     * getImmolationInnitiative()
     * params: names of databases [single, or an array] 
     * returns: none
     * -
     * deletes the databases
     * Called from: startFromScratch() 
     */
    public function getImmolationInnitiative($ArrayDB_Names_Questions,$MasterSessionDB){
        
        //* First up, immolation. ------------- kill the question databases
        foreach($ArrayDB_Names_Questions as $dbName){
            $this->getCreateDB($dbName);        //we need this command to establish a connection to current DB.
            $stmt = $this->DB->prepare("DROP DATABASE IF EXISTS ".strval($dbName).";");
            $stmt->execute();
        }//end_for_loop
        //* First up, immolation. ------------- kill the master session database
        foreach($MasterSessionDB as $dbName){
            $this->getCreateDB($dbName);        //we need this command to establish a connection to current DB.
            $stmt = $this->DB->prepare("DROP DATABASE IF EXISTS ".strval($dbName).";");
            $stmt->execute();
        }//end_for_loop
    }//end_function
    
    /*
     * getCreateDB_Questions_and_their_tables()
     * params:
     * returns:
     * -
     * Synopsis:
     * Called from:
     * startFromScratch()
     * 
     */
    public function getCreateDB_Questions_and_their_tables($ArrayDB_Names_Questions,$ArrayDB_PhoenixArray,$tableNames_Qs){
        //*Re-create the databases. ------------- works
        foreach($ArrayDB_Names_Questions as $dbName){
            $this->getCreateDB($dbName);        //we need this command to establish a connection to current DB.
            //
            $stmt = $this->DB->prepare("CREATE DATABASE ".strval($dbName).";");
            $stmt->execute();
            //here - put the code to create all the tables in each database.
            $parallelCountTables = 0;
            $retStr = "";
            // echo "DB: <b>".$ArrayDB_Names_Questions[$k]."</b><br>";
            for($i=0;$i<count($ArrayDB_PhoenixArray)-1;$i=$i+2){
                $retStr = "CREATE TABLE ";
                //-- switch to the database.
                $stmt = $this->DB->prepare("USE ".strval($dbName).";");
                $stmt->execute();
                //
                $retStr .=strval($tableNames_Qs[$parallelCountTables])." (";
                echo "PhoenixArray count: ".count($ArrayDB_PhoenixArray[$i])."<br>";
                
                for($j=0;$j<count($ArrayDB_PhoenixArray[$i])-1;$j=$j+2){
                    $retStr.=strval($ArrayDB_PhoenixArray[$i][$j])." ".strval($ArrayDB_PhoenixArray[$i+1][$j]).","
                           .strval($ArrayDB_PhoenixArray[$i][$j+1])." ".strval($ArrayDB_PhoenixArray[$i+1][$j+1]).",";
                }//end_for
                // - I need this case to handle an odd number of fields:var-descriptions
                if(count($ArrayDB_PhoenixArray[$i])%2!=0){
                    $j = count($ArrayDB_PhoenixArray[$i])-1;
                    $retStr.=strval($ArrayDB_PhoenixArray[$i][$j])." ".strval($ArrayDB_PhoenixArray[$i+1][$j]).",";
                           //.strval($ArrayDB_PhoenixArray[$i][$j+1])." ".strval($ArrayDB_PhoenixArray[$i+1][$j+1]).",";
                }
                
                //remove the last comma, add ");" ---- string prep.
                $parallelCountTables++;
                $retStr=rtrim($retStr,",");
                $retStr.=");";
                echo $retStr."<br>";
                //-- Create the table
                $stmt = $this->DB->prepare(strval($retStr));
                $stmt->execute();
             
            }
            echo "<b>done.</b><br>";
            
        }//end_foreach_loop
        
    }//end_function

    
    /*
     * getInitialize_Master_Session_Database()
     * params: none
     * returns: none
     * -
     * Synopsis..
     * Just hard code the initialization - 
     * 
     */
    public function getInitialize_Master_Session_Database(){
        $Model_DATA_HUB = new Model_DATA_HUB();
        $MasterSessionDB_initValues = $Model_DATA_HUB->getSetOfInitializationValues_MasterSession();
        $MasterSessionDB_initFields = $Model_DATA_HUB->getSetOfInitializationFields_MasterSession();
        
        // - auto create fields..
        $Str_Fields = "(";
        foreach($MasterSessionDB_initFields as $field){
            $Str_Fields.=$field.",";
        }
        $Str_Fields = rtrim($Str_Fields,",");
        $Str_Fields .= ") ";                    //Note: extra space
        
        // - auto create values..
        $Str_Values = "VALUES (";
        foreach($MasterSessionDB_initValues as $value){
            $Str_Values.="'".htmlspecialchars($value)."'".",";
        }
        $Str_Values = rtrim($Str_Values,",");
        $Str_Values .= ");";                    //Note: semicolon
        
        
        //setOfInitialization_MasterSession
        $this->getCreateDB("master_session_data_db");        //we need this command to establish a connection to current DB.
        //
        $stmt = $this->DB->prepare("USE master_session_data_db;");
        $stmt->execute();
        
        $statementStr ="";
        $statementStr.="INSERT INTO master_session_data_table "
                     .strval($Str_Fields)
                     .strval($Str_Values);
        //echo "HERE IS OUR STATEMENT :".$statementStr."<br>";
        $stmt = $this->DB->prepare($statementStr);
        $stmt->execute();
        
    }//end_method
    
    //Not qutie a getter.
    //Input is intended to be the name of the database
    /*
     * getSetCurrentDB($dbName)
     * params: a valid database name
     * returns: none
     * -
     * Synopsis:
     * The Database: master_session_data_DB
     * Will hold:
     * current_DB
     * current_questionnaire
     * current_view
     */
    public function getSetCurrentDB($dbName){
        //$this->setDBName($dbName);
        //echo "Opening DB name: ".$this->DATA_BASE_NAME."\n";
        $dataBase ='mysql:dbname='.strval($dbName).';charset=utf8;host=127.0.0.1';       //<--- name has already been changed.
        $user ='root';                                                      //when the DB doesn't exist - you get
        $password =''; // Empty string with XAMPP install                   //via CLI
        try {                                                               //Error establishing Connection
            $this->DB = new PDO ( $dataBase, $user, $password );
            $this->DB->setAttribute ( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
        } catch ( PDOException $e ) {
            echo ('Error establishing Connection');
            echo ($e);
            exit ();
        }
    }//end_method
    
    //////**** master_session_data_db --- getters [begin] *****
    /*
     * getCurrentView()
     * params: none
     * returns: none
     * -
     * Synopsis:
     * From the database: master_session_data_db, access the field: current_view_field
     *
     */
    public function getCurrentView(){
        //set the database to: master_session_data_db
        $this->getSetCurrentDB("master_session_data_db");
        //(1) I'll need the session_data
        $searchString = "SELECT current_view_field ".
            "FROM master_session_data_table ".
            "WHERE entry=1 ".
            "Limit 1";
        //echo "Here is the command we made:".$searchString."\n";     //---- debugging
        //(1)
        $stmt = $this->DB->prepare($searchString);
        //(2)
        $stmt->execute();
        //(3)
        $retArr = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $retArr[0]['current_view_field'];
        //echo  "HERE IS session_data: ".gettype($sessionData)."\n";
        //echo "\n".print_r(array_keys($sessionData)); //spits out ([0]=>[0])
        //echo print_r($sessionData);
        //echo "\n>>"."\n";
        //echo $sessionData[0]['curr_q'];     //Whatever-the-fuck thing this is appears to work.
        //echo "\n>>\n";
    }//end_method
    
    /*
     * getCurrentDB()
     * params: none
     * returns: none
     * -
     * Synopsis:
     * From the database: master_session_data_db, access the field: current_DB_field
     *
     */
    public function getCurrentDB(){
        //set the database to: master_session_data_db
        $this->getSetCurrentDB("master_session_data_db");
        //(1) I'll need the session_data
        $searchString = "SELECT current_DB_field ".
            "FROM master_session_data_table ".
            "WHERE entry=1 ".
            "Limit 1";
        //echo "Here is the command we made:".$searchString."\n";     //---- debugging
        //(1)
        $stmt = $this->DB->prepare($searchString);
        //(2)
        $stmt->execute();
        //(3)
        $retArr = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $retArr[0]['current_DB_field'];
        //echo  "HERE IS session_data: ".gettype($sessionData)."\n";
        //echo "\n".print_r(array_keys($sessionData)); //spits out ([0]=>[0])
        //echo print_r($sessionData);
        //echo "\n>>"."\n";
        //echo $sessionData[0]['curr_q'];     //Whatever-the-fuck thing this is appears to work.
        //echo "\n>>\n";
    }//end_method
    
    /*
     * getCurrentQuestionSet()
     * params: none
     * returns: none
     * -
     * Synopsis:
     * From the database: master_session_data_db, access the field: current_questionnaire_field
     *
     */
    public function getCurrentQuestionSet(){
        //set the database to: master_session_data_db
        $this->getSetCurrentDB("master_session_data_db");
        //(1) I'll need the session_data
        $searchString = "SELECT current_questionnaire_field ".
            "FROM master_session_data_table ".
            "WHERE entry=1 ".
            "Limit 1";
        //echo "Here is the command we made:".$searchString."\n";     //---- debugging
        //(1)
        $stmt = $this->DB->prepare($searchString);
        //(2)
        $stmt->execute();
        //(3)
        $retArr = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $retArr[0]['current_questionnaire_field'];
        //echo  "HERE IS session_data: ".gettype($sessionData)."\n";
        //echo "\n".print_r(array_keys($sessionData)); //spits out ([0]=>[0])
        //echo print_r($sessionData);
        //echo "\n>>"."\n";
        //echo $sessionData[0]['curr_q'];     //Whatever-the-fuck thing this is appears to work.
        //echo "\n>>\n";
        
    }//end_method
    
    
    
    //////**** master_session_data_db --- getters [end] *****
    
    //////**** master_session_data_db --- setters [begin] *****
    /*
     * Setter for the field that holds the name of the database to set as the current database.
     */
    /*
     * setCurrent_SessionView()
     * params: none
     * returns: none
     * -
     * Synopsis:
     * From the database: master_session_data_db, set the field: current_view_field
     *
     */
    public function setCurrent_SessionView($viewValue){

        $this->getSetCurrentDB("master_session_data_db");
        //
        //(1) I'll need the session_data
        $searchString = "UPDATE master_session_data_table "
                        ."SET current_view_field='".strval($viewValue)."' "
                        ."WHERE entry=1;";
        //echo "Here is the command we made:".$searchString."\n";     //---- debugging
        //(1)
        $stmt = $this->DB->prepare($searchString);
        //(2)
        $stmt->execute();
        
    }//end_method
    
    
    
    /*
     * setCurrent_SessionDB()
     * params :
     * returns:
     * -
     * Synopsis:
     * Sets master_session_data_db, current database.
     * 
     */
    public function setCurrent_SessionDB($DBValue){
        
        $this->getSetCurrentDB("master_session_data_db");
        //
        //(1) I'll need the session_data
        $searchString = "UPDATE master_session_data_table "
            ."SET current_DB_field='".strval($DBValue)."' "
                ."WHERE entry=1;";
                //echo "Here is the command we made:".$searchString."\n";     //---- debugging
                //(1)
                $stmt = $this->DB->prepare($searchString);
                //(2)
                $stmt->execute();
              
    }//end_method

    
    /*
     * setCurrent_SessionQSet()
     * params: none
     * returns: none
     * -
     * Synopsis:
     * From the database: master_session_data_db, set the field: current_questionnaire_field
     *
     */
    public function setCurrent_SessionQSet($QValue){
        
        $this->getSetCurrentDB("master_session_data_db");
        //
        //(1) I'll need the session_data
        $searchString = "UPDATE master_session_data_table "
            ."SET current_questionnaire_field='".strval($QValue)."' "
                ."WHERE entry=1;";
                //echo "Here is the command we made:".$searchString."\n";     //---- debugging
                //(1)
                $stmt = $this->DB->prepare($searchString);
                //(2)
                $stmt->execute();
                
    }//end_method

    //////**** master_session_data_db --- setters [end] *****
    
    
    /*
     * 
     * Set the current private instance $this->DB
     */
    public function getSetCurrentDB_USECommand($setToDB){
        $this->getCreateDB($setToDB);        //we need this command to establish a connection to current DB.
        //
        $stmt = $this->DB->prepare("USE ".strval($setToDB));
        $stmt->execute();
        
    }//end_method
    
    /*
     * Setter for the field that holds the name of the database to set as the current database.
     */
    public function setDBName(){
        
        
    }//end_method
    
}//end_class
?>
