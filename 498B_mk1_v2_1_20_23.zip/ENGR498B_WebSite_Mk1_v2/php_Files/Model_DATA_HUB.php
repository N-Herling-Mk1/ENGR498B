<?php
/*
 * File: Model_DATA_HUB.php
 * -
 * This file is the singular location of all database names/file names.
 * And, the ability to return questionnaire files as an array.
 * -
 * This will be the source of database file names.
 * One stop shopping!
 * 
 */

class Model_DATA_HUB{
    
    //-parallel arrays for the form that will set options.
    //(1)
    //-radio buttons
    private $setOfDataBaseNames_full = ["DB:Magnesium (Mg)","DB:Folic Acid (B9)","DB:Vitamin B12 (B12)","DB:Iron (Fe)"];
    private $setOfDataBaseNames_id = ["magnesium_db","FolicAcid_db","vitmainB12_db","iron_db"];
    //(2)
    //-radio buttons
    private $setOfViewOptionNames_full = ["Nathan's View &nbsp;&nbsp;[EXPERT level]","Raphael's View [NOOB level]"];
    private $setOfVewOptionNames_id = ["nathansView","raphaelsView"];
    //(3)
    //-radio buttons
    private $setOfQuestionnaireNames_full = ["Q:Magnesium (Mg)","Q:Folic Acid (B9)","Q:Vitamin B12 (B12)","Q:Iron (Fe)"];
    private $setOfQuestionnaireNames_id = ["magnesium_q","FolicAcid_q","vitmainB12_q","iron_q"];
    //(4)
    //-checkboxes
    //- I think I can get away with the same ids as (1) since the name will be different.
    private $setOfLoadDBNames_full = ["DB:Magnesium (Mg)","DB:Folic Acid (B9)","DB:Vitamin B12 (B12)","DB:Iron (Fe)"];
    private $setOfLoadDBNames_id = ["magnesium_db","FolicAcid_db","vitmainB12_db","iron_db"];
    //(5)
    //-checkboxes
    //unique
    private $setOfImmolateAndRebirth_full = ["Complete Reset","Are you Sure?"];
    private $setOfImmolateAndRebirth_id = ["immolateAndRebirth_1","immolateAndRebirth_2"];
    //
    // - below are for loading/creating database options.
    // - the set of databases for questionnaires + the set of databases for questionnaires
    private $setOfQuestionnaireDBNames = ["magnesium","folicacid","vitaminB12","iron"];
    private $setOfTablesForEachQuestionnaire = ["comments_table","questions_table","branch_commands_table","Q_session_data_table"];
    //. these will be parallel arrays.
    //$array = array("comments"=>"["line","comment"],["int(20)","varchar(1023)"]");
    private $setOfColumnNames_Questionnaire_Table_comments = ["line","comment"];
    private $setOfColumnVarType_Questionnaire_Table_comments = ["int(20)","varchar(1023)"];
    //.
    private $setOfColumnNames_Questionnaire_Table_questions = ["number","question"];
    private $setOfColumnVarType_Questionnaire_Table_questions = ["int(63)","varchar(1023)"];
    //.
    private $setOfColumnNames_Questionnaire_Table_branch_commands = ["line","command"];
    private $setOfColumnVarType_Questionnaire_Table_branch_commands = ["int(20)","varchar(1023)"];
    //.
    private $setOfColumnNames_Questionnaire_Session_Data_commands = ["q_type","q_tree","total_q","curr_q"];
    private $setOfColumnVarType_Questionnaire_Session_Data_commands = ["varchar(63)","varchar(255)","int(63)","int(63)"];
    //
    // - the info. for master_session_data + tables for master_session_data
    private $master_session_data_DBName = ["master_session_data_DB"];
    private $setOfTablesForMasterSessionData = ["master_session_data_table"];
    //
    private $setOfColumnNames_MasterSession = ["entry","current_DB_field","current_questionnaire_field","current_view_field"];
    private $setOfColumnVarType_MasterSession = ["int(20)","varchar(63)","varchar(63)","varchar(63)"];
    // - an initialization set.
    private $setOfInitialization_Fields_Master_Session = ["entry","current_DB_field","current_questionnaire_field","current_view_field"];
    private $setOfInitialization_Values_Master_Session = ["1","magnesium","magnesium","nathansView"];
   
    // - set of current questionnaire files
    private $MgDataBaseQ_File = "../txt_Files/q_Mg_Qs_Mk3.txt";
    private $FolicAcidQ_File = "../txt_Files/q_FolicAcid_Qs_Mk3.txt";
    private $VitaminB12Q_File = "../txt_Files/q_VitmainB12_Qs_Mk3.txt";
    private $IronQ_File = "../txt_Files/q_Fe_Qs_Mk3.txt";
    //
    
    //Handle the parallel arrays.----------------------------------------------------------------------
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    /*
     * getDataBaseChoices()
     * params : none
     * returns: the array with the 'full name' of the database. (user friendly)
     * -
     * Note:
     * Parallel arrrays: setOfDataBaseNames_full,setOfDataBaseNames_full     
     */
    public function getSetOfDataBaseNames_full(){
        return $this->setOfDataBaseNames_full;
    }//end_method
    
    /*
     * setOfDataBaseNames_ids()
     * params: none
     * returns: the id tag of the databases
     * -
     * Note:
     * Parallel arrrays: setOfDataBaseNames_full,setOfDataBaseNames_full
     * 
     */
    public function getSetOfDataBaseNames_ids(){
        return $this->setOfDataBaseNames_id;
    }//end_method
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //****
    //Truncate the comments, 
    //Note: Parallel arrays: setOfViewOptionNames_full, setOfViewOptionNames_id
    public function getSetOfViewNames_full(){
        return $this->setOfViewOptionNames_full;    
    }//end_method
    
    public function getSetOfViewNames_ids(){
        return $this->setOfVewOptionNames_id;
    }//end_method
    //****
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //****
    //Truncate the comments,
    //Note: Parallel arrays: setOfQuestionnaireNames_full, setOfQuestionnaireNames_id
    public function getSetOfQuestionnaireNames_full(){
        return $this->setOfQuestionnaireNames_full;
    }//end_method
    
    
    public function getSetOfQuestionnaireNames_ids(){
        return $this->setOfQuestionnaireNames_id;
    }//end_method
    //****
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //****
    //Truncate the comments,    
    //Note: Parallel arrays: setOfLoadDBNames_full, setOfLoadDBNames_id
    public function getSetOfLoadDBNames_full(){        
        return $this->setOfLoadDBNames_full;
    }//end_method
    
 
    public function getSetOfLoadDBNames_id(){
        return $this->setOfLoadDBNames_id;
    }//end_method
    //****
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //****
    //Truncate the comments,
    //Note: Parallel arrays: setOfImmolateAndRebirth_full, setOfImmolateAndRebirth_id
    public function getSetOfImmolateAndRebirth_full(){
        return $this->setOfImmolateAndRebirth_full;
    }//end_method
    
    
    public function getSetOfImmolateAndRebirth_id(){
        return $this->setOfImmolateAndRebirth_id;
    }//end_method
    //****
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    
    
    
    //--- end of parallel arrays -------------------------------------------------------------------
    
    //.............
    // - below are for loading/creating database options.
    //..............
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //****
    //- getter for the instantiation of databases
    public function getSetOfDBQuestionOptions(){
        return $this->setOfQuestionnaireDBNames;
    }//end_method
    
 
    //- getter for the instantiation of databases
    public function getSetOfDBTablesEachQuestion(){
        return $this->setOfTablesForEachQuestionnaire;
    }//end_method
    //****
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //****
    //- getter for the instantiation of databases
    public function getSessionMasterDBName(){
        return $this->master_session_data_DB;
    }//end_method
    
    
    //- getter for the instantiation of databases
    public function getSessionMasterDB_TableNames(){
        return $this->setOfTablesForMasterSessionData;
    }//end_method
    //****
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        
   
    //--- end of associated arrays -------------------------------------------------------------------
    
 
    //-----constructing the database -----------------------------------------------------------------

    //- getter for the set of possible database names.
    public function getSetOfQuestionnaireDBNames(){
        return $this->setOfQuestionnaireDBNames;
    }//end_method
    
    //-getter for the tables that will go in every database of type 'question' (above)
    public function getSetOfTablesForQuestionnaires(){
        return $this->setOfTablesForEachQuestionnaire;
    }
    //-- parallel arrays for the questionnaire database set up.
    //VVVVVVVV more parallel arrays VVVVVVVV
    
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //****
    //- getter for the: table within each q-database:comments|names of fields 
    public function getSetQuest_Table_Comments_ColNames(){
        return $this->setOfColumnNames_Questionnaire_Table_comments;
    }//end_method
    
    
    //- getter for the: table within each q-database:comments|variable type/variable size
    public function getSetQuest_Table_Comments_VolVarTypes(){
        return $this->setOfColumnVarType_Questionnaire_Table_comments;
    }//end_method
    //****
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    

    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //****
    //- getter for the: table within each q-database:questions|names of fields 
    public function getSetQuest_Table_Questions_ColNames(){
        return $this->setOfColumnNames_Questionnaire_Table_questions;
    }//end_method
    
    
    //- getter for the: table within each q-database:questions|variable type/variable size
    public function getSetQuest_Table_Questions_VolVarTypes(){
        return $this->setOfColumnVarType_Questionnaire_Table_questions;
    }//end_method
    //****
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //****
    //- getter for the: table within each q-database:branch_commands|names of fields
    public function getSetQuest_Table_BranchComands_ColNames(){
        return $this->setOfColumnNames_Questionnaire_Table_branch_commands;
    }//end_method
    
    
    //- getter for the: table within each q-database:branch_commands|variable type/variable size
    public function getSetQuest_Table_BranchComands_VolVarTypes(){
        return $this->setOfColumnVarType_Questionnaire_Table_branch_commands;
    }//end_method
    //****
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //****
    //- getter for the: table within each q-database:session_data|names of fields
    public function getSetQuest_Table_Q_Session_Data_ColNames(){
        return $this->setOfColumnNames_Questionnaire_Session_Data_commands;
    }//end_method
    
    
    //- getter for the: table within each q-database:session_data|variable type/variable size
    public function getSetQuest_Table_Q_Session_Data_VolVarTypes(){
        return $this->setOfColumnVarType_Questionnaire_Session_Data_commands;
    }//end_method
    //****
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //////
    ///// .. end of getters.. that construct the 'question database' and each of their tables.
    /////
    ///// .. below, constructing the unique Database: master_session_data_DB
    /////....................................................................

    // - the name of the database to hold session data
    public function getNameOfMasterSessionDataDB(){
        return $this->master_session_data_DBName;
    }//end_method
    
    // - the table(s) that go into the master session 
    public function getTablesForMasterSessionDB(){
        return $this->setOfTablesForMasterSessionData;
    }//end_method
    
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //****
    //- getter for the: table within each q-database:branch_commands|names of fields
    public function getSetQuest_Table_MasterSession_ColNames(){
        return $this->setOfColumnNames_MasterSession;
    }//end_method
    
    
    //- getter for the: table within each q-database:branch_commands|variable type/variable size
    public function getSetQuest_Table_MasterSession_VolVarTypes(){
        return $this->setOfColumnVarType_MasterSession;
    }//end_method
    //****
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    //******** Here's something unique *********
    
    
    /*
     * getPhoenixArray_Questions()
     * params: none
     * returns: an array of arrays
     * -
     * For every table .. consecutive parallel arrays..
     */
    public function getPhoenixArray_Questions(){
       $retArray = [];
       
       array_push($retArray,$this->setOfColumnNames_Questionnaire_Table_comments,$this->setOfColumnVarType_Questionnaire_Table_comments);
       array_push($retArray,$this->setOfColumnNames_Questionnaire_Table_questions,$this->setOfColumnVarType_Questionnaire_Table_questions);
       array_push($retArray,$this->setOfColumnNames_Questionnaire_Table_branch_commands,$this->setOfColumnVarType_Questionnaire_Table_branch_commands);
       array_push($retArray,$this->setOfColumnNames_Questionnaire_Session_Data_commands,$this->setOfColumnVarType_Questionnaire_Session_Data_commands);
       
       return $retArray;
        
    }//end_method

    
    /*
     * getPhoenixArray_MasterSession()
     * params: none
     * returns: an array of arrays
     * -
     * For every table .. consecutive parallel arrays..
     */
    public function getPhoenixArray_MasterSession(){
        $retArray = [];
        
        array_push($retArray,$this->setOfColumnNames_MasterSession,$this->setOfColumnVarType_MasterSession);
        
        return $retArray;
        
    }//end_method
    
    /*
     * A getter for the initialization set for the master_session_db
     * 
     */
    public function getSetOfInitializationValues_MasterSession(){
        return $this->setOfInitialization_Values_Master_Session;
    }//end_method
    
    
    /*
     * A getter for the initialization fields of the master_session_db
     * 
     */
    public function getSetOfInitializationFields_MasterSession(){
        return $this->setOfInitialization_Fields_Master_Session;
    }//end_method
    /*
     * getMgQuestionnaire()
     * params: none
     * returns: an array 
     * -
     * Synopsis: 
     * Open the file, return it as an array.
     * 
     */
    public function getMgQuestionnaire(){
        $array = File($this->MgDataBaseQ_File);              //All the code needed to open a file!        
        return $array;
    }//end_method
    
    
    /*
     * getVitB9FolicAcidQuestionnaire()
     * params: none
     * returns: an array
     * -
     * Synopsis:
     * Open the file, return it as an array.
     *
     */
    public function getVitB9FolicAcidQuestionnaire(){
        $array = File($this->FolicAcidQ_File);              //All the code needed to open a file!
        return $array;
    }//end_method
    
    /*
     * getVitB12Questionnaire()
     * params: none
     * returns: an array
     * -
     * Synopsis:
     * Open the file, return it as an array.
     *
     */
    public function getVitB12Questionnaire(){
        $array = File($this->VitaminB12Q_File);              //All the code needed to open a file!
        return $array;
    }//end_method
    
    /*
     * getIronFeQuestionnaire()
     * params: none
     * returns: an array
     * -
     * Synopsis:
     * Open the file, return it as an array.
     *
     */
    public function getIronFeQuestionnaire(){
        $array = File($this->IronQ_File);              //All the code needed to open a file!
        return $array;
    }//end_method
    
}//end_class
?>