<?php
/*
 * File: helperClass_FileDump.php
 * -
 * Synopsis:
 * Dump things to .txt files - that way I don't have to rely on attempting to debug through .html/.php
 * -
 * a_bcdef_ghij_klmn_opqr_stuv_wxyz
 * 
 */

class helperClass_FileDump{
    
    
    /*
     * printGETArrayToFile(..)
     * params: $_GET[] array, located through another file.
     * returns: none
     * -
     * Synopsis:
     * Static file name: "w_GET_ArrayAsTxt.txt"
     * https://www.tutorialrepublic.com/faq/how-to-get-the-current-date-and-time-in-php.php#:~:text=Answer%3A%20Use%20the%20PHP%20date,s')%20%2C%20and%20so%20on.
     * 
     */
    function printGETArrayToFile($getArray){
        $fileName = "w_GET_ArrayAsTxt.txt";
        $date = date('m-d-y h:i:s');
        $message = "*******************\n"
                    ."Printing the".'$_GET'. "array"
                    ."Time: ".$date."\n"
                    ."*******************\n";
                    $myfile = fopen($fileName, "w") or die(">>Unable to open file! ".$fileName);
                    //iterate through the question array
                    
       fwrite($myfile, $message);
                    
        foreach($getArray as $line){
            $line.="\n";
            fwrite($myfile, $line);
            }
                    
        fclose($myfile);
        
    }//end_method
    
}//end_class
?>
