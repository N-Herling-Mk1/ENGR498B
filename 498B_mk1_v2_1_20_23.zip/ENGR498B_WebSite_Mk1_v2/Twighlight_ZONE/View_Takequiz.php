<!-- 

File name quizView.php 
-

************************************
* Nathan Herling 
* ENGR 498B, Spring 2023
* The University of Arizona
************************************
-
Notes:
html + php in a .php file.
-->

<!DOCTYPE html>
<html>
<head>
<title>Take the Quiz!</title>
<link rel="stylesheet" type="text/css" href="../css_Files/quizPage.css">
</head>
<body onload=showFirstQuestion()>
<?php 
session_start();
/*
 * session_start() creates a session or resumes the current one based on a session 
 * identifier passed via a GET or POST request, or passed via a cookie. 
 * When session_start() is called or when a session auto starts, 
 * PHP will call the open and read session save handlers.
 */

?>
	<!--************************* Top of the page banner *********************************-->
    <!-- Top Banner -->
	<div class="headerDiv"></div>
	<!--************************* Quiz Dashboard *********************************-->
	<div class="quizDashBoard">
		<div class="quizTitle">Gesund Health - Quiz Dashboard</div>
		<div class="quizCompletionPercentatge">
			<div id="textOnTopOfPercentDone_id" class="textOnTopOfPercentDone">0%&nbsp;done</div>
			<!-- A div for the %BAR (nested divs) -->
			<div id="upDateQuestions" class="PercentBarcontainer">
				<div id="PercentDone" class="PercentDone"></div>
			</div>
		</div>
		<div class="questionStatsText_Answered" id="questionStatsText_Answered_id">
		Questions Answered:&nbsp;0/13
		</div>
		<div class="questionStatsText_Skipped" id="questionStatsText_Skipped_id">
		&nbsp;&nbsp;&nbsp;Questions Skipped:&nbsp;2,3,5 +
		</div>

	
	</div>


	<!--************************* Top of the page buttons *********************************-->
	<!-- A div for [prev] [submit] [next]-->
	<div class="toggleBtnDiv">
		<button type="button" id="getPrevQuestion_Btn" class="toggleBtn_Left" onclick=showCurrentQuestion(this)>last</button>
		<button type="button" id="submit_Btn" class="submitButton" onclick=showCurrentQuestion(this)>submit</button>
		<button type="button" id="getNextQuestion_Btn" class="toggleBtn_Right" onclick=showCurrentQuestion(this)>next</button>
		<!-- the  -->
	</div>
	<!--*********************************************************************************-->

    <!--************************* Progress Bar *******************************************-->
	<!-- A div for text on top of %BAR-->
	<!--*********************************************************************************-->


    <!--************************ Question re-write block*********************************-->
	<!-- Where the questionnaire goes -->
	<div id="masterControlQuizPage">
		<!-- Questions will be generated here.. -->
		<div class="questionFormat" id="questionRewriteDiv"></div>

	</div>
	<!--*********************************************************************************-->
<script>
//The question reWrite block.
var questionReWrite_DIV = document.getElementById("questionRewriteDiv");
var currentQuestion = 0;

function showFirstQuestion() {
	console.log("Bip..");
	showCurrentQuestion("first");
}//end_function


/*
* showCurrentQuestion(element)
* params: element
* returns: none
* -
* Need an AJAX call here to the controller.php
* 
*/
function showCurrentQuestion(element) {
	console.log("You are processing a toggle/submit request.");
	//console.log(typeof(element));		//object
	//console.log(typeof(element.id));	//string
	let getStr="";
	if(typeof(element)==="object"){		//This is here to differentiate between 'string' of the intial state.
		getStr = String(element.id);	//and 'object' of the non-initial state.  If it's an object, I need the string value.
	} else {
		getStr = String(element);
	}
	let ajax = new XMLHttpRequest();
	// Arguments: method (GET) and url with query param(s)
	ajax.open("GET", "../php_Files/controller.php?todo="+getStr);	//sets 'todo', specifically with the value encoded in the element id

		ajax.send();
		let retStr = "";
		// This high order anonymous function will execute when the server responds (a callback)
		ajax.onreadystatechange = function() {
			//for information purposes:
			console.log("State: " + ajax.readyState);
			
			if (ajax.readyState == 4 && ajax.status == 200) {
				console.log("You hit ["+element.id+"] (in the View)");
				//Get the next question from the controller.
				retStr = ajax.responseText;
				//console.log("Here is the inner HTML**: " + retStr);
				//re-write the question div
				questionReWrite_DIV.innerHTML = retStr;

			} else {
				//At the moment, I have no way to test this.
				//I'm assuming \n characters will function as desired and strings work like this...
				//Below does work, but it throws alerts unnecessarily atm.
				//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
			}
		}; // End anonymous high order function
	
}//end_function


/*
* getCurrentRadioVal()
* params: none
* returns: ?
* -
* Synopsis:
* to record and re-write the memory file from the radio button selection.
*
*/
function getCurrentRadioVal(element){
	//console.log("You hit a radio button!"+element.id);
	let retStr = String(element.id);
	console.log("You hit a radio button!"+retStr);
	let ajax = new XMLHttpRequest();
	// Arguments: method (GET) and url with query param(s)
	ajax.open("GET", "../php_Files/controller.php?todo="+retStr);	//sets 'todo', specifically with the value encoded in the element id

		ajax.send();
		//let retStr = "";
		// This high order anonymous function will execute when the server responds (a callback)
		ajax.onreadystatechange = function() {
			//for information purposes:
			console.log("State: " + ajax.readyState);
			
			if (ajax.readyState == 4 && ajax.status == 200) {
				console.log("**RADIO REQUEST**");
				//Get the next question from the controller.
				retStr = ajax.responseText;
				//console.log("Here is the inner HTML**: " + retStr);
				//re-write the question div
				questionReWrite_DIV.innerHTML = retStr;

			} else {
				//At the moment, I have no way to test this.
				//I'm assuming \n characters will function as desired and strings work like this...
				//Below does work, but it throws alerts unnecessarily atm.
				//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
			}
		}; // End anonymous high order function
	
}//end_function

//>>>> will probably be done in the controller with the db itself.
function trackQuestionNumber(element){
	console.log("bip..");
	//console.log(element.id);
	switch(element.id) {
  		case "getPrevQuestion_Btn":
    		console.log(element.id);
    		showCurrentQuestion();
    	break;
  		case "getNextQuestion_Btn":
    		console.log(element.id);
    	break;
    	case "submit_Btn":
    		console.log(element.id);
    	break;
  		default:
    		console.log("#yolo");
		}
}//end_function


//>>>>>>>>>>> For testing >>>>>>>>>>>>>>>>>
function getButtonType(element){
	console.log("bip..");
	//console.log(element.id);
	switch(element.id) {
  		case "getPrevQuestion_Btn":
    		console.log(element.id);
    		showCurrentQuestion();
    	break;
  		case "getNextQuestion_Btn":
    		console.log(element.id);
    	break;
    	case "submit_Btn":
    		console.log(element.id);
    	break;
  		default:
    		console.log("#yolo");
		}
}//end_function
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


/* - Previous function
	alert('view.php under construction');
		let ajax = new XMLHttpRequest();
		// Arguments: method (GET) and url with query param(s)
		ajax.open("GET", "controller.php?todo="+"getQuotes");	//hey, look.  We ARE using GET ?checkBox=" + checkBox

		ajax.send();
		let retStr = "";
		// This high order anonymous function will execute when the server responds (a callback)
		ajax.onreadystatechange = function() {
			//for information purposes:
			console.log("State: " + ajax.readyState);
			if (ajax.readyState == 4 && ajax.status == 200) {
				//This is how we turn a JSON array into a JS array.

				retStr = ajax.responseText;
				console.log("Here is the inner HTML**: " + retStr);

				element.innerHTML = retStr;

			} else {
				//At the moment, I have no way to test this.
				//I'm assuming \n characters will function as desired and strings work like this...
				//Below does work, but it throws alerts unnecessarily atm.
				//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
			}
		}; // End anonymous high order function
*/


</script>

</body>
</html>