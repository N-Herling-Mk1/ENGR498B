<?php 
/*
 * Nathan Herling
 * Inefficiently reopens the file every time and takes the indexed element.
 */
$outputArray = json_decode($_GET ['outputArray']);

$fileName = "../txt_Files/Magnesium_ML_Q_Answers.txt";


//no need to echo, champ.
getGenerateOutput($fileName,$outputArray);

/*
 * getGenerateOutput($fileName,$array)
 * params:
 * returns:
 * -
 * Synopsis:
 * print the contents of the array to a text file of name: $fileName
 * 
 */
function getGenerateOutput($fileName,$array){
    $myfile = fopen($fileName, "w") or die("Unable to open file!");
    echo "here";
    for($i=0;$i<count($array);$i++){
        fwrite($myfile, $array[$i]."\n");
    }//end_for_loop

    fclose($myfile);        //close your f*cking pointer..
    
}//end_method

?>