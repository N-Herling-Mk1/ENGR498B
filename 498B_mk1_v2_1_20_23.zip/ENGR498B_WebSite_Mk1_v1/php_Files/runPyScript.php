<?php
/*
 * 11/21/22
 * Sole purpose: to execute the python file you're passing to it. 
 *
 */
$pyFileToLoad = $_GET ['pyFileToLoad'];
$pyFileToLoad=strval($pyFileToLoad);
$command_Val = 'python ../Python_Files/'.$pyFileToLoad;
$command = escapeshellcmd($command_Val);
shell_exec($command);
?>