<?php 
/*
 * Nathan Herling
 * 11/12/22
 * This .php file will work to 
 * (1) onload - load the pyhton test button page.
 * (2) when I hit the home button - also load (re-load) the python test button page.
 * I just need one method in my .js file.
 * showStartPage()
 * Call it on load, and then attached an event listener to the button.
 */



//That's it.
echo getHomePage().PHP_EOL;


/*
* getHomePage()
* params:
* returns:
* -
* Synopsis
* when you click on the [home] button in pythonTestPage.html
* this reloads the original page.
* lots of hard coding ...
*/ 
function getHomePage(){
	$retStr='';
	$retStr.=   '<div class="gridFormatContainer">'
				.'<div class="grid-container">'
		.'<div class="grid-item"> <div id="getRunPythonBtn1" class="pythonButton" onClick="getPyTest(this)"><br>Test 1</div></div>'
		.'<div class="grid-item"> <div id="getRunPythonBtn2" class="pythonButton" onClick="getPyTest(this)"><br>Test 2</div></div>'
		.'<div class="grid-item"> <div id="getRunPythonBtn3" class="pythonButton" onClick="getPyTest(this)"><br>Test 3</div></div>'
		.'<div class="grid-item"> <div id="getRunPythonBtn4" class="pythonButton" onClick="getPyTest(this)"><br>Test 4</div></div>'
		.'<div class="grid-item"> <div id="getRunPythonBtn5" class="pythonButton" onClick="getPyTest(this)"><br>Test 5</div></div>'
		.'<div class="grid-item"> <div id="getRunPythonBtn6" class="pythonButton" onClick="getPyTest(this)"><br>Test 6</div></div>'
		.'<div class="grid-item"> <div id="getRunPythonBtn7" class="pythonButton" onClick="getPyTest(this)"><br>Test 7</div></div>'
		.'<div class="grid-item"> <div id="getRunPythonBtn8" class="pythonButton" onClick="getPyTest(this)"><br>Test 8</div></div>'
		.'<div class="grid-item"> <div id="getRunPythonBtn9" class="pythonButton" onClick="getPyTest(this)"><br>Test 9</div></div>'
	.'</div>'
	.'</div>';
	return $retStr;
	
}//end_function

?>