<?php

$command = escapeshellcmd('python pyGraphTest1.py');
shell_exec($command);
//$output = shell_exec($command);
//echo $output;
?>