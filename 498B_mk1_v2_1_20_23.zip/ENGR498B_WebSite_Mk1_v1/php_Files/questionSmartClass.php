<?php

require_once './DatabaseAdaptor.php';
class questionSmartClass {
    /*
     * File: questionSmartClass.php
     * ENGR 498B 
     * Nathan Herling
     * The University of Arizona, Spring 2023
     * -
     * A class to handle creating dynamically populated radio button lists.
     * Tasks:
     * (1) Handle unique question selection based off of prev. answers when applicable. 
     * (2) Memory of past questions answered per session.
     * 
     */
    // Properties
    private $db_TextFile_input;
    //
    private $db_IntelliMemory_output;
    private $db_IntelliQBranchInstructions_output;      //hold the branch instrutions per line, or "NA"
    private $db_StoreQuestionOptions;
    //
    private $currentQuestionNumber = 0;
    private $commentArray = [];
    private $questionArray = [];
    private $questionTree = "";
    private $sessionData = [];
    private $dbType="";
    private $smartArray = [];
    private $numberOfQuestions = -1;
    //
    private $errorReport = "../txt_Files/errorReport.txt";
    //private $color;
    
    /*
     * set_dbTextFile(..)
     * params: string
     * retruns: none
     * -
     * Synopsis:
     * sets the datbase name and text file to look in.
     * 
     */
    function set_dbTextFile_SmartClass($db_Name) {
        //echo "<p>In set_dbTextFile_SmartClass</p>";
        //create the error report file:
        switch ($db_Name) {
            case 'Magnesium (Mg)' || 'magnesium':
                //echo "i equals 0";
                $this->db_TextFile_input = "../txt_Files/Mg_Qs_Mk3.txt";
                $this->dbType = "magnesium";
                $this->db_IntelliMemory_output = "../txt_Files/memory_file_"."magnesium".".txt";
                $this->db_IntelliQBranchInstructions_output = "../txt_Files/branchInstruct_file_"."magnesium".".txt";
                $this->db_StoreQuestionOptions = "../txt_Files/optionsToQ_file_"."magnesium".".txt";
                break;
            case 'Vitamin B12' || 'vitaminB12':
                $this->db_TextFile_input = "../txt_Files/VitB12_Qs_Mk2.txt";
                $this->dbType = "vitaminB12";
                $this->db_IntelliMemory_output = "../txt_Files/memory_file_".'vitaminB12'.".txt";
                $this->db_IntelliQBranchInstructions_output = "../txt_Files/branchInstruct_file_"."vitaminB12".".txt";
                $this->db_StoreQuestionOptions = "../txt_Files/optionsToQ_file_"."vitaminB12".".txt";
                break;
            case 'Iron (Fe)'|| 'iron':
                $this->db_TextFile_input = "../txt_Files/Fe_Qs_Mk2.txt";
                $this->dbType = "iron";
                $this->db_IntelliMemory_output = "../txt_Files/memory_file_"."iron".".txt";
                $this->db_IntelliQBranchInstructions_output = "../txt_Files/branchInstruct_file_"."iron".".txt";
                $this->db_StoreQuestionOptions = "../txt_Files/optionsToQ_file_"."iron".".txt";
                break;
            case 'Folic Acid (Vitamin B9)' || 'folicacid':
                $this->db_TextFile_input = "../txt_Files/FolicAcid_Qs_Mk2.txt";
                $this->dbType = "folicacid";
                $this->db_IntelliMemory_output = "../txt_Files/memory_file_"."folicacid".".txt";     
                $this->db_IntelliQBranchInstructions_output = "../txt_Files/branchInstruct_file_"."folicacid".".txt";
                $this->db_StoreQuestionOptions = "../txt_Files/optionsToQ_file_"."folicacid".".txt";
                break;
            default:
                echo "Unexpected db input in: set_dbTextFile(..), File: questionLoadClass.php";
        }
        //echo "The dbText file is set to: ".$this->db_TextFile."\n";
      
        //auto call for convienence?
        $this->getProcessQuestionFile_SmartClass();
    }//end_method
    
    
    /*
     * getProcessQuestionFile_SmartClass()
     * params: none
     * returns: none
     * -
     * Synopsis:
     * call this method after db_TextFile is set.
     * (1) opens the text file
     * (2) splits the text file up according to the first character in the line
     *     '#' -> comment
     *     '$' -> q_tree
     *     ''  -> question
     * https://www.w3schools.com/php/func_string_substr.asp
     * https://www.geeksforgeeks.org/how-to-pop-an-alert-message-box-using-php/
     */
    function getProcessQuestionFile_SmartClass(){
        //File() loads the file as an array.
        //echo "<p>Here(getProcessQuestionFile_SmartClass())</p>";
        $array = File($this->db_TextFile_input);              //All the code needed to open a file!
        for ($i = 0; $i < count($array); $i++) {
            switch(substr($array[$i],0,1)){ //first character;substr(string,start,length)
                case '#':   //A comment
                    array_push($this->commentArray,substr($array[$i],1));
                    break;
                case '$':   //The question tree
                    $this->questionTree = substr($array[$i],1);
                    break;
                case '*':   //A question
                    array_push($this->questionArray,substr($array[$i],1));
                    break;
                    
                default:
                    //I'm thinking - MAYBE create an error class?
                    echo "Error in: questionLoadClass, getProcessQuestionFile()\n";
                    echo 'alert("Error in: questionLoadClass, getProcessQuestionFile()")';
            }
        }
        //Set question number
        $this->numberOfQuestions = count($this->questionArray);
        

    }//end_method
    
    
    
    /*
     * getInitializeIntelliFiles()
     * params: none
     * returns: none
     * -
     * Synopsis:
     * do this at the start of the session, don't call it more than once.
     * 
     */
    function getInitializeIntelliFiles(){
        $myfile = fopen($this->errorReport, "w") or die(">>Unable to open file! ".$this->errorReport);
        fclose($myfile);
        $this->getCreateIntelliMemoryTxtFile();
        $this->getCreateIntelliQuestionBranchTxtFile();
        $this->getCreateIntelliQOptionsTxtFile();
    }//end_method
    
    /*
     * getCreateIntelliMemoryTxtFile()
     * params : none
     * returns: 
     * -
     * Synopsis:
     * Read through the questionArray, the array will look like:
     * Question {A,B,C,D} or Question {A,B,C,D}{E,F,G,H}
     * Ignore the Question.  Take the bracket and format it:
     * {A,B,C,D}{E,F,G,H} -> {0000}{0000}
     * This is to initialize the question memory text file. 
     * NOTE: calls getIntelliMemory_Helper()
     * -
     * $this->questionArray
     * $this->smartArray
     */
    function getCreateIntelliMemoryTxtFile(){
        //Open the file 'new' as 'write' - then close it.
        $myfile = fopen($this->db_IntelliMemory_output, "w") or die(">>Unable to open file! ".$this->db_IntelliMemory_output);
        fclose($myfile);
        //append the new file.
        $myfile = fopen($this->db_IntelliMemory_output, "a") or die(">>Unable to open file! ".$this->db_IntelliMemory_output);
        //iterate through the question array
        foreach($this->questionArray as $question){
            //echo "<p>Here(*)</p>";
            //slice from the first occurence of '{'
            $subStr = substr($question,strpos($question,"{"));
            $fileLine = $this->getIntelliMemory_Helper($subStr);
            $fileLine.="\n";
            fwrite($myfile, $fileLine);
            
        }
        //Print the $localArray to the memory file.
       // echo "<p>Here (getCreateSmartQuestionTxtFile()).</p>";

        fclose($myfile);
    }//end_method
    
    /*
     * getIntelliMemory_Helper()
     * params: none
     * returns: an array.
     * -
     * Synopsis:
     * Handles converting:
     * {A,B,C,D}@{E,F,G,H} -> {0000}{0000}
     * In array form.
     * Note: works with {A,B,C,D}[if=1;1][if=2;2]
     * intelli-question format since I'm counting commas!
     */
    function getIntelliMemory_Helper($stringToProcess){
        $locateIf = strrpos($stringToProcess,"}");
        $stringToProcess = substr($stringToProcess,0,$locateIf+1);
        
        
        echo "<br>[create mem] question: ".$stringToProcess;

        //$numberQOptions = substr_count($stringToProcess,"{");
        $localArray = explode("@",$stringToProcess);
        $retStr="";
        foreach($localArray as $qSetOptions){
            
            $retStr.="{0";
            $numberCommas = substr_count($qSetOptions,",");
            echo "<br>|number of commas:".$numberCommas;
            
            for($i=0;$i<$numberCommas;$i++){
                $retStr.="0";
            }//end_inner_for_loop
            $retStr.="}@";
        }
        $retStr = substr($retStr,0,strlen($retStr)-1);    //remove the last @.
        return $retStr;
    }//end_method
    
    
    /*
     * getCreateIntelliQuestionBranchTxtFile()
     * params:
     * returns:
     * -
     * Synopsis:
     * If the next question in the question array is dispaly dependent upon the prev. question
     * The format will look like:
     * Input:
     * *[1] Are you a biological male, female, or quite possibly Kryptonian?{Male,Female,Kryptonian}$1:<Male>^2:<Female>^3:<Kryptonian>
     * Output:
     * Array([Male],[Female],[Kryptonian])
     * Input:
     * *(2) On average, how many Liters of water do you drink per day?{[less],A,B,C,[more]}@{[less],D,E,F,G,H,[more]}@{Kryptonite-good,Kryptonite-bad}$1:<[less],[more],A,B,C>^2:<D,E,F,G,H>^3:<Kryptonite-good,Kryptonite-bad>
     * Output:
     * Array([[less],[more],A,B,C],[D,E,F,G,H],[Kryptonite-good,Kryptonite-bad])
     */
    function getCreateIntelliQuestionBranchTxtFile(){
        //Open the file 'new' as 'write' - then close it.
        $myfile = fopen($this->db_IntelliQBranchInstructions_output, "w") or die(">>Unable to open file! ".$this->db_IntelliQBranchInstructions_output);
        fclose($myfile);
        //append the new file.
        $myfile = fopen($this->db_IntelliQBranchInstructions_output, "a") or die(">>Unable to open file! ".$this->db_IntelliQBranchInstructions_output);
        //iterate through the question array
        
        
        $this->dumpToTextFile($this->questionArray,"../txt_files/x_error_check.txt");
        
        foreach($this->questionArray as $question){
            $retArr=[];
            echo "<br>Branch-file(0);current-Q:".htmlspecialchars($question)."|END|";
            //echo "<p>Here(-)</p>";
            //slice from the first occurence of '$' - there could be nothing after, but it will always be present.
            if(str_contains($question,"$")){//str_contains(string $haystack, string $needle)
                $subStr = substr($question,strpos($question,"$")+1);
                echo "<br>Branch-file(1):".htmlspecialchars($subStr);
                //Now I have:
                //1:<Male>^2:<Female>^3:<Kryptonian>
                //1:<[less],[more],A,B,C>^2:<D,E,F,G,H>^3:<Kryptonite-good,Kryptonite-bad>
                $tempArr = explode("^",$subStr);
                //Now I have:
                //1:<[less],[more],A,B,C>   2:<D,E,F,G,H>    3:<Kryptonite-good,Kryptonite-bad>
                //Note: they're already in the index order I want.
                for($i=0;$i<count($tempArr);$i++){
                    $tempStr =str_replace("<","",$tempArr[$i]);
                    $tempStr =str_replace(">","",$tempStr);
                    $tempArr2 =  explode(":",$tempStr);
                    echo "<br>Branch file(2):".htmlspecialchars($tempArr2[1]);
                    //Split at :, take index:1, remove first and last characters <>, push into array, done.
                    array_push($retArr,$tempArr2[1]);
                }
            } else {                //if 
                $subStr = "$\n";
                array_push($retArr,$subStr);
            }
            for($i=0;$i<count($retArr);$i++){
                if($i==0){
                    fwrite($myfile,$retArr[$i]);
                }else{
                    $retArr[$i]="|".$retArr[$i];
                    fwrite($myfile,$retArr[$i]);   
                }
            }
            
        }//end_foreach_loop
 
        //Nice to see if it's in the right form, but not the formatted version I want.
        //file_put_contents($this->db_IntelliQBranchInstructions_output, print_r($retArr, true));
        fclose($myfile);
    }//end_method
    
    
    
    
    /*
     * getCreateIntelliQOptionsTxtFile()
     * params:
     * returns:
     * -
     * Synopsis:
     * creates the .txt file that holds the options that are displayed as html.
     * e.g.
     * (1) Blah, this is q 1.${A,B,C)@{E,F,G,H}
     * would print:
     * {A,B,C)@{E,F,G,H}
     * NOTE:
     * WORKS - but, somehow I'm calling it twice.
     */
    function getCreateIntelliQOptionsTxtFile(){
        echo "<br>--Initiallizing Intelligent TextFile_Q_options<br>";
        //Open the file 'new' as 'write' - then close it.
        $myfile = fopen($this->db_StoreQuestionOptions, "w") or die(">>Unable to open file! ".$this->db_StoreQuestionOptions);
        fclose($myfile);
        //append the new file.
        $myfile = fopen($this->db_StoreQuestionOptions, "a") or die(">>Unable to open file! ".$this->db_StoreQuestionOptions);
        //$myfile = fopen($this->db_StoreQuestionOptions, "w") or die(">>Unable to open file! ".$this->db_StoreQuestionOptions);
        
        foreach($this->questionArray as $question){
            //echo "<p>Here(*)</p>";
            //slice from the first occurence of '{'
            $subStr = substr($question,strpos($question,"{"));
            $subStr = substr($subStr,0,strrpos($subStr,"}")+1);
            //$fileLine = $this->getCreateIntelliQOptionsTxtFile_Helper($subStr);
            $subStr.="\n";
            fwrite($myfile, $subStr);
            
        }
        fwrite($myfile, "\n");
        fclose($myfile);
        
    }//end_method
    
    
    /*
     * getCheckIfBranch(..)
     * params: current question number, databaseAdaptor object pointed to current use db
     * returns: none
     * -
     * Synopsis:
     * Inputs the current question number
     * Checks if the question number is branch eligible (>1)
     * The signal for branch is the question containing '$' - checks if prev question contains '$'
     * [once determined]
     * Access the memory file to see what was choosen for the former question.
     * Use this information to show the desired question options.
     * -
     * To perform a branch, you need :
     * (1) the associative array from the prev. question, 
     * (2) the memory from the previous question.
     * (3) and you need to check it against ..the current memory value.?
     * 
     * -
     */
    function getCheckIfBranch($currentQuestionNumber,$theDBA){
        echo "<br>Check Branch";
        if($currentQuestionNumber>1){                           //quetion numbers start at 1.
            $prevQuesNumber = $currentQuestionNumber - 1;
            $prevQuestion = $theDBA->getQuestionGivenNumber($prevQuesNumber);
            echo "<p>Prev Q:".$prevQuestion."</p>";
            
            //Does the previous question contain a branch command?
            if(str_contains($prevQuestion,'$')){                        //'$' is the marker for associative array.
                $this->set_dbTextFile_SmartClass($theDBA->getDBName());
                $memoryFile = $this->db_IntelliMemory_output;
                $memoryFileAsArray = file($memoryFile);
                $lineFromMemFile = $memoryFileAsArray[$prevQuesNumber-1];   //another offset due to question number/array offset
                echo "<p>Prev Question contains branch</p>";      //Works till here, now I need to check memory.

                //echo "Branch Array inst.: ".$this->getBranchCheck_Helper($lineFromMemFile)."<br>";
                return $this->getBranchCheck_Helper($prevQuestion,$lineFromMemFile);
            }
        }

        echo "Branch inst.: 0<br>";
        return 0;
    }//end_method
    
    
    /*
     * getBranchCheck_Helper()
     * params:
     * returns:
     * -
     * Synopsis:
     * if there's a one in a grouping of {}, detect which grouping.
     * Else, return -1 {for error checking}
     * 
     */
    function getBranchCheck_Helper($prevQuestion,$lineFromMemFile){
        //process down to associative array. json_decode()
        //echo "<br>PREV-Q:".$prevQuestion;
        $findChar = strpos($prevQuestion,"$");
        $subStr = substr($prevQuestion,$findChar+1);
        $subStr = trim($subStr, "'");
        $tempArray1 = explode(",",$subStr);
        $tempArray2 = [];
        for($i=0;$i<count($tempArray1);$i++){
            $tempStr = $tempArray1[$i];
            echo "<br>TempStr=".$tempStr;
            $tempStrArray = explode(":",$tempStr);
            //echo "<br>Temp[0]=".strval($tempStrArray[0])."|Temp[1]=".strval($tempStrArray[1]);
            $tempArray2[strval($tempStrArray[0])]=strval($tempStrArray[1]);
        }
        echo "<br>array...";
        print_r($tempArray2);
        echo "<br>Looking at [branch prev mem]".$lineFromMemFile;
        echo "<br>Looking at [branch prev q>>]:".$subStr;
        if(str_contains($lineFromMemFile,"@")){
            $localArray = explode("@", $lineFromMemFile);
            for($i=0;$i<count($localArray);$i++){
                if(str_contains($localArray[$i],"1")){
                    //where it was located and the values.
                    echo "<br>Branch return: ".$i."<br>";
                    return $i;
                }
            }//end_for_loop
        }//end_if
        echo "<br>Branch return: 0<br>";
        return 0;       //else no branch.
    }//end_method
    
    /*
     * getCheckIfMemory()
     * params:
     * $currentQuestionNumber - a number.  the number of the current question
     * $theDBA - a databaseAdapter object
     * returns:
     * -
     * Synopsis:
     * open current mem.txt file
     * go to current question === the line of the file
     * if the line contains a '1', then I need to account for memory
     * else I can print the blank question.
     * -
     * Notes: 
     * Which branch should be decided somewhere else.
     * Here I Just want to process e.g., {001}${000}${000}
     * To this: 001
     * -
     * Notes:
     * https://www.php.net/manual/en/function.file.php
     */
    function getCheckIfMemory($currentQuestionNumber,$theDBA){
        $returnStr="";
        $this->set_dbTextFile_SmartClass($theDBA->getDBName());
        $memoryFile = $this->db_IntelliMemory_output;
        //echo "<p>Current memory file: ".$memoryFile."</p>";
        $memoryFileAsArray = file($memoryFile);
        //print_r($memoryFileAsArray);
        //does the current line contain a '1'
        echo "<br>Memory array:<br>";
        if(str_contains($memoryFileAsArray[$currentQuestionNumber-1],"1")){//the offset is due to array offset, not question offset.
            echo "Memory detected.";
            //error check.
            if(substr_count($memoryFileAsArray[$currentQuestionNumber-1],"1")>1){$this->getCheckErrorPrintToFile("error in memory, more than one 1 detected.");}
            //array_push($returnArray,true);
            $returnStr = $this->getCheckIfMemory_Helper($memoryFileAsArray[$currentQuestionNumber-1]);
            
            //echo print_r($returnArray);
            return $returnStr;
        }else{
            echo "No memory detected.";
            //array_push($returnArray,false);
            //$str = strval($memoryFileAsArray[$currentQuestionNumber-1]);
            //array_push($returnArray,$str);  
            //echo print_r($returnArray);
            //return $returnArray;
        }
        $returnStr = $this->getCheckIfMemory_Helper($memoryFileAsArray[$currentQuestionNumber-1]);
    }//end_method

 
    
    /*
     * getCheckIfMemory_Helper()
     * params: line from the memory file.
     * returns: if more than one {} present, locates where the '1' is, returns integer.
     */
    function getCheckIfMemory_Helper($memoryFileLine){
        $retStr = "";                           //clean it of { and } before you send it back.
        if(str_contains($memoryFileLine,"$")){
            $localArray = explode("$", $memoryFileLine);            
            for($i=0;$i<count($localArray);$i++){
                $retStr = substr($localArray[$i],1);
                $retStr = substr($retStr,0,-2);
                if(str_contains($localArray[$i],"1")){
                //where it was located and the values.
                    echo "<br>[Mem-ret-str]:".$retStr."<br>";
                    return $retStr;
                }
            }//end_for_loop
            //You made it here, so they're both all 0's - return the first one.
            return $retStr;
        }//end_if_statement
        //else-
        $retStr = substr($memoryFileLine,1);
        $retStr = substr($retStr,0,-2);
        echo "<br>[Mem-ret-str]:".$retStr."<br>";
        return $retStr;
    }//end_method
    
    /*
     * getCheckErrorPrintToFile()
     * -
     * Synopsis: attempt to set up an error checking capacity that doesn't rely on printing to webpage.
     */
    function getCheckErrorPrintToFile($message){
        $date = $date = date('m-d-y | h:i:s');
        $date.="\n".$message;
        $myfile = fopen($this->errorReport, "a") or die(">>Unable to open file! ".$this->errorReport);
        fwrite($myfile, $date);
        fclose($myfile);
        
    }//end_method
    
    //$btnFields = $smartClassObject->getButtonFields($actionCase,$currentQuestionNumber,$branchCheck);
    //$catChecked = $smartClassObject->getCatChecked($aBlockOfZeroOnes);
    
    /*
     * branchCheck|memoryCheck |  Action |
     * -----------+------------+---------+
     *     0      |    0       |  ret 0  |
     *     0      |    1       |  ret 1  |
     *     1      |    0       |  ret 2  |
     *     1      |    1       |  ret 3  |
     * -----------+------------+---------+
     */
    
    /*
     * getButtonFields($actionCase,$currentQuestionNumber,$branchCheck)
     * params: $branchNumber needs to be a number.
     * returns: returns the fields to be used for the radio buttons.
     * -
     * Synopsis:
     * Give me the correct branch, please.
     * -
     * Due to lack of foresight in DB design.
     * I'm inputting the entire question.
     * Format Words+words+words{}@{}$'if->then'
     * cut one: {}@{}
     * cut two:[{},{}]
     * cut three (select correct above)
     * cut four: remove({A,B,C},{})
     * cut 5 explode A,B,C based on ,
     * That should be your option array..
     * -
     * getCheckErrorPrintToFile()
     */
    function getButtonFields($currentQuestion,$branchCheck){
        echo "<br>Curr Q: ".$currentQuestion;
        echo "<br>Branch: ".$branchCheck."<br>";
        //from the current database, get the current question. split between first '{' and last '}'
        $sliceOne = strpos($currentQuestion,"{");
        $sliceTwo = strrpos($currentQuestion,"}")-$sliceOne+1;
        
        $subStr = substr($currentQuestion,$sliceOne,$sliceTwo);
        //echo "subStr Two: ".$subStr."<br>";
        $this->getCheckErrorPrintToFile("cut one ".$subStr);
        //from above split at '@'
        $tempArr = [];
        if(str_contains($subStr,"@")){
            $tempArr = explode("@",$subStr);
        }else{
            array_push($tempArr,$subStr);
        }
        //$this->getCheckErrorPrintToFile("cut two ".print_r($tempArr));
        //echo "subStr Three: ".print_r($tempArr)."<br>";
        //select the branch
        //echo "Array Key: ".$branchCheck;
        $subStr = $tempArr[$branchCheck];                     //fucking array offset..
        $this->getCheckErrorPrintToFile("cut three ".$subStr);
        //remove all '}','{'
        $subStr = trim($subStr,"{}");
        $this->getCheckErrorPrintToFile("cut four ".$subStr);
        //create return array.
        $retArray = explode(",",$subStr);
        $this->getCheckErrorPrintToFile("cut five ".$subStr);
        //return the options[branchNumber]
        return $retArray;              //cross you f*cking fingers ... lol.
    }//end_method
    
    
    
    /*
     * getCatChecked($aBlockOfZeroOnes)
     * params : input is e.g. 001 or 000
     * returns: find the location of 1, else return -1     
     * -
     * Where the non-zero is, or -1
     */
    function getCatChecked($aBlockOfZeroOnes){
        echo "(1)Get CatChecked_Str:".$aBlockOfZeroOnes."<br>";
        $locationLocationlocation = strpos($aBlockOfZeroOnes,"1");
        //$sliceTwo = strrpos($aBlockOfZeroOnes,"}")-$sliceOne;
        echo "(2)Get CatChecked loc:".$locationLocationlocation."<br>";
        //$location = strpos($sliceTwo,"1");
        if(!$locationLocationlocation){
            echo "(2)Get CatChecked loc: -1 <br>";
            return -1;
        }
        echo "(2)Get CatChecked loc:".$locationLocationlocation."<br>";
        return $locationLocationlocation;
    }//end_method
    
    /*
     * getCreateIndividualizedRadioBtns($btnSize,$btnFields)
     * params: $catChecked the number of the item that is checked, if the options are in an array; else gives -1.
     * params: $btnFields: array containing the question options.
     * returns:
     * -
     * Synopsis:
     * 
     * Create the radio buttons based off the field names, return the html.
     * <input onclick=getCurrentRadioVal() type="radio" name="radioQ" value="constant" class="radioText" required > Constant <input
     * onclick=getCurrentRadioVal() type="radio" name="radioQ" value="frequent" class="radioText" required> Frequent <input
     * onclick=getCurrentRadioVal() type="radio" name="radioQ" value="infrequent" class="radioText" required> Infrequent <input
     * onclick=getCurrentRadioVal() type="radio" name="radioQ" value="rarely" class="radioText" required> Rarely <input
     * onclick=getCurrentRadioVal() type="radio" name="radioQ" value="never" class="radioText" required> Never
     */
    function getCreateIndividualizedRadioBtns($btnFields, $catChecked){
        echo "Create Radio Buttons<br>";
        echo "Btn fields: ".print_r($btnFields)."<br>";
        echo "cat checked: ".$catChecked."<br>";
        $retStr = "";
        for ($i = 0; $i < count($btnFields); $i ++) {
            if ($i == $catChecked) {
                $retStr .= '<label class="radioText">' . PHP_EOL;
                $retStr .= '<input onclick=getCurrentRadioVal(this) type="radio" id=' . $btnFields[$i] . ' name="radioQ" value=' . $btnFields[$i] . ' checked  class="radiobtnSize" required>';
                $retStr .= $btnFields[$i];
                $retStr .= '</label><br>' . PHP_EOL;
            } else {
                $retStr .= '<label class="radioText">' . PHP_EOL;
                $retStr .= '<input onclick=getCurrentRadioVal(this) type="radio" id=' . $btnFields[$i] . ' name="radioQ" value=' . $btnFields[$i] . ' class="radiobtnSize" required>';
                $retStr .= $btnFields[$i];
                $retStr .= '</label><br>' . PHP_EOL;
            }
        }
        // echo $retStr;
        return $retStr;
    } // end_function
    
    
    /*
     * getCreateQuestionDiv()
     * params: text version of the question
     * returns: html code
     * -
     * Synopsis:
     * takes in the txt version, reWrites a <div>
     * Question comes in looking like:
     * (5) Describe your daily sense of muscle fatigue/tightness.{(1)-None,(2)-Some,(3)-Moderate,(4)-Intense,(5)-Severe}
     */
    function getCreateQuestionDiv($theQuestionItself){
        //split on first ")"+2
        $locOne = strpos($theQuestionItself,")")+2;
        $retStr = substr($theQuestionItself,$locOne);
        //echo "<br>formatted question(1):".$retStr;
        //slice on first "{"+1
        $locTwo = strpos($retStr,"{");
        $retStr = substr($retStr,0,$locTwo);
        //echo "<br>formatted question(2):".$retStr;
        $retStr="<div class='putQuestionTxtHere'>".$retStr."</div>";
       // echo "<br>formatted question: ".$retStr;
        return $retStr;
    }//end_function
    
    /*
     * getQuestOptionBasedOnQnumAndBranch(...)
     * params :
     * returns:
     * -
     * Synopsis
     * Input: currentQuestionNumber : take me to the line in the question memory file
     * branchCheck: in the Q-mem-file, if there is a '@', this tells me which to look in.
     */
    function getQuestOptionBasedOnQnumAndBranch($currentQuestionNumber,$branchCheck,$memoryClue,$theDBA){
        //open the file.
        $this->set_dbTextFile_SmartClass($theDBA->getDBName());     
        //echo "<p>Current memory file: ".$memoryFile."</p>";
        $memoryFileAsArray = file($this->db_StoreQuestionOptions);
        
        $lookAtLine = $memoryFileAsArray[$currentQuestionNumber-1];
        //$memoryClue = str_replace(" ","",$memoryClue);
        echo "<br>Q-options: ".$lookAtLine;
        echo "<br>Mem-clue-: ".strval($memoryClue)."|length|".strlen($memoryClue);;
        //remove all '}' and '{'
        $subStr = str_replace("{","",$lookAtLine);
        $subStr = str_replace("}","",$subStr);
        $subStr = str_replace(" ","",$subStr);
        $subStr = str_replace("\r","",$subStr);
        $subStr = str_replace("\n","",$subStr);
        echo "<br>Substring:".$subStr."<br>";
        if(str_contains("@",$subStr)){           //if the line contains '@', split
            $tempArr=explode("@",$subStr);
            $tempArr2 =explode(",",$tempArr[$branchCheck]);
            $retVal = array_search(strval($memoryClue), $tempArr2);
            //echo "Search Array-<br>";
            print_r($tempArr2)."<br>";
            //$boolVal = substr_compare(strval($memoryClue), $tempArr2[1]);
            //echo "<br>Bool - val:". 
            echo "<br>YES-branch, returning:".$retVal."<br>";
            return $retVal;
        }
        //echo "<br>Substring:".$subStr."<br>";
        $tempArr2 =explode(",",$subStr);
        $retVal = array_search(strval($memoryClue), $tempArr2);
        //$boolVal = strcmp(strval($memoryClue), strval($tempArr2[1]));
        //echo "<br>Arra[1]:".$tempArr2[1]."|length|".strlen($tempArr2[1]);
        //echo "<br>Bool Val:".$boolVal;
        //echo "<br>Search Array::";
        print_r($tempArr2)."<br>";
        echo "<br>NO-branch, returning:".$retVal."|<br>";
        return $retVal;
        
    }//end_method
    
    
    /*
     * getReWriteMemoryFile(..)
     * params :
     * returns:
     * -
     * Synopsis:
     * re-write the memory file.
     * 
     */
    function getReWriteMemoryFile($currentQuestionNumber,$branchCheck,$theDBA,$memLocation){
        //open the file.
        $this->set_dbTextFile_SmartClass($theDBA->getDBName());
        //echo "<p>Current memory file: ".$memoryFile."</p>";
        $memoryFileAsArray = file($this->db_IntelliMemory_output);
        $line = $memoryFileAsArray[$currentQuestionNumber-1];       //offset due to array->questin number
        //rewrite any current information.
        $line = str_replace("1","0",$line);
        echo "<br>Mem init:".$line."|Looking at:".$memLocation;
        if(str_contains("@",$line)){           //if the line contains '@', split
            $tempArr=explode("@",$line);
            $replacementLine = $tempArr[$branchCheck];
            $replacementLine = substr_replace($replacementLine, "1", $memLocation+1,1);
            echo "<br>Branch new mem:".$replacementLine;
        }
        $replacementLine = substr_replace($line, "1", $memLocation+1,1);
        echo "<br>No-Branch new mem:".$replacementLine;
        $memoryFileAsArray[$currentQuestionNumber-1] = $replacementLine;

        $myfile = fopen($this->db_IntelliMemory_output, "w") or die(">>Unable to open file! ".$this->db_IntelliMemory_output);
        fclose($myfile);
        $myfile = fopen($this->db_IntelliMemory_output, "a") or die(">>Unable to open file! ".$this->db_IntelliMemory_output);
        
        
        foreach($memoryFileAsArray as $question){
            fwrite($myfile, $question);
        }

        fclose($myfile);
                
    }//end_method
    
    /*
     * getDBComments()
     * params: none
     * returns: the array of extracted comments from the .txt file.
     *
     */
    function getDBComments(){
        //echo ">>You are in: getDBComments()\n";
        //echo print_r($this->commentArray());
        //echo count($this->commentArray)."\n";
        //echo "<<\n";
        return $this->commentArray;
    }//end_method
    
    
    /*
     * getDBQuestions()
     * params: none
     * returns: the array of extracted questions from the .txt file.
     */
    function getDBQuestions(){
        return $this->questionArray;
    }//end_method
    
    
    /*
     * getSessionData()
     * params: none
     * returns: the array with elements of meta info [$metaInfo]
     * -
     * Synopsis:
     * session_data (q_type varchar(63),            $this->dbType
     *               q_tree varchar(255),           $this->questionTree
     *               total_q INT(63),               $this->numberOfQuestions
     *               curr_q  INT(63));              starts at 1, with bounds on increment/decrement.
     */
    function getSessionData(){
        array_push($this->sessionData,$this->dbType);
        array_push($this->sessionData,$this->questionTree);
        array_push($this->sessionData,$this->numberOfQuestions);
        array_push($this->sessionData,'1');
        return $this->sessionData;
    }//end_method
    
    
    //Used for checking to see if I could 'talk to' the class.
    function get_name() {
        return $this->db_TextFile;
    }//end_method
    

    /*
     * toString()
     * params : none
     * returns: string
     * -
     * Synopsis:
     * To string for all the fields in the class.
     */
    function toString(){
        $retStr="";
        $retStr.="******(to String: begin)******\n".
            "[Comments]\n";
        for($i=0;$i<count($this->commentArray);$i++){
            $number=$i+1;
            $retStr.="[".$number."] ".$this->commentArray[$i];
        }
        
        $retStr.= "\n[q-tree]\n".
            $this->questionTree."\n".
            "[Questions]\n";
            for($i=0;$i<count($this->questionArray);$i++){
                $number=$i+1;
                $retStr.="(".$number.") ".$this->questionArray[$i];
            }
            $retStr.="\n\n[Number of Questions]\n".
                $this->numberOfQuestions."\n";
                $retStr.="*****(to String: end)******\n";
                echo $retStr;
    }//end_method
    
    /*
     * A method that dumps array information to a text file.
     *
     */
    function dumpToTextFile($array,$fileName){
        $myfile = fopen($fileName, "w") or die(">>Unable to open file! ".$fileName);
        for($i=0;$i<count($array);$i++){
           fwrite($myfile,$array[$i]); 
        }
        fclose($myfile);
        
    }//end_function
}//end_class
?>