
<?php

/*
 * ENGR498B
 * Nathan Herling
 * The University of Arizona Spring 2023
 * 
 */
// This class has a constructor to connect to a database. The given
// code assumes you have created a database named 'quotes' inside MariaDB.
//
// Call function startByScratch() to drop quotes if it exists and then create
// a new database named quotes and add the two tables (design done for you).
// The function startByScratch() is only used for testing code at the bottom.
// 
/*
Notes:
All adapted from CSC 337 - final project.
-
I had no idea you could add .html code to a .php page... in the beginning.. I do now!
Notes (W15-HW2):
[things added]
[x] htmlspecialchars($str)
[x] bindParam  https://www.php.net/manual/en/pdostatement.bindparam.php
[x] if user pw is involved use a hash function: password_hash(), and password_verify() to decode/match.
 */
include '../php_Files/questionLoadClass.php';


class DatabaseAdaptor {
  private $DB; // The instance variable used in every method below
  private $DATA_BASE_NAME; //= 'magnesium';//options: 'magnesium', 'iron', 'folicacid', 'vitaminB12'
  //private $questionLoad = new questionLoadClass();
  
  // Connect to an existing data based named 'quotes'
  public function __construct() {
//     $this->setDBName($dbName);
//     $dataBase ='mysql:dbname='.strval($this->DATA_BASE_NAME).';charset=utf8;host=127.0.0.1';       //<--- name has already been changed.
//     $user ='root';                                                      //when the DB doesn't exist - you get
//     $password =''; // Empty string with XAMPP install                   //via CLI
//     try {                                                               //Error establishing Connection
//         $this->DB = new PDO ( $dataBase, $user, $password );
//         $this->DB->setAttribute ( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
//     } catch ( PDOException $e ) {
//         echo ('Error establishing Connection');
//         exit ();
//     }
//     $this->getPopulateDB();
  }//end_constructor
  
  
  //create db with inputted name.
  //From the controller this is called via the page: populateAdBase.php
  //This is used to create the database from the information encoded in the .txt file.
  //This sets the CURRENT dbName, meaning: as the .txt file is processed the class field: $this->DATA_BASE_NAME
  //should be the correct db to use.
  /*
   * Call this to create/re-create from scratch.
   * 
   */
  public function getCreateDB($dbName){
      $this->setDBName($dbName);
      //echo "Opening DB name: ".$this->DATA_BASE_NAME."\n";
      $dataBase ='mysql:dbname='.strval($this->DATA_BASE_NAME).';charset=utf8;host=127.0.0.1';       //<--- name has already been changed.
      $user ='root';                                                      //when the DB doesn't exist - you get
      $password =''; // Empty string with XAMPP install                   //via CLI
      try {                                                               //Error establishing Connection
          $this->DB = new PDO ( $dataBase, $user, $password );
          $this->DB->setAttribute ( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
      } catch ( PDOException $e ) {
          echo ('Error establishing Connection');
          echo ($e);
          exit ();
      }
      $this->getPopulateDB();
  }//end_method

  
  /*
   * getOpenDB()
   * params: see setDBName(..) for how to select proper name.
   * returns: none
   * -
   * Synopsis: differs from 'getCreateDB(..)' 
   * Assumes everything is alread made and we just need to start a new session.
   */
  public function getOpenDB($dbName){
      $this->setDBName($dbName);
      //echo "Opening DB name: ".$this->DATA_BASE_NAME."\n";
      $dataBase ='mysql:dbname='.strval($this->DATA_BASE_NAME).';charset=utf8;host=127.0.0.1';       //<--- name has already been changed.
      $user ='root';                                                      //when the DB doesn't exist - you get
      $password =''; // Empty string with XAMPP install                   //via CLI
      try {                                                               //Error establishing Connection
          $this->DB = new PDO ( $dataBase, $user, $password );
          $this->DB->setAttribute ( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
      } catch ( PDOException $e ) {
          echo ('Error establishing Connection');
          echo ($e);
          exit ();
      }  
  }//end_method
  
  
  
  
  
  //getter for db name.
  public function getDBName(){
      return $this->DATA_BASE_NAME;
  }//end_method

   //set the db name.
  public function setDBName($dbName){
      //echo "In: setDBName val=".$dbName."\n";
      switch ($dbName) {
          case 'Magnesium (Mg)':
              //echo "i equals 0";
              $this->DATA_BASE_NAME="magnesium";
              break;
          case 'Vitamin B12':
              $this->DATA_BASE_NAME="vitaminB12";
              break;
          case 'Iron (Fe)':
              $this->DATA_BASE_NAME="iron";
              break;
          case 'Folic Acid (Vitamin B9)':
              $this->DATA_BASE_NAME="folicacid";
              break;
          default:
              echo "Unexpected db input in: setDBName(..), File: DatabaseAdaptor.php";
      }
      
      //echo "DB name set to: ".$this->DATA_BASE_NAME."\n";
  }//end_method
  
  ///// area for 498B /////
// This function exists only for testing purposes. Do not call it any other time.
//********************************
// The function Rick gave us [well, method, I think...]
//12/28/22 --- attempting to heavily modify..
//********************************
/* 12/28/22 --- attempting to heavily modify..
 * 
 *OK, should work for 'as of 1/2/23' formatting...
 *
 */
public function startFromScratch() {
  $stmt = $this->DB->prepare("DROP DATABASE IF EXISTS ".strval($this->DATA_BASE_NAME).";");        //Drop magnesium
  $stmt->execute();
       
  // This will fail unless you created database magnesium inside MariaDB.
  $stmt = $this->DB->prepare("create database ".strval($this->DATA_BASE_NAME).";");                //re-create magnesium
  $stmt->execute();

  $stmt = $this->DB->prepare("use ".strval($this->DATA_BASE_NAME).";");                                //switch to quotes
  $stmt->execute();
        
  //Creates the Table 'comments'
  //with the fields: line, comment
  $update = " CREATE TABLE comments ( " .
            " line INT(20), comment varchar(1023));";       
  $stmt = $this->DB->prepare($update);
  $stmt->execute();
                
  //Creates the Table 'questions'
  //with the fields: number, question 
  $update = "CREATE TABLE questions ( ". 
            "number INT(63), question varchar(1023));";    
  $stmt = $this->DB->prepare($update);
  $stmt->execute();

  //Creates the Table 'session_data'
  //with the fields: q_tree
  $update = "CREATE TABLE session_data ( ".
      "q_type varchar(63),".
      "q_tree varchar(255),".
      "total_q INT(63),".
      "curr_q INT(63));";
  $stmt = $this->DB->prepare($update);
  $stmt->execute();
}//end_function
    

///// area for 498B /////
/*
 * getPopulateDB()
 * params: none
 * returns: none
 * -
 * Synopsis:
 * (1) open up the questionnaire file [via nested function call with switch statement].
 * (2) parse the components via #,$,'' -> put them into arrays.
 * (3) store these into their correct DB components.
 * 
 */
public function getPopulateDB(){
    $this->startFromScratch();
    $questionLoad = new questionLoadClass();
    $questionLoad->set_dbTextFile($this->DATA_BASE_NAME);
    //echo $questionLoad->get_name();
    $questionLoad->getProcessQuestionFile();        //This is called to split the questionnaire into components inside: $questionLoad
    //$questionLoad->toString();                    //<<---- WE ARE HERE! !! !
    //populate the comment table
    $this->getPopulateDBComments($questionLoad->getDBComments());
        
    //populate the questions table
    $this->getPopulateDBQuestions($questionLoad->getDBQuestions());
    //populate the session_data table
    $this->getPopulateDBSessionInfo($questionLoad->getSessionData());
    
    //show some info.
    //echo $questionLoad->toString();//->get_name();
}//end_function



///// area for 498B /////
/*
 * getPopulateDBComments(..)
 * params: An array containing comments loaded in from the .txt file
 * returns: none
 * -
 * Synopsis:
 * From an object of type: questionLoadClass, the comments are extracted
 * Then, sent here to be put into the database.
 * (1) account for current db - should be done with the DB constructor via the controller.
 * (2) for each line in the comment array, add to the table: comments.
 * (3) sanitize the input, remove new line and return characters.
 * (4) bind the params.  all-though I'm not certain what that means, atm - it's some sort of security feature. 
 * Note: removing return and new line chars
 * https://thisinterestsme.com/php-remove-newlines/
 */
public function getPopulateDBComments($commentArray){
    
    $line = "";
    $comment = "";
    $currentDBtable = 'comments';
    
    for($i=0;$i<count($commentArray);$i++){
        $line = strval($i+1);
        //$line = str_replace("\n",'', $line);
        $line = htmlspecialchars($line);
        $comment = strval($commentArray[$i]);
        //$comment = str_replace("\n",'', $comment);
        //$comment = htmlspecialchars($comment);
        //$comment = filter_var($comment, FILTER_SANITIZE_STRING);
        $comment = htmlspecialchars(str_replace(array("\n","\r"),'', $comment));
        //echo "Here is the current comment line: ".$comment."\n";
            //
        $searchString="INSERT INTO ".$currentDBtable." (line, comment) ".
                "VALUES (:line_, :comment_)";
        //echo "Here is the command we made:".$searchString."\n";           //---- debugging
            //strval($quote)
            //strval($author)
            //(1)
        $stmt = $this->DB->prepare($searchString);
            //(1b)
        $stmt->bindParam(':line_',$line);
        $stmt->bindParam(':comment_',$comment);
            //(2)
        $stmt->execute();
        $line = "";
        $comment = "";
    }
        //(3)
    //$stmt->fetchAll(PDO::FETCH_ASSOC);    //I don't think I need the 'fetchAll'
    //I don't think I need this...
    //return $stmt->fetchAll(PDO::FETCH_ASSOC);
    
}//end_function


/*
 * getPopulateDBQuestions(..)
 * params: none
 * returns: none
 * -
 * Synopsis:
 * From an object of type: questionLoadClass, the questions are extracted
 * Then, sent here to be put into the database.
 * (1) account for current db - should be done with the DB constructor via the controller.
 * (2) for each line in the comment array, add to the table: questions.
 * (3) sanitize the input, remove new line and return characters.
 * (4) bind the params.  all-though I'm not certain what that means, atm - it's some sort of security feature. 
 * Note: removing return and new line chars
 * https://thisinterestsme.com/php-remove-newlines/
 */
 public function getPopulateDBQuestions($questionArray){
    
    $number = "";
    $question = "";
    $currentDBtable = 'questions';
    
    for($i=0;$i<count($questionArray);$i++){
        $number = strval($i+1);
        //$line = str_replace("\n",'', $line);
        $number = htmlspecialchars($number);
        $question = strval($questionArray[$i]);
        //$comment = str_replace("\n",'', $comment);
        //$comment = htmlspecialchars($comment);
        //$comment = filter_var($comment, FILTER_SANITIZE_STRING);
        $question = htmlspecialchars(str_replace(array("\n","\r"),'', $question));
        //echo "Here is the current question line: ".$question."\n";
        //
        $searchString="INSERT INTO ".$currentDBtable." (number, question) ".
            "VALUES (:number_, :question_)";
        //echo "Here is the command we made:".$searchString."\n";           //---- debugging
        //strval($quote)
        //strval($author)
        //(1)
        $stmt = $this->DB->prepare($searchString);
        //(1b)
        $stmt->bindParam(':number_',$number);
        $stmt->bindParam(':question_',$question);
        //(2)
        $stmt->execute();
        $number = "";
        $question = "";
    }
    
}//end_fuction

/*
 * getPopulateDBSessionInofo(..)
 * params: An array containing the session information
 * returns: none
 * -
  * From an object of type: questionLoadClass, the questions are extracted
 * Then, sent here to be put into the database.
 * (1) account for current db - should be done with the DB constructor via the controller.
 * (2) for each line in the comment array, add to the table: questions.
 * (3) sanitize the input, remove new line and return characters.
 * (4) bind the params.  all-though I'm not certain what that means, atm - it's some sort of security feature. 
 * -
 * session_data( q_type varchar(63),
 *               q_tree varchar(255),
 *               total_q INT(63),
 *               curr_q INT(63)));
 * Note: removing return and new line chars
 * https://thisinterestsme.com/php-remove-newlines/
 */  
public function getPopulateDBSessionInfo($sessionArray){
    //Session array will have 4 elements, each of which is a column for one table entry.
    $q_type="";
    $q_tree="";
    $total_q="";
    $curr_q="";
    $currentDBtable = 'session_data';
    //
    $q_type = $sessionArray[0];
    $q_tree = $sessionArray[1];
    $total_q = $sessionArray[2];
    $curr_q = $sessionArray[3];
    //$curr_q = '3';
    //        $comment = htmlspecialchars(str_replace(array("\n","\r"),'', $comment));
    $q_type = htmlspecialchars(str_replace(array("\n","\r"),'', $q_type));
    $q_tree = htmlspecialchars(str_replace(array("\n","\r"),'', $q_tree));
    $total_q = htmlspecialchars($total_q);
    $curr_q = htmlspecialchars($curr_q);
    //
    //
    $searchString="INSERT INTO ".$currentDBtable." (q_type, q_tree, total_q, curr_q) ".
        "VALUES (:q_type_, :q_tree_, :total_q_, :curr_q_)";
    //echo "Here is the command we made:".$searchString."\n";           //---- debugging
    //strval($quote)
    //strval($author)
    //(1)
    $stmt = $this->DB->prepare($searchString);
    //(1b)
    $stmt->bindParam(':q_type_',$q_type);
    $stmt->bindParam(':q_tree_',$q_tree);
    $stmt->bindParam(':total_q_',$total_q);
    $stmt->bindParam(':curr_q_',$curr_q);
    //(2)
    $stmt->execute();
    
    
}//end_function


///// area for 498B /////

/*
 * getSwitchCurrDB(..)
 * params: the name of the desired database.
 * returns: none
 * -
 * Synopsis:
 * switches to the database name in the param.
 */
public function getSwitchCurrDB($DB_TO_USE){
    //echo "In DB TO USE>>\n";
    //echo $DB_TO_USE."\n";
    $searchString="USE ".$DB_TO_USE.";";
    $searchString = htmlspecialchars(str_replace(array("\n","\r"),'', $searchString));
    //echo "Our string|".$searchString."|\n";
    
    //(1)
    $stmt = $this->DB->prepare($searchString);
    //(2)
    $stmt->execute();
}//end_function

/*
 * getCurrDBQuestionNumber()
 * params : .. No need to switch db's here - I'll do that in its own method.
 * returns: An array that will contain the 
 * 
 */
public function getCurrDBQuestionNumber(){
    
    //(1) I'll need the session_data
    $searchString = "SELECT curr_q ". 
                    "FROM session_data ".
                    "WHERE q_type='".strval($this->DATA_BASE_NAME)."'";
    //echo "Here is the command we made:".$searchString."\n";     //---- debugging
    //(1)
    $stmt = $this->DB->prepare($searchString);
    //(2)
    $stmt->execute();
    //(3)
    $sessionData = $stmt->fetchAll(PDO::FETCH_ASSOC);
    //echo  "HERE IS session_data: ".gettype($sessionData)."\n";
    //echo "\n".print_r(array_keys($sessionData)); //spits out ([0]=>[0])
    //echo print_r($sessionData);
    //echo "\n>>"."\n";
    //echo $sessionData[0]['curr_q'];     //Whatever-the-fuck thing this is appears to work.
    //echo "\n>>\n";
//     foreach($sessionData as $thing){
//         echo $thing."\n";
//     }
//    $hereWeAre = implode(" ",$sessionData); 
    //(2) I'll use the session_data to get the current question
    //You want [curr_q]
    //$currentQuestion = $sessionData[5];
   // echo $sessionData;
    //(3)
    return strval($sessionData[0]['curr_q']);
}//end_function


/*
 * getQuestionGivenNumber($currentQuestionNumber)
 * params: a string, number representing the question I want to get.
 * returns: a string, the question and its options.
 * -
 * Note: to be 'smart' I'll have to know which option to pick from the list,
 * if more than one option exists.
 */
public function getQuestionGivenNumber($currentQuestionNumber){
    //(1) I'll need the session_data
    $searchString = "SELECT question ".
                    "FROM questions ".
                    "WHERE number='".strval($currentQuestionNumber)."'";
    //echo "Here is the command we made:".$searchString."\n";     //---- debugging
    //(1)
    $stmt = $this->DB->prepare($searchString);
    //(2)
    $stmt->execute();
    //(3)
    $sessionData = $stmt->fetchAll(PDO::FETCH_ASSOC);
    //(3)
    return strval($sessionData[0]['question']);
    
}//end_function


/*
 * get_decrement_QuestionNumberInDB()
 * params : none
 * returns: none
 * -
 * Synopsis:
 * All the bounds checking has been done up front.
 * So, all this needs to do is to lower the question number by 1.
 * 
 */
public function get_decrement_QuestionNumberInDB(){
    //(1) I'll need the session_data
    $searchString = "UPDATE session_data ".
        "SET curr_q=curr_q-1 ".
        "WHERE q_type='".strval($this->DATA_BASE_NAME)."'";
    //echo "Here is the command we made:".$searchString."\n";     //---- debugging
    //(1)
    $stmt = $this->DB->prepare($searchString);
    //(2)
    $stmt->execute();
    
  
}//end_function


/*
 * get_increment_QuestionNumberInDB()
 * params : none
 * returns: none
 * -
 * Synopsis:
 * All the bounds checking has been done up front.
 * So, all this needs to do is to increase the question number by 1.
 *
 */
public function get_increment_QuestionNumberInDB(){
    //echo "<p>In get_increment_QuestionNumberInDB():DatabaseAdaptor.php</p>";
    //(1) I'll need the session_data
    $searchString = "UPDATE session_data ".
        "SET curr_q=curr_q+1 ".
        "WHERE q_type='".strval($this->DATA_BASE_NAME)."'";
    //echo "<p>Here is the command we made:".$searchString."</p>";     //---- debugging
    //(1)
    $stmt = $this->DB->prepare($searchString);
    //(2)
    $stmt->execute();
    
}//end_function

/*
 * function get_totalQNumber_INDB()
 * params: none
 * returns: a string, that is the total number of questions in the current questionnaire.
 * -
 * Synopsis:
 * via the 'session_data' table, the data entry total_q.
 */
public function get_totalQNumber_INDB(){
    //(1) I'll need the session_data
    $searchString = "SELECT total_q ".
        "FROM session_data ".
        "WHERE q_type='".strval($this->DATA_BASE_NAME)."'";
    //echo "Here is the command we made:".$searchString."\n";     //---- debugging
    //(1)
    $stmt = $this->DB->prepare($searchString);
    //(2)
    $stmt->execute();
    //(3)
    $sessionData = $stmt->fetchAll(PDO::FETCH_ASSOC);
    //(3)
    return strval($sessionData[0]['total_q']);
    
    
}//end_function

//////////////////// area for CSC 337///////////////////////////
// Complete these five 'straightfoward' functions and run as a CLI application
// ... as we settle into the 'straightforward' vector Calculus component of the course
// [ha] ...

    /*--------------------------------------------------------- (1/5)
     * getAllQuotations()
     * params: NONE
     * returns: DB query
     * -
     * Synopsis:
     * In the DB 'quotes' - the table 'quotations' - return? idk.
     * This needs a better explanation.  I'll go check the assert statement.
     * OK, addQuote(..,..) is called first and creates things in the
     * quotation table.
     * From problem spec
     * Return a PHP array of all columns in the table quotations
     * ----
     * Week 13 - day 2 modification
     * Put them is descending order by rating.
     * Week 15 - no input chars, no use for (W15-HW2): htmlspecialchars($str)
     * Week 15 - no input param, no bindParam(..)
     */
    public function getAllQuotations() {
        //Does this work in CLI mode? --- yes!
        //echo "You are in: getAllQuotations()\n";                    //---- debugging
        //Construct the SQL command.
        $searchString="SELECT * FROM quotations ";
        $searchString.="ORDER BY rating DESC;";                       //--- add command to order by descending.
        //echo "Here is the command we made:".$searchString."\n";     //---- debugging
        //(1)
        $stmt = $this->DB->prepare($searchString);
        //(2)
        $stmt->execute();
        //(3)
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }//end_function
    
    /*--------------------------------------------------------- (2/5)
     * getAllUsers()
     * params: none
     * returns: DB query
     * -
     * Synopsis:
     * In DataBaseAdaptorTest.php, users are added before this is called.
     * Should return associative array with [user name] and [id]
     * From problem spec
     * Return a PHP array of all columns in table users
     * Week 15 - no string input no need for: htmlspecialchars($str)
     * Week 15 - Week 15 - no input param, no bindParam(..)
     */
    public function getAllUsers(){
        //Does this work in CLI mode? --- yes!
        //echo "You are in: getAllUsers()\n";                           //---- debugging
        //Construct the SQL command.
        $searchString="SELECT * FROM users";
        //echo "Here is the command we made:".$searchString."\n";       //---- debugging
        //(1)
        $stmt = $this->DB->prepare($searchString);
        //(2)
        $stmt->execute();
        //(3)
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }//end_function
    
    /*--------------------------------------------------------- (3/5)
     * addQuote($quote, $author)
     * params: $quote, $author
     * returns: DB query
     * -
     * Synopsis:
     * looks like this: $theDBA->addQuote('one', 'A');
     * From problem spec
     * (1) Insert string $quote to the quotations table with the string 
     *     $author to be the author of the quote. Set rating and flagged 
     *     to default values of 0. The time it field is set to the value now().
     * (2) Do not INSERT anything into the ID column. The first column name after 
     *     INSERT must be added.  The first VALUE should be now(). With auto-increment 
     *     turned on, MariaDB will add the next available unique integer ID automatically. 
     * <<<NOTE:> I discovered that any string entered with an apostrophe ' causes an error>>> [11/22/22]
     * Week 15 - notes
     * htmlspecialchars($str) - since I'm binding to the parameter, I think I need to input the already modified parameter.
     * prepare+bindParam() https://www.php.net/manual/en/pdostatement.bindparam.php (works)
     */
    public function addQuote($quote, $author) {
        //$quote = htmlspecialchars($quote);                                  //---week 15, HW2 requirement - do this at method call to make myself feel better
        //$author = htmlspecialchars($author);                                //---week 15, HW2 requirement -
        //Does this work in CLI mode? --- yes!
        //echo "You are in: addQuote(..,..)\n";                            //---- debugging
        ///echo "You entered:|Quote|".$quote."|Author|".$author."\n";      //---- debugging
        //Construct the SQL command.
        $searchString="INSERT INTO quotations (added, quote, author, rating, flagged) ".
            "VALUES (NOW(),:quote_,:author_,0, 0)";
        //echo "Here is the command we made:".$searchString."\n";           //---- debugging
        //strval($quote)
        //strval($author)
        //(1)
        $stmt = $this->DB->prepare($searchString);
        //(1b)
        $stmt->bindParam(':quote_',$quote);
        $stmt->bindParam(':author_',$author);
        //(2)
        $stmt->execute();
        //(3)
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }//end_function

    /*--------------------------------------------------------- (4/5)
     * addUser($accountname, $psw)
     * params: $accountname, $psw
     * returns: DB query
     * -
     * Synopsis:
     * looks like it adds user,pw
     * $theDBA->addUser("Sammi", "1234");
     * From problem spec
     * Insert a new user to table users. You will need to examine the INSERT in 
     * - function startFromScratch() of DataBaseAdaptor
     * -- note:
     * https://www.w3schools.com/sql/sql_autoincrement.asp
     * Week 15, hw 2
     * (1) htmlspecialchars($str) - I'm doing this where there's a method call - not here since I'm guessing
     *                          'parameter bind' means I'm referencing the original parameters.
     * (2) prepare+bindParam() https://www.php.net/manual/en/pdostatement.bindparam.php [works]
     * (3) salt/hash pw: https://www.php.net/manual/en/function.password-hash.php    
     */
    public function addUser($accountname, $psw){
        //$accountname = htmlspecialchars($accountname);                  //---week 15, HW2 requirement
        //$psw = htmlspecialchars($psw);                                  //---week 15, HW2 requirement
        //Does this work in CLI mode? --- yes!
        //echo "You are in: addUser(..,..)\n";                          //---- debugging
        //echo "You entered: |".$accountname."|".$psw."\n";             //---- debugging
        //Construct the SQL command.
        //$psw = password_hash($psw,PASSWORD_DEFAULT);                    //<<----------------HASH
        $hash = password_hash(htmlspecialchars($psw), PASSWORD_DEFAULT);        //I'm paranoid, atm, re: htmlspecialchars(..)
        //echo "Here is the hashed pw: ".$hash."\n";
        $searchString="INSERT INTO users (username, password)".
                      "VALUES (:accountname_,:hash_)";
        //echo "Here is the command we made:".$searchString."\n";   //---- debugging
        //(1)
        $stmt = $this->DB->prepare($searchString);
        //(1b)
        $stmt->bindParam(':accountname_',$accountname);
        $stmt->bindParam(':hash_',$hash);                           //store the hashed pw.                        
        //(2)
        $stmt->execute();
        //(3)
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }//end_function


    /*--------------------------------------------------------- (5/5)
     * verifyCredentials($accountName, $psw)
     * params: $accountName, $psw
     * returns: DB query
     * -
     * Synopsis:
     * Users and their passwords are added first in the DataBaseAdaptorTest.php file
     * Once added, we can call This method. ..
     * From problem spec
     * return true if the given string $accountName's password matches the given string $psw, 
     * - false if there no match or the user does not exist in table users
     * ******************************
     * Example print off of the associative array.
     * Array
    (
    [0] => Array
        (
            [id] => 1
            [username] => Sammi
            [password] => 1234
        )
    [1] => Array
        (
            [id] => 2
            [username] => Chris
            [password] => abcd
        )
    [2] => Array
        (
            [id] => 3
            [username] => Gabriel
            [password] => abc123
        )
        )
     * Week 15 - hw2
     * htmlspecialchars($str) - I'm doing this where there's a method call - not here since I'm guessing
     *                          'parameter bind' means I'm referencing the original parameters.     
     * (1) bindParam() https://www.php.net/manual/en/pdostatement.bindparam.php
     * (2)prepare+bindParam() https://www.php.net/manual/en/pdostatement.bindparam.php - not needed here as params not used in db call.
     * (3) Get the incoming pw, get the hash value.
     *  - find the account name's hashed pw.
     *  - compare the two (incoming,stored) - both hash values, to determine if accountName matches pw.     
     */
    public function verifyCredentials($accountName, $psw){
        //echo "Input: ".$accountName."|".$psw."\n";
        
        //$accountName = htmlspecialchars($accountName);              //---week 15, HW2 requirement
        //$psw = htmlspecialchars($psw);                              //---week 15, HW2 requirement
        //Does this work in CLI mode? --- yes!
        //echo "You are in: verifyCredentials(..,..)\n";            //---- debugging
        //echo "You entered: |".$accountName."|".$psw."\n";
        //Get the associative array from the command to get all rows in users.
        $searchString="SELECT * FROM users";
        //echo  "Here is the command we made:".$searchString."\n";  //---- debugging
        //(1)
        $stmt = $this->DB->prepare($searchString);
        //(2)
        $stmt->execute();
        //(3)
        $array = $stmt->fetchAll(PDO::FETCH_ASSOC);
        //echo "Here is the table contents:\n";                     //---- debugging
        //echo print_r($array);
        
        //I need the actual (hashed) pw from the user...
        for($i=0;$i<count($array);$i++){
            if($array[$i]['username']===strval($accountName)){
                $hashed_USR_PW = $array[$i]['password'];
                break;
            }
        }
        //check the incoming pw vs. the hashed_USR_PW
        $locVerify = password_verify(htmlspecialchars($psw), $hashed_USR_PW);            //Test if hashes to pw
        //I need to get the user's pw...
        //echo "rev-Hash: ".$locVerify."\n";
        
        //Both conditions have to be true.
        for($i=0;$i<count($array);$i++){
            //if($array[$i]['username']===strval($accountName) AND $array[$i]['password']===strval($psw)){//previous design.
            if($array[$i]['username']===strval($accountName) AND $locVerify){   //new design.
                return true;
            }
        }
        
        return false;
    }//end_function

    
    //   .........................................................................
    //   ........ Week 13 - day 2 Modification + a HAT Week 15 - day 2............  
    //   .........................................................................
    //                        ____
    //                        |  |
    //                        |**|
    //                       ------
    //    ||                  -  -
    //    ||                  0  0
    //  ------                  O
    //  \    /                \_|_/
    //   \  /                   |
    //    \/                  _/ \_

    /* ------------------------------------------- addition (1/2)
     * raiseRating()
     * params: ID [id of the rating from 'quotations' database you want to raise.
     * returns: DB querry.
     * -
     * input an id from the database, will increment the rating by 1 
     * .. updating it in the database..
     * >> SAME 3 steps of DB update >>
     * Week 15, hw 2.
     * (1) htmlspecialchars($str) - done in controller.
     * (2) bindParam() https://www.php.net/manual/en/pdostatement.bindparam.php [works]
     * (3) no pw, no hash
     */
    public function raiseRating($ID){
        //$ID = htmlspecialchars($ID);                                    //---week 15, HW2 requirement
        //echo "You've made it to: raiseRating() ID=".$ID."\n";
        $dbCommand="";
        $dbCommand.="UPDATE quotations ".
                      "SET rating=rating+1 ". 
                      "WHERE id=:ID_";
        //echo "Here is the command [raise] we made:".$dbCommand."\n";   //---- debugging
        //(1)
        $stmt = $this->DB->prepare($dbCommand);
        //(1b)
        $stmt->bindParam(':ID_',$ID);
        //(2)
        $stmt->execute();
        //(3)
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    }//end_function

    /* ------------------------------------------- addition (2/2)
     * lowerRating()
     * params: ID [id of the rating from 'quotations' database you want to lower.
     * returns: DB querry.
     * -
     * input an id from the database, will decrement the rating by 1 
     * .. updating it in the database..
     * >> SAME 3 steps of DB update >>
     * Week 15, hw 2.
     * (1) htmlspecialchars($str) -- done in controller
     * (2) bindParam() https://www.php.net/manual/en/pdostatement.bindparam.php [works]
     * (3) no pw, no hash
     */
    public function lowerRating($ID){
        //$ID=htmlspecialchars($ID);                                      //---week 15, HW2 requirement
        //echo "You've made it to: lowerRating() ID=".$ID."\n";
        $dbCommand="";
        $dbCommand.="UPDATE quotations ".
                    "SET rating=rating-1 ".
                    "WHERE id=:ID_";
        //echo "Here is the command [lower] we made:".$dbCommand."\n";   //---- debugging
        //(1)
        $stmt = $this->DB->prepare($dbCommand);
        //(1b)
        $stmt->bindParam(':ID_',$ID);
        //(2)
        $stmt->execute();
        //(3)
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    }//end_function
    
    /*
     * justProveHere($ID)
     * params: user ID
     * returns: nothing
     * -
     * Synopsis: just echos that you arrived here and were able to pass the $ID.
     * Week 15, hw 2.
     * (1) htmlspecialchars($str) -- no need to do anything; but done here.     
     * (2) bindParam() https://www.php.net/manual/en/pdostatement.bindparam.php [we're good]
     * (3) no pw, no hash            
     */
    public function justProveHere($ID){
        $ID=htmlspecialchars($ID);
        //echo "You're in justProveHere() Here is the ID: ".$ID;      //---week 15, HW2 requirement; why not?
        //echo "<br>";
    }//end_method
    
    
 ////>>>>>>>>>>>>>> QUOTES 3 >>>>>>>>>>>>>>//
 
    /*
     * getRemoveQuote($ID)
     * params:
     * returns: DB query [action of removal]
     * -
     * SYNOPSIS:
     * input the ID of the author whose quote you want to remove.
     * only operates on the database: quotations
     * Week 15, hw 2.
     * htmlspecialchars($str) -- done in controller.
     * bindParam() https://www.php.net/manual/en/pdostatement.bindparam.php [works]
     * 
     */
    public function getRemoveQuote($ID){
        //$ID = htmlspecialchars($ID);                                        //---week 15, HW2 requirement
        //echo "You've made it to: getRemoveQuote($ID) ID=".$ID."<br>";
        $dbCommand="";
        $dbCommand.="DELETE FROM quotations ".
                    "WHERE id=:ID_";
        //echo "Here is the command [lower] we made:".$dbCommand."\n";   //---- debugging
        //(1)
        $stmt = $this->DB->prepare($dbCommand);
        //(1b)
        $stmt->bindParam(':ID_',$ID);
        //(2)
        $stmt->execute();
        //(3)
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    }//end_method
    
}//End_class_DatabaseAdaptor


?>
