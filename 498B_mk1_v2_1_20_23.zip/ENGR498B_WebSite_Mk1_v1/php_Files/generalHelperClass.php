<?php
/*
 * File: generalHelperClass.php
 * 
 * ENGR498A
 * Nathan Herling
 * Spring 2023
 * The University of Arizona
 * -
 * Synopsis:
 * A class to handle error checking/error reporting to be paired with:questionSmartClass.php
 * Notes:
 * At-the-Moment...
 * Let's name all ouput files: x_error_[info].txt
 * They'll populate at the end of the directory then.
 */
class generalHelperClass{
    //Fields
    


    //Methods
    /*
     * getQuestionAndBranchesLogicCheck()
     * params:
     * returns:
     * -
     * Synopsis:
     * Take in the question (e.g.)
     * 
     * Check if the encoded options match the branch options.
     * 
     * Make sure encoded option number matches the branch option number.
     * 
     */
    function getQuestionAndBranchesLogicCheck(){
        
        
    }//end_method
    
    
    /*
     * getPrintFormattedArray_v1($array,$fileName)
     * params:
     * returns:
     * -
     * Synopsis:
     * Takes: Array([[1,2],[a],[e,f,g]])
     * Prints:
     * [1,2],[a],[e,f,g]
     */
    function getPrintFormattedArray_v1($array,$fileName){
        
    }//end_method
    
}//end_class
?>