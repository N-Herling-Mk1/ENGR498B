
<?php
/*
* File: php_openTxtFileRetAsArray.php
*
* ENGR_498B, Spring 2023
* Nathan Herling
* The University of Arizona
* init date: 12/22/2022
* -
* Generic .php file to open a .txt file and return the contents as an array.
*/

//*********** MAIN **********************
//Use the global array Get to define variables passed via the AJAX command.
$inputFile = $_GET ['inputFileName'];

//What I think good code format is:
echo getReturnTxtFileAsArray($inputFile);

//*********** END MAIN ******************

//********************
//    Functions
//********************
//      ||
//      ||
//      ||
//     \\//
//      \/
//********************

/*
 * getReturnTxtFileAsArray($inputFile)
 * params: name of the .txt file to open
 * returns: returns the file as a .php array [have to encode to JSON]
 * -
 * Synopsis:
 * Inputs txt file name.  Opens and reads into .php array, converts to .JSON
 * returns to method call, echo back to the .js file.
 * NOTE:
 * https://code-boxx.com/php-read-file/
 */
function getReturnTxtFileAsArray($inputFile){
    $array = file($inputFile);

    return json_encode($array);
} // end_function
?>