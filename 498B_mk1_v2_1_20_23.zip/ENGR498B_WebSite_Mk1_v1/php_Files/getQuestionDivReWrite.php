<?php
/*
 * Nathan Herling
 * Create individual html radio buttons..?
 */
$catChecked = $_GET['checkBox'];
$btnFields = json_decode($_GET['btnCategories']);
// open the file as an array, return array[$index];

echo getCreateIndividualizedRadioBtns($btnFields, $catChecked);

/*
 * getCreateIndividualizedRadioBtns($btnSize,$btnFields)
 * params:
 * returns:
 * -
 * Synopsis:
 * I really don't need the $btnSize field .. but, work with me here.
 * Create the radio buttons based off the field names, return the html.
 * <input onclick=getCurrentRadioVal() type="radio" name="radioQ" value="constant" class="radioText" required > Constant <input
 * onclick=getCurrentRadioVal() type="radio" name="radioQ" value="frequent" class="radioText" required> Frequent <input
 * onclick=getCurrentRadioVal() type="radio" name="radioQ" value="infrequent" class="radioText" required> Infrequent <input
 * onclick=getCurrentRadioVal() type="radio" name="radioQ" value="rarely" class="radioText" required> Rarely <input
 * onclick=getCurrentRadioVal() type="radio" name="radioQ" value="never" class="radioText" required> Never
 */
function getCreateIndividualizedRadioBtns($btnFields, $catChecked){
    $retStr = "";
    for ($i = 0; $i < count($btnFields); $i ++) {
        if ($i == $catChecked) {
            $retStr .= '<label class="radioText">' . PHP_EOL;
            $retStr .= '<input onclick=getCurrentRadioVal() type="radio" id=' . $btnFields[$i] . ' name="radioQ" value=' . $btnFields[$i] . ' checked  class="radiobtnSize" required>';
            $retStr .= $btnFields[$i];
            $retStr .= '</label><br>' . PHP_EOL;
        } else {
            $retStr .= '<label class="radioText">' . PHP_EOL;
            $retStr .= '<input onclick=getCurrentRadioVal() type="radio" id=' . $btnFields[$i] . ' name="radioQ" value=' . $btnFields[$i] . ' class="radiobtnSize" required>';
            $retStr .= $btnFields[$i];
            $retStr .= '</label><br>' . PHP_EOL;
        }
    }
    // echo $retStr;
    return $retStr;
} // end_function
?>