<?php
/*
 * I think question load's job interact with the DB also.
 * Load in the text file - put its contents in the DB.
 * 
 */
class questionLoadClass {
    // Properties
    private $db_TextFile;
    private $currentQuestionNumber = 0;
    private $commentArray = [];
    private $questionArray = [];
    private $questionTree = "";
    private $sessionData = [];
    private $dbType="";
    private $numberOfQuestions = -1;
    //private $color;
    
    // Using the current database in DatabaseAdaptor.php
    // Set the db_Name here, locally.
    // Then call the method to decide which questionnaire file to open.
    function set_dbTextFile($db_Name) {
        //$this->$db_TextFile = $db_Name;
        //echo "in:set_dbTextFile input Value:".$db_Name."\n";
        switch ($db_Name) {
            case 'magnesium':
                //echo "i equals 0";
                $this->db_TextFile="../txt_Files/Mg_Qs_Mk3.txt";
                $this->dbType = "magnesium";
                break;
            case 'vitaminB12':
                $this->db_TextFile="../txt_Files/VitB12_Qs_Mk2.txt";
                $this->dbType = "vitaminB12";
                break;
            case 'iron':
                $this->db_TextFile="../txt_Files/Fe_Qs_Mk2.txt";
                $this->dbType = "iron";
                break;
            case 'folicacid':
                $this->db_TextFile="../txt_Files/FolicAcid_Qs_Mk2.txt";
                $this->dbType = "folicacid";
                break;
            default:
                echo "Unexpected db input in: set_dbTextFile(..), File: questionLoadClass.php";
        }
        //echo "The dbText file is set to: ".$this->db_TextFile."\n";
    }//end_method
    
    
    /*
     * getProcessQuestionFile()
     * params: none
     * returns: none
     * -
     * Synopsis:
     * call this method after db_TextFile is set.
     * (1) opens the text file
     * (2) splits the text file up according to the first character in the line
     *     '#' -> comment
     *     '$' -> q_tree
     *     ''  -> question
     * https://www.w3schools.com/php/func_string_substr.asp 
     * https://www.geeksforgeeks.org/how-to-pop-an-alert-message-box-using-php/   
     */
    function getProcessQuestionFile(){
        //File() loads the file as an array.
        $array = File($this->db_TextFile);
        for ($i = 0; $i < count($array); $i++) {
            switch(substr($array[$i],0,1)){ //first character;substr(string,start,length)
                case '#':   //A comment
                    array_push($this->commentArray,substr($array[$i],1));
                break;
                case '$':   //The question tree
                    $this->questionTree = substr($array[$i],1);
                break;
                case '*':   //A question
                    //echo "<br>substr($array[$i],1)";
                    array_push($this->questionArray,substr($array[$i],1));
                break;
                
                default:
                    //I'm thinking - MAYBE create an error class?
                    echo "Error in: questionLoadClass, getProcessQuestionFile()\n";
                    echo '<script>alert("Error in: questionLoadClass, getProcessQuestionFile()")</script>';
            }
        }
        //Set question number
        //echo "here.\n";
        //echo "->".$this->numberOfQuestions."\n";
        $this->numberOfQuestions = count($this->questionArray);
        //echo "Number of questions:".$this->numberOfQuestions."\n";
    }//end_method
    
    
    /*
     * getDBComments()
     * params: none
     * returns: the array of extracted comments from the .txt file.
     * 
     */
    function getDBComments(){
        //echo ">>You are in: getDBComments()\n";
        //echo print_r($this->commentArray());
        //echo count($this->commentArray)."\n";
        //echo "<<\n";
        return $this->commentArray;
    }//end_method
    
    
    /*
     * getDBQuestions()
     * params: none
     * returns: the array of extracted questions from the .txt file.
     */
    function getDBQuestions(){
        return $this->questionArray;
    }//end_method
    
    
    /*
     * getSessionData()
     * params: none
     * returns: the array with elements of meta info [$metaInfo]
     * -
     * Synopsis:
     * session_data (q_type varchar(63),            $this->dbType            
     *               q_tree varchar(255),           $this->questionTree
     *               total_q INT(63),               $this->numberOfQuestions
     *               curr_q  INT(63));              starts at 1, with bounds on increment/decrement.
     */
    function getSessionData(){
        array_push($this->sessionData,$this->dbType);
        array_push($this->sessionData,$this->questionTree);
        array_push($this->sessionData,$this->numberOfQuestions);
        array_push($this->sessionData,'1');
        return $this->sessionData;
    }//end_method
    
    //return the current question
    //this will be formatted html in the final version.
//     function currentQuestion(){
//         $retStr=""; //we'll do some html formatting ...
        
//         $retStr = $this->questionArray[$this->currentQuestionNumber];
        
//         echo $retStr;
//     }//end_method
    
    //Used for checking to see if I could 'talk to' the class.
    function get_name() {
        return $this->db_TextFile;
    }//end_method
    
    //Increment the question number.
    //Set a max of number of questions available.
//     function get_increment_QuestionNumber(){
//         //echo "Number of questions:".$this->numberOfQuestions."\n";
//         echo "\nincrementing..\n";
//         echo ($this->currentQuestionNumber < $this->numberOfQuestions);
//         if($this->currentQuestionNumber < $this->numberOfQuestions){
//             $this->currentQuestionNumber++;
//         }
//         $this->get_question_Stats();
//     }//end_method
    
    //Decrement the question number. 
    //Set a min of 0.
//     function get_decrement_QuestionNumber(){
//         echo "\ndecrementing..\n";
//         if($this->currentQuestionNumber>=1){
//             $this->currentQuestionNumber--;
//         }
//         $this->get_question_Stats();
//     }//end_method
    
    
//     function get_question_Stats(){
//         $retStr="";
//         $retStr="\n"."-------"."\nTotal Questions: ".$this->numberOfQuestions.
//                  "\nCurrent Question:  ".$this->currentQuestionNumber."\n"."------"."\n";
//         echo $retStr;
//     }//end_method
    
    /*
     * toString()
     * -
     * Synopsis:
     * prints all the class field values. 
     */
    function toString(){
        $retStr="";
        $retStr.="******(to String: begin)******\n".
                "[Comments]\n";
        for($i=0;$i<count($this->commentArray);$i++){
            $number=$i+1;
            $retStr.="[".$number."] ".$this->commentArray[$i];
        }
        
        $retStr.= "\n[q-tree]\n".
                  $this->questionTree."\n".
                  "[Questions]\n";
        for($i=0;$i<count($this->questionArray);$i++){
            $number=$i+1;
            $retStr.="(".$number.") ".$this->questionArray[$i];
                }
       $retStr.="\n\n[Number of Questions]\n".
                $this->numberOfQuestions."\n";
       $retStr.="*****(to String: end)******\n";             
        echo $retStr;
    }//end_method
    

}//end_class
?>