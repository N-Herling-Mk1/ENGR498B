<?php

/*
 * 11-21-22
 * Nathan Herling
 * Specificially designed for .txt files
 * Reads the file in as an array, encodes it with JSON, sends it back.
 * expects: fileName.txt format.
 */
$fileName = $_GET ['txtfileName'];

$fullPath = "../txt_Files/".$fileName;
//echo "hey..<br>";
//open the file as an array, return array[$index];
$array = File($fullPath);
//print_r($array);
echo json_encode($array);        //that should be it...
?>