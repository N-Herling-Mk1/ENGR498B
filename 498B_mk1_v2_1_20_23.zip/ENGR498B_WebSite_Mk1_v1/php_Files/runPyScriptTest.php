<?php 
/*
 * Nathan Herling
 * WebSite - mk3
 * Works via passing AJAX query parameter from: runPythonTestPage.js
 * <script>alert("Welcome to Geeks for Geeks")</script>
 * $command = escapeshellcmd('python pyGraphTest1.py');
 * shell_exec($command);
 * -
 * Now I need to build a switch statement here based off of the different test inputs.
 */
//------- open and run the python script -----------//..... constitutes 'Test 0' .. just accessing the python script.
$pyFileToLoad = $_GET ['pyFileToLoad'];
$pyFileToLoad=strval($pyFileToLoad);
$command_Val = 'python ../Python_Files/'.$pyFileToLoad;
$command = escapeshellcmd($command_Val);
shell_exec($command);
//------- python script has been run -------------//
//------- code for test whether or not shell runs--//
//$checkVal=shell_exec($command);
//echo getCheckNull($checkVal);
//echo "Running: ".$command_Val;
//echo escapeshellcmd($command_Val);
//-------------------------------------------------//

//[Here we go!] call the decision function
getTestSwitchStatement($pyFileToLoad);
/*
 * getCheckNull($checkVal)
 * params: $checkVal=shell_exec($command);
 * returns: Null/not_null
 * -
 * Works successfully to see if I'm getting something from my file call.
 */
function getCheckNull($checkVal){
    if($checkVal==NULL){
        return "<h1>_NULL</h1>";
    }
    else{
        return "<h1>alert(NOT_NULL)</h1>";
    }
}//end_method

/*
 * getTestSwitchStatement($pyFileToLoad)
 * params: a python test file name.
 * returns: .. nothing atm ... just performs a decision..
 * -
 * Notes: all echo tests worked correctly.
 */
function getTestSwitchStatement($pyFileToLoad){
    
    switch($pyFileToLoad){
        case "pyTest1.py":
            //Here we're going to print to a file, read in the text, print it to the html <div>
            //echo '<h1>'.'test2'.'</h1>';
            getRunTest1("../txt_Files/test2.txt");
            break;
        case "pyTest2.py":
            getRunTest2();
            //Here we're going to create a .png graph, and print the .png [with some formatting] to the html <div>
            //echo '<h1>'.'test3'.'</h1>';
            break;
        case "pyTest3.py":
            //Test 3 will be running some basic pandas code in a python file.
            //print it out to a .csv file
            //read in the .csv file line by line just using <div>..<br>....</div>
            //I'll establish a basic 'how to print' and get some pandas experience.
            getRunTest3();
            //echo '<h1>'.'test4'.'</h1>';
            break;
        case "pyTest4.py":
            //Test 4 will be running some basic pandas code in a python file.
            //Now it's time to start with some ML...?
            //echo '<h1>'.'test4'.'</h1>';
            break;
        case "pyTest5.py":
            //echo '<h1>'.'test5'.'</h1>';
            //Now it's time to start with some ML...?
            break;
        case "pyTest6.py":
            //echo '<h1>'.'test6'.'</h1>';
            break;
        case "pyTest7.py":
            //echo '<h1>'.'test7'.'</h1>';
            break;
        case "pyTest8.py":
            //echo '<h1>'.'test8'.'</h1>';
            break;
        case "pyTest9.py":
            //echo '<h1>'.'test9'.'</h1>';
            break;
        default:
            //Never triggered during testing.
            echo '<h1>'.'error in getTestSwitchStatement(..)'.'</h1>';
    }//end_switch
    
}//end_method


/*
 * getRunTest1()
 * params:
 * returns:
 * -
 * Note: the python script was already run by the time we get here.  [officially test 0 top of code]
 * Synopsis:
 * Opens a .txt file created by a Python script, re-prints the contents to html.
 * f.write("This is pyTest2\nMake this bold\nMake this italicized\put this in a separate div with a border colored blue.")
 */
function getRunTest1($fileName){
    //Load the python file [which should already exist] - into an array.
    $lines = file($fileName);
    //loop through it, creat html code
   $retStr="";
   $retStr.="<p>SIZE:".sizeof($lines)."</p>".PHP_EOL;
   $retStr.= "<p>".$lines[0]."<br>".PHP_EOL;
   $retStr.='<b>'.$lines[1].'</b>'.PHP_EOL;
   $retStr.='<i>'.$lines[2].'</i>'.PHP_EOL;
   $retStr.='<div style="border-style:solid;border-color:blue;">'.$lines[3]."</div>".PHP_EOL;
   $retStr.='</div>'.PHP_EOL;
    
    //echo it back.
    echo $retStr;
}//end_method


/*
 * getRunTest2()
 * params:
 * returns:
 * -
 * Note: the python script was already run by the time we get here.  [officially test 0 top of code]
 * Synopsis:
 * Opens a .png [a graph] made with python, and prints that .png to an html div.
 * <img src="img_girl.jpg" alt="Girl in a jacket" width="500" height="600">
 */
function getRunTest2(){
    $retStr="";
    //Make a nice <div> ... rounded border ... put the .png in there.
    $retStr.='<div style="margin-left:10%;border-style:solid;border-width:5px;border-color:blue;height:700px;width:800px;border-radius:10px;">'.PHP_EOL;
    $retStr.='<p style="text-align:center">Here is a Python graph that was generated with a button push</p>'.PHP_EOL;
    $retStr.='<img src="../Images/theGraph.png" alt="Whoops" width="640" height="480">'.PHP_EOL;
    $retStr.='</div>'.PHP_EOL;
    echo $retStr;
}//end_method


/*
 * getRunTest3()
 * params:
 * returns:
 * Note: the python script was already run by the time we get here.  [officially test 0 top of code]
 * Synopsis:
 * pyTest3.py creates a .csv file, from a pandas dataframe.
 * We're going to:
 * (1) read in the .csv
 * (2) <div> line 1<br> line 2..<br></div>
 * (3) return the html code.
 */
function getRunTest3(){
    $row = 1;
    $entryCount=0;
    if (($handle = fopen("../csv_Files/csvTest1.csv", "r")) !== FALSE) {
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {           //I have no idea what the 1000 means.
            $num = count($data);
            if($row===1){
                $retStr="";
                $retStr.="<div style='font-size:1.5em'>".'<b>The column names in this .csv are:</b><br>';
                for ($c=1; $c < $num; $c++) {                           //Some idea what this does.
                    $retStr.= $c."). ".$data[$c] . "<br>";
                }
                echo $retStr."</div>";
            } else{
                $entryCount++;
                $resetRowNum=$row-2;//adjust back to no offset.
                $numOffset = $num-1;
                echo '<b><span style="color:rgb(187, 175, 59);font-size:1.25em">'.$numOffset.' fields in line ' .$resetRowNum.':</b><br></span>';
            for ($c=1; $c < $num; $c++) {                           //Some idea what this does.
                echo $data[$c] . "<br>";
            }
          }//end_if_else
          echo "<br>".PHP_EOL;
          $row++;
        }//end_while_..
        echo "<p style='border-style:solid;border-width:5px;border-color:blue;font-size:1.5em'><b>**Total entries: ".$entryCount."</b></p>".PHP_EOL;
        fclose($handle);
    }//end_top_if_$handle..
}//end_method

?>


