<!--
File Name: DatabaseAdaptorTest.php
 -->
<?php
/*
 * File Name: DataBaseAdaptorTest.php
 */
/*
************************************
* Nathan Herling
* CSC 337, Fall 2022
* The University of Arizona
* Week 13, HW 1 - also Week 13, HW 2. - Week 14, HW1 - Week 15, HW1. - Week 15, HW2.
* File: DataBaseAdaptorTest.php
* [all files]: controller.php, DatabaseAdaptor.php, DatabaseAdaptorTest.php,
* [n=9      ]  styles.css, view.php, addQuote.php, login.php, logout.php, register.php.
* -
* Call this bad boy for a test, I guess.
* To run: (|>) [green arrow button]
* (|>) > RUN AS > 2 PHP CLI Application.
* CLI: Command Line Interface
* -
* OK, nice.  Good way to test via console.************************************
*/
include 'DatabaseAdaptor.php';
//include 'questionLoadClass.php';

$theDBA = new DatabaseAdaptor();
$theDBA->startFromScratch();              //<--Will erase/re-write data.


echo "You are here.. check via DOS Window if the database looks like you want.\n";
echo "Testing class response..\n";
echo $theDBA->getPopulateDB();
echo "\n>>>>>\n";
//These should pass until I put something into the DB 'quotes'
//$arr = $theDBA->getAllQuotations();
//assert(empty($arr));  // if one of these fail, Rick's startFromScratch is wrong
//$arr = $theDBA->getAllUsers();
//assert(empty($arr));

/*
//--- add the code to make this method---------------------------- do (1/5):(1/5)
$theDBA->addUser("Sammi", "1234");
$theDBA->addUser("Chris", "abcd");
$theDBA->addUser("Gabriel", "abc123");
echo ">>PAST: addUser(..)\n";
///////////>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// -- call the method
$arr = $theDBA->getAllUsers();//---------------------------------- do (2/5):(2/5)
// asserts for: getAllUsers()
assert($arr[0]['username'] === 'Sammi');
assert($arr[0]['id'] == 1);  // Using === can't be used, MariaDB ints are not PHP ints
assert($arr[1]['username'] === 'Chris');
assert($arr[1]['id'] == 2);
assert($arr[2]['username'] === 'Gabriel');
assert($arr[2]['id'] == 3);
echo ">>PASS: getAllUsers()\n";
///////////>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//Create this method: verifyCredentials($name,$pw)---------------- do (5/5):(3/5)
//Looks like it checks for the match between name and id.
//Users and their credentials...
//$theDBA->addUser("Sammi", "1234");
//$theDBA->addUser("Chris", "abcd");
//$theDBA->addUser("Gabriel", "abc123");
//------------------ going to need to change when hash is added? ----------------//
assert($theDBA->verifyCredentials('Sammi', '1234'));        //Pass
assert($theDBA->verifyCredentials('Chris', 'abcd'));        //Pass
assert($theDBA->verifyCredentials('Gabriel', 'abc123'));    //Pass
assert(! $theDBA->verifyCredentials('Huh', '1234'));        //Fail user doesn't exist, pw does.
assert(! $theDBA->verifyCredentials('Sammi', 'xyz'));       //Fall user exists, pw doesn't.
echo ">>PASS: verifyCredentials(.. , ..)\n";
///////////>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


//---------------------------------------------------------------- do (3/5):(4/5)
$theDBA->addQuote('one', 'A');
$theDBA->addQuote('two', 'B');
$theDBA->addQuote('three', 'C');
echo ">>PAST: addQuote()\n";
///////////>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

//---------------------------------------------------------------- do (4/5):(5/5)
$arr = $theDBA->getAllQuotations();
echo "Count: ".count($arr)."\n";
assert(count($arr) == 3);
assert($arr[0]['quote'] === 'one');
assert($arr[0]['author'] === 'A');
// Can't use === because SQL ints are not PHP ints
assert($arr[0]['rating'] == 0);   
assert($arr[0]['flagged'] == 0);
assert($arr[1]['quote'] === 'two');
assert($arr[1]['author'] === 'B');
assert($arr[1]['rating'] == 0);
assert($arr[1]['flagged'] == 0);

// No assert tests for NOW() are possible without some more work
assert($arr[2]['id'] == 3);
assert($arr[2]['author'] === 'C');
assert($arr[2]['quote'] === 'three');
echo ">>PASS: getAllQuotations()\n";
///////////>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

//OK - week 13, day 2 tests..--------------------------- these tests are shite - I don't know why they're not working.
// ----------------------------------------------------- code works through DOS terminal and works through full stack website.
$arr = $theDBA->getAllQuotations();
//TESTING RAISE RANKING..
//print_r($arr);
//echo "Originally: ".$arr[2]['rating']."\n";
//$theDBA->raiseRating('3');
//echo "After: ".$arr[2]['rating']."\n";
//print_r($arr);
//echo "Originally: ".$arr[1]['rating']."\n";
//$theDBA->lowerRating('2');
//echo "After: ".$arr[1]['rating']."\n";

*/
?>