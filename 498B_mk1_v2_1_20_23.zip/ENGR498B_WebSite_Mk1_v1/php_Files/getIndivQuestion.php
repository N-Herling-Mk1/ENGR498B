<?php 
/*
 * Nathan Herling
 * Inefficiently reopens the file every time and takes the indexed element.
 */
$index = $_GET ['index'];

$fileName = "../txt_Files/Questions_magnesium_mk1.txt";

//open the file as an array, return array[$index];
$array = File($fileName);
echo $array[$index];        //that should be it...

?>