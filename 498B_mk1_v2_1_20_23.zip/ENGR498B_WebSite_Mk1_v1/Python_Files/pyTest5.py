"""
Nathan Herling
11/11/2022
Testing basic python functionality.
"""

#Create a method to open a file and write something to the file.
"""

"""
def getWriteToFile():
    print("You are in write-to-file")
    f = open("./Images/demofile2.txt","w")
    f.write("Now the file has more content!")
    f.close()
    
    return 0


# Defining main function
def main():
    print("Test-5 not established yet.")

    #Call this bad-boy    
    getWriteToFile()
  
# Using the special variable 
# __name__
if __name__=="__main__":
    main()
