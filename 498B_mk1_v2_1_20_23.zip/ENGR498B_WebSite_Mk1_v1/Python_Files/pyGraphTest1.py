import matplotlib.pyplot as plt

def getbasicGraph():
    print("getbasicGraph()")
    # x axis values
    x = [1,2,3]
    # corresponding y axis values
    y = [2,4,1]
      
    # plotting the points 
    plt.plot(x, y)
      
    # naming the x axis
    plt.xlabel('x - axis')
    # naming the y axis
    plt.ylabel('y - axis')
      
    # giving a title to my graph
    plt.title('My first graph!')
      
    # function to show the plot
    #plt.show()    
    plt.savefig("../Images/theGraph.png")
    return 0

# Defining main function
def main():
    #Call this bad-boy
    print("You are in pyGraphTest1.py")    
    getbasicGraph()
      
  
# Using the special variable 
# __name__
if __name__=="__main__":
    main()
