"""
11/12/22
ML
Testing pandas.
OK.  worked in basic python.
Let's test it in html environment.
Note - dataframe documentation
https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.to_csv.html
"""
import pandas as pd

# Defining main function
def main():
    print("hey there - test 3")
    #Create a simple dataset of people
    data = {'Name': ["John", "Anna", "Peter", "Linda"],
            'Location': ["New York","Paris","Berlin","London"],
            'Age': [24,13,53,33]
            }
    df_stats1 = pd.DataFrame(data)
    #print(df_stats1.to_string())       #print to terminal.
    df_stats1.to_csv("../csv_Files/csvTest1.csv")
  
# Using the special variable 
# __name__
if __name__=="__main__":
    main()
