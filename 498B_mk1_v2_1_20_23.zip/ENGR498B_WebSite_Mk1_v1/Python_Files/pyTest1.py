"""
Nathan Herling
11/11/2022
Testing basic python functionality.
"""

#Create a method to open a file and write something to the file.
"""

"""
def getWriteToFile():
    print("You are in write-to-file")
    f = open("../txt_Files/test1.txt","w")
    f.write("This is test one. \nSuccessful Test 1 means creation of this text file..")
    f.close()
    
    return 0


# Defining main function
def main():
    print("Test-1 not established yet.")

    #Call this bad-boy    
    getWriteToFile()
  
# Using the special variable 
# __name__
if __name__=="__main__":
    main()
