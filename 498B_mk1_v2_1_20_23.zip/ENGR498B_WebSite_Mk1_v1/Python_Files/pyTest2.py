"""
Nathan Herling
11/11/2022
Testing basic python functionality.
"""

#Create a method to open a file and write something to the file.
"""

"""
def getWriteToFile():
    print("You are in write-to-file")
    f = open("../txt_Files/test2.txt","w")
    f.write("This is pyTest2\nMake this bold\nMake this italicized\nput this in a separate div with a border colored blue.")
    f.close()
    
    return 0


# Defining main function
def main():
    print("Test-2.")

    #Call this bad-boy    
    getWriteToFile()
  
# Using the special variable 
# __name__
if __name__=="__main__":
    main()
