"""
11/21/22
Adding functionality to read in: Magnesium_ML_Q_Answers.txt
This will contain the use case categories:
 'Gender':[1],
 'Daily_H20_Consumption':[5]
 'Daily_Sleep':[3]
 'Intense_Exercise_Weekly_Min':[30],
 'Daily_Sense_Muscle_Fatigue':[5],
 

Adjusting [11/13/22]
Now I'm going to read in the input as ge
******//*************\\****
*****//***************\\****
****//=================\\***
***//Supervised Learning\\**
***\\===================//**
****\\*****************//***
*****\\***************//****
Measuring 4 things for classification:
OUTPUT: 1 of 3 classes
EACH DATAPOINT: its class is called a label.
- in ML -
individual items: samples
their properties: features
---------

n  category
--------------------
1) petal length [cm]............................................. [1.0 - 6.9]
2) petal width  [cm]............................................. [0.1 - 2.5]
3) sepal length [cm]............................................. [4.3 - 7.9]
4) sepal width  [cm]............................................. [2.0 - 4.4]
Belonging to 3 species: setosa, versicolor, or virgincia.   [complete set]
-----------------------------------
Iris plants dataset
--------------------

**Data Set Characteristics:**

    :Number of Instances: 150 (50 in each of three classes)
    :Number of Attributes: 4 numeric, pre
..
------------------------------------
********************************************************************
---<<<<<<<<<<<<<<<--------- Here we are! ----------------------<<<<<<<<<<<<<
Suppose Magnesium
n  category
-------------------
1) hours of sleep per day [hrs] .................................... [4 - 12 ]
2) water consumed day  [L] ......................................... [1 - 5.0]
3) Intense exercise min per week [min] ............................. [0 - 150 ]
4) muscle fatigue....... ...........0:none 5:severe................. [0  to  4 ]
Belonging to 3 categories: low need, moderate need, or severe need.
******************************************************************
"""
#Imports to always include
########################################
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from IPython.display import display
import IPython
import sys
import sklearn as skl
import matplotlib
import scipy as sp
import seaborn as sns
import random
import os
#########################################



"""
* generateGaussian_hrSleepPerDay()
* params:
* returns:
* -
* Synopsis:
* Too little sleep could indicate Mg could be beneficial.
* Units:[Hours]
* Range: [4-12] , mean=8, sigma=1, n=10000000
* Any number less than 7 will trigger:
* 1 Mg need
* else:
* 0 No Mg need
* -
* how to do this:
* https://stackoverflow.com/questions/18441779/how-to-specify-upper-and-lower-limits-when-using-numpy-random-normal
"""
def generateGaussian_hrSleepPerDay():
    print("hrs of sleep")
    lower = 3
    upper = 11     
    mu = 8
    sigma = 1
    N = 10000000

    s = sp.stats.truncnorm.rvs(
          (lower-mu)/sigma,(upper-mu)/sigma,loc=mu,scale=sigma,size=N)
    #s = np.floor(s)
    print("Max",max(s))
    print("Min",min(s))

    #print(s)
    return s


"""
* generateGuassian_waterInLPerDay_men()
* params:
* returns:
* -
* Synopsis:
* Too much water consumption could indicate low Mg levels.
* Units:[Liters]
* Range: [1-4] , mean=3.7, sigma=0.3, n=10000000
* Any number greater than 3.7:
* 1 Mg need
* else:
* 0 No Mg need
* -
* how to do this:
* https://stackoverflow.com/questions/18441779/how-to-specify-upper-and-lower-limits-when-using-numpy-random-normal
"""
def generateGuassian_waterInLPerDay_men():
    print("Liters of water: men")
    lower = 0.5
    upper = 5   
    mu = 3.7
    sigma = 0.25
    N = 10000000

    s = sp.stats.truncnorm.rvs(
          (lower-mu)/sigma,(upper-mu)/sigma,loc=mu,scale=sigma,size=N)
    #s = np.floor(s)
    print("Max",max(s))
    print("Min",min(s))
    return s


"""
* generateGuassian_waterInLPerDay_women()
* params:
* returns:
* -
* Synopsis:
* Too much water consumption could indicate low Mg levels.
* Units:[Liters]
* Range: [1-4] , mean=2.7, sigma=0.3, n=10000000
* Any number greater than 2.7 will trigger:
* 1 Mg need
* else:
* 0 No Mg need
* -
* how to do this:
* https://stackoverflow.com/questions/18441779/how-to-specify-upper-and-lower-limits-when-using-numpy-random-normal
"""
def generateGuassian_waterInLPerDay_women():
    print("Liters of water: women")
    lower = 0.5
    upper = 4   
    mu = 2.7
    sigma = 0.25
    N = 10000000

    s = sp.stats.truncnorm.rvs(
          (lower-mu)/sigma,(upper-mu)/sigma,loc=mu,scale=sigma,size=N)
    #s = np.floor(s)
    print("Max",max(s))
    print("Min",min(s))
    
    return s

"""
* generateGuassian_intenseExerciseMinPerWeek()
* params:
* returns:
* -
* Synopsis:
* Intense exercise can increse urinary and sweat loss of electrolytes.
* Units:[hours]
* Range: [0-150] , mean=75, sigma=0.5, n=10000000
* Any number greater than 75 will trigger:
* 1 Mg need
* else:
* 0 No Mg need
* -
* how to do this:
* https://stackoverflow.com/questions/18441779/how-to-specify-upper-and-lower-limits-when-using-numpy-random-normal
"""
def generateGuassian_intenseExerciseMinPerWeek():
    print("Intense min exercise per week")
    lower = 0
    upper = 150     
    mu = 75
    sigma = 12.5
    N = 10000000

    s = sp.stats.truncnorm.rvs(
          (lower-mu)/sigma,(upper-mu)/sigma,loc=mu,scale=sigma,size=N)
    #s = np.floor(s)
    print("Max",max(s))
    print("Min",min(s))

    return s


"""
* generateGaussian_dailySenseMuscleFatigue()
* params:
* returns:
* -
* Synopsis:
* Mg is a vital mineral in muscle contraction.  Lack of it can
* cause symptoms including muscle fatigue.
* Units:[rubric]
* Range: [1-5] , mean=2.5, sigma=0.5, n=10000000
* Any number greater than 2.5 will trigger:
* 1 Mg need
* else:
* 0 No Mg need
* -
* how to do this:
* https://stackoverflow.com/questions/18441779/how-to-specify-upper-and-lower-limits-when-using-numpy-random-normal
"""
def generateGaussian_dailySenseMuscleFatigue():
    print("Daily sense of muscle fatigue")
    lower = 1
    upper = 5   
    mu = 2.5
    sigma = 0.25
    N = 10000000

    s = sp.stats.truncnorm.rvs(
          (lower-mu)/sigma,(upper-mu)/sigma,loc=mu,scale=sigma,size=N)
    #s = np.floor(s)
    print("Type",type(s))
    print("Max",max(s))
    print("Min",min(s))
    return s


"""
* getCreateDataFrame_1()
* params: all the guassian np arrays I created
* returns: a data frame
* -
* Synopsis:
* Gender|Intense_Exercise_Weekly_Min|Daily_Sense_Muscle_Fatigue|Daily_H20_Consumption|Daily_Sleep <--- column titles
* 
* I want 150 entries.
* For each entry assign a value from the appropriate np array.
* Since the data gets shuffled for the ML, do 50 men then 50 women.
* https://www.geeksforgeeks.org/different-ways-to-create-pandas-dataframe/
* https://www.statology.org/pandas-add-row-to-dataframe/#:~:text=You%20can%20use%20the%20df,loc%5Blen(df.
"""
def getCreateDataFrame_1(gHrsSleep,gH20_men,gH20_wom,gIntExWk,gDailyFat):

    df = pd.DataFrame(columns=['Gender','Intense_Exercise_Weekly_Min',
                               'Daily_Sense_Muscle_Fatigue','Daily_H20_Consumption',
                               'Daily_Sleep','level_of_Mg_Need_encode','level_of_Mg_Need_description'])

    #df.astype({'Gender':'int32'}).dtypes - did not work.
    #test this:
    #print(df)
    #print("Here?-->",gIntExWk[getRI()])

    for i in range(150):
        randyInt = random.randint(0,10000000)
        arg1 = int(1)                    #1 Stands for female.
        arg2 = gIntExWk[randyInt]
        arg3 = gDailyFat[randyInt]
        arg4 = gH20_wom[randyInt]
        arg5 = gHrsSleep[randyInt]
        arg6, arg7 = getDecision(arg1,arg2,arg3,arg4,arg5)

        df.loc[len(df.index)] = [arg1,arg2,arg3,arg4,arg5,int(arg6),str(arg7)] 

    for i in range(150):
        randyInt = random.randint(0,10000000)
        arg1 = int(0)                    #0 stands for male
        arg2 = gIntExWk[randyInt]
        arg3 = gDailyFat[randyInt]
        arg4 = gH20_men[randyInt]
        arg5 = gHrsSleep[randyInt]
        arg6, arg7 = getDecision(arg1,arg2,arg3,arg4,arg5)

        df.loc[len(df.index)] = [arg1,arg2,arg3,arg4,arg5,int(arg6),str(arg7)] 

                                 

    #print(df.to_string())
    return df

"""
getDecision()
* params: gender, exHr, dayFatigue, h20Intake, dailySleep
* returns: one of: low,moderate,high
-
Synopsis:
0/4 - low
1/4 - moderate
2/4 - moderate
3/4 - moderate
4/4 - high
"""
def getDecision(gender, exHr, dayFatigue, h20Intake, dailySleep):

    category = 0                #keep track of the number of categories triggered.
    if(gender==1):              #female
        if(dailySleep<=float(7)):
            category+=1
        if(h20Intake>float(2.7)):
            category+=1
        if(exHr>float(75)):
            category+=1
        if(dayFatigue>2.5):
            category+=1

    if(gender==0):              #male
        if(dailySleep<=float(7)):
            category+=1
        if(h20Intake>float(3.7)):
            category+=1
        if(exHr>float(75)):
            category+=1
        if(dayFatigue>2.5):
            category+=1

    if(category==0):                    #0/4 - low
        return 0, "low" 
    elif(0<category and category<4):    #1/4, 2/4, 3/4 - moderate
        return  1, "moderate"
    else:                               #4/4 - high
        return  2, "high"

    return -1


"""
getTestCase()
params: none
returns: a processed list for the ML test case.
-
This is the format I want...
https://thispointer.com/read-a-text-file-into-string-and-strip-newlines-in-python/
 'Gender':[1],
 'Daily_H20_Consumption':[5]
 'Daily_Sleep':[3]
 'Intense_Exercise_Weekly_Min':[30],
 'Daily_Sense_Muscle_Fatigue':[5],
 ---
 The dictionary I'm returning must have indecies..
 https://www.stechies.com/valueerror-using-scalar-values-must-pass-index/

"""
def getTestCase():
    print("Opening"+str("Magnesium_ML_Q_Answers.txt"))
    # Using readlines()
    Lines = []
    processedLines = []
    with open('../txt_Files/Magnesium_ML_Q_Answers.txt','r') as file:
        text = file.readlines()

    file.close()
    print(text)
    #processedLines=text.split("\n")
    print("Here is what I read: ["+str(len(text))+"]")
    #print(Lines)
    for x in text:
        #print(x.strip())
        processedLines.append(x.strip())

    print(processedLines)
    """
    {'Gender':[1],'Intense_Exercise_Weekly_Min':[30],
                               'Daily_Sense_Muscle_Fatigue':[5],'Daily_H20_Consumption':[5],
                               'Daily_Sleep':[3]}
    """
    
    gender = getMatch_MLDF_toTextFile_Gender(str(processedLines[0]))
    waterConsumption = getMatch_MLDF_toTextFile_H20_Consumption(str(processedLines[1]),gender)
    dailySleep = getMatch_MLDF_toTextFile_DailySleep(str(processedLines[2]))
    intenseExWeek = getMatch_MLDF_toTextFile_IntenseExMin(str(processedLines[3]))
    dailyFatigue = getMatch_MLDF_toTextFile_DailyFatigue(str(processedLines[4]))
    retStr=""
    retDict={'Gender': [gender],
             'Intense_Exercise_Weekly_Min' :[float(intenseExWeek)],
             'Daily_Sense_Muscle_Fatigue' :[int(dailyFatigue)],
             'Daily_H20_Consumption' :[int(waterConsumption)],
             'Daily_Sleep' :[int(dailySleep)]}
    
    return retDict


"""
-------------------------------------------------------------------- (1/5)
getMatch_MLDF_toTextFile_Gender(gender)
params: value from the file for gender
returns: the key [0->F, 1->M]
-
Synopsis: run through if/else return correct value.
eg: Female
"""
def getMatch_MLDF_toTextFile_Gender(gender):
    print("Keying[gender]: "+str(gender))
    if(gender=="Female"):
        print("returning: "+str(0))
        return 0
    else:
        return 1

    return -1

"""
-------------------------------------------------------------------- (2/5)
getMatch_MLDF_toTextFile_H20_Consumption(waterConsumption)
params: value from the file for water consumption
returns: the key [same for both genders]
[less]
1
2
3
4
5
[more]
-
Synopsis: run through if/else return correct value.
eg: 2
"""
def getMatch_MLDF_toTextFile_H20_Consumption(waterConsumption,gender):
    print("Keying[h20]: "+str(waterConsumption)+"| "+str(gender))
    if(waterConsumption=="[less]"):
        print("returning: 0.5") 
        return 0.5
    if(waterConsumption=="[more]" and waterConsumption=="male"):
        print("returning: 6")
        return 6
    if(waterConsumption=="[more]" and waterConsumption=="female"):
        print("returning: 5")
        return 5
    print("returning: "+str(int(waterConsumption)))
    
    return int(waterConsumption)
    
    
"""
-------------------------------------------------------------------- (3/5)
getMatch_MLDF_toTextFile_DailySleep(dailySleepHr)
params: value from the file for dailySleep hours
returns: the key
[less] .. key:3
4 ....... key:4
5 ....... key:5
6 ....... key:6
7 ....... key:6
8 ....... key:7
9 ....... key:8
10 ...... key:10
[more] .. key:11
-
Synopsis: run through if/else return correct value.
eg: 22.5

"""
def getMatch_MLDF_toTextFile_DailySleep(dailySleepHr):
    print("Keying[sleep]: "+str(dailySleepHr))

    if(dailySleepHr=="[less]"):
        print("returning: "+str(3))
        return 3

    if(dailySleepHr=="[more]"): 
       print("returning: "+str(11))
       return 11
    
    print("returning: "+dailySleepHr)
    return int(dailySleepHr)


"""
-------------------------------------------------------------------- (4/5)
getMatch_MLDF_toTextFile_IntenseExMin
params: value from the file for intense exercise min per week
returns: the key
0-15 ..... return 7.5
15-30 .... return 22.5
30-45 .... return 37.5
45-60 .... return 52.5
60-75 .... return 67.5
75-90 .... return 82.5
90-105 ... return 97.5
105-120 .. return 112.5
120-135 .. return 127.5
135-150 .. return 142.5
[more] .. return 150 [max value]

-
Synopsis: run through if/else return correct value.
eg: 22.5
"""
def getMatch_MLDF_toTextFile_IntenseExMin(intenseExMin):
    print("Keying[weekExer]: "+str(intenseExMin))
    
    if(intenseExMin=="0-15"):
        print("returning: ",float(7.5))
        return float(7.5)
    if(intenseExMin=="15-30"):
        print("returning: ",float(22.5))
        return float(22.5)
    if(intenseExMin=="30-45"):
        print("returning: ",float(37.5))
        return float(37.5)
    if(intenseExMin=="45-60"):
        print("returning: ",float(52.5))
        return float(52.5)
    if(intenseExMin=="60-75"):
        print("returning: ",float(67.5))
        return float(67.5)
    if(intenseExMin=="75-90"):
        print("returning: ",float(82.5))
        return float(82.5)
    if(intenseExMin=="90-105"):
        print("returning: ",float(97.5))
        return float(97.5)
    if(intenseExMin=="105-120"):
        print("returning: ",float(112.5))
        return float(112.5)
    if(intenseExMin=="120-135"):
        print("returning: ",float(127.5))
        return float(127.5)
    if(intenseExMin=="135-150"):
        print("returning: ",float(142.5))
        return float(142.5)
    if(intenseExMin=="[more]"):
        print("returning: ",float(150))
        return float(150)

    return -1

"""

-------------------------------------------------------------------- (5/5)
getMatch_MLDF_toTextFile_DailyFatigue(dailyFatigueLevel)
params: value from the file for muscle_fatigue
returns: the key 
(1)-None .... return 1
(2)-Some .... return 2
(3)-Moderate. return 3
(4)-Intense.. return 4
(5)-Severe... return 5
-
Synopsis: run through if/else return correct value.
"""
def getMatch_MLDF_toTextFile_DailyFatigue(dailyFatigueLevel):
    print("Keying[dailyFatigue]: "+str(dailyFatigueLevel))

    if(dailyFatigueLevel=="(1)-None"):
        print("returning: "+str(int(1)))
        return int(1)
    if(dailyFatigueLevel=="(2)-Some"):
        print("returning: "+str(int(2)))
        return int(2)       
    if(dailyFatigueLevel=="(3)-Moderate"):
        print("returning: "+str(int(3)))
        return int(3)   
    if(dailyFatigueLevel=="(4)-Intense"):
        print("returning: "+str(int(4)))
        return int(4)
    if(dailyFatigueLevel=="(5)-Severe"):
        print("returning: "+str(int(5)))
        return int(5)      


"""
getRecordOrganizePrintToFile(recordict)
params: python dictionary
returns: none
-
Synopsis: reads in the results from ML.
Finds the highest percentage scored, and the name associated with it.
Exports those two pieces of data to: MLResults.txt
dictionary looks like:
(string,list)
recordict={'k=1': [.8867,"moderate"],
           'k=2' :[.8867,"low"],
           'k=3' :[.6867,"high"],
           'k=5' :[.9867,"moderate"],
           'k=7' :[.8767,"moderate"]}
"""
def getRecordOrganizePrintToFile(recordict):

    highScore=0.0
    scoreVal=""
    for x,y in recordict.items():
        #print(type(x),type(y))     #(string,list)
        #print(x,y)
        if(y[0]>float(highScore)):
            highScore=y[0]
            scoreVal=y[1]
    highScore = "{:.2f}".format(highScore*100) +"%"
    print("High Values:"+str(highScore)+"|"+str(scoreVal))

    if os.path.exists("../txt_Files/MLResults.txt"):
        os.remove("../txt_Files/MLResults.txt")

    with open('../txt_Files/MLResults.txt', 'w') as f:
        f.write(highScore)
        f.write("\n")
        f.write(scoreVal)
    f.close()
    print("Results written to: '../txt_Files/MLResults.txt'")
    return -1

# Defining main function
def main():
    getTestCase()
    #Call these bad-boys
    #These represent the continuous data I'm going to use to train my model.
    gHrsSleep = generateGaussian_hrSleepPerDay()
    gH20_men = generateGuassian_waterInLPerDay_men()
    gH20_wom = generateGuassian_waterInLPerDay_women()
    gIntExWk = generateGuassian_intenseExerciseMinPerWeek()
    gDailyFat = generateGaussian_dailySenseMuscleFatigue()

    df1 = getCreateDataFrame_1(gHrsSleep,gH20_men,gH20_wom,gIntExWk,gDailyFat)
    print(df1.to_string())
    #ok, let's do some ML
    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test =\
                    train_test_split(df1[['Gender','Intense_Exercise_Weekly_Min',
                               'Daily_Sense_Muscle_Fatigue','Daily_H20_Consumption',
                               'Daily_Sleep']],df1['level_of_Mg_Need_encode'],random_state=0)

    y_train = y_train.astype('int')
    y_test = y_test.astype('int')    
    #-check the types of data in the columns
    results=df1.dtypes
    print(results)

    #examining output shape
    print("X_train type:",type(X_train))
    print("y_train type:",type(y_train))

    #
    print("X_train shape:",X_train.shape)
    print("y_train shape:",y_train.shape)
    

    #
    print("X_train:\n",X_train.to_string())
    print("y_train:\n",y_train.to_string())
    
    #df2 = pd.DataFrame(X_train,columns=df1.feature_names)
    # create a scatter matrix from the dataframe, color by y_train.

    #pd.plotting.scatter_matrix(df2, c=y_train, figsize=(12,12),
    #                           marker='o', hist_kwds={'bins':20},s=60,
    #                           alpha=.8)
    pd.plotting.scatter_matrix(df1)
    #plt.show()
    plt.savefig("pairPlot_Mk2.png")


   #knn encapsulates: the algorithm that will be used to build the model from the training data
    #as well as the algorithm to make predictions on new data points.  It will also hold all the information
    #that the algorithm has extracted from the training data.
    from sklearn.neighbors import KNeighborsClassifier
    knn1 = KNeighborsClassifier(n_neighbors=1)           #setting n=1
    knn2 = KNeighborsClassifier(n_neighbors=2)           #setting n=2
    knn3 = KNeighborsClassifier(n_neighbors=3)           #setting n=3
    knn5 = KNeighborsClassifier(n_neighbors=5)           #setting n=5
    knn7 = KNeighborsClassifier(n_neighbors=7)           #setting n=7

    #build the model.
    #---- no easy way to get feature importance for k-nearest neighbors
    knn1.fit(X_train,y_train)
    knn2.fit(X_train,y_train)
    knn3.fit(X_train,y_train)
    knn5.fit(X_train,y_train)
    knn7.fit(X_train,y_train)
    
    #suppose you've got some new info.
    
    data1 = {'Gender':[1],'Intense_Exercise_Weekly_Min':[30],
                               'Daily_Sense_Muscle_Fatigue':[5],'Daily_H20_Consumption':[5],
                               'Daily_Sleep':[3]}
    
    data = getTestCase()
    print("Here in main...")
    print(type(data))
    print(data)
    #print("vs.")
    #print(type(data1))
    #print(data1)
    x_new = pd.DataFrame(data) #['Gender','Intense_Exercise_Weekly_Min',
                                         #'Daily_Sense_Muscle_Fatigue','Daily_H20_Consumption',
                                         #'Daily_Sleep']

    #make a prediction..
    prediction1 = knn1.predict(x_new)
    prediction2 = knn2.predict(x_new)
    prediction3 = knn3.predict(x_new)
    prediction5 = knn5.predict(x_new)
    prediction7 = knn7.predict(x_new)

    #I was having difficulty getting the 'below' to work - so, I just did this.
    #No shame in doing it this way?
    predictionKey=['low','moderate','high']
    print("Prediction1:",predictionKey[int(prediction1)])
    print("Prediction2:",predictionKey[int(prediction2)])
    print("Prediction3:",predictionKey[int(prediction3)])
    print("Prediction5:",predictionKey[int(prediction5)])
    print("Prediction7:",predictionKey[int(prediction7)])
    #
    
    

    #--- I think I'd need to structure this differently to get exactly what I
    #--- want.  
    #print("Predicted target name:", df1['level_of_Mg_Need_description'][prediction1])        #Yes, worked.
    #print("Predicted target name:", df1['level_of_Mg_Need_description'][prediction2])        #Yes, worked.
    #print("Predicted target name:", df1['level_of_Mg_Need_description'][prediction3])        #Yes, worked.
    #print("Predicted target name:", df1['level_of_Mg_Need_description'][prediction5])        #Yes, worked.
    #print("Predicted target name:", df1['level_of_Mg_Need_description'][prediction7])        #Yes, worked.
    #How do we know we can trust our model?
    y_pred1 = knn1.predict(X_test)
    percent1=np.mean(y_pred1 == y_test)
    print("Test set score(1): {:.2f}".format(np.mean(y_pred1 == y_test)))
    print("Test set predictions:\n",y_pred1)        #--- just the array
    print("---------")

    #
    y_pred2 = knn2.predict(X_test)
    percent2=np.mean(y_pred2 == y_test)
    print("Test set score(2): {:.2f}".format(np.mean(y_pred2 == y_test)))
    print("Test set predictions:\n",y_pred2)        #--- just the array
    print("---------")
    #
    y_pred3 = knn3.predict(X_test)
    percent3=np.mean(y_pred3 == y_test)
    print("Test set score(3): {:.2f}".format(np.mean(y_pred3 == y_test)))
    print("Test set predictions:\n",y_pred3)        #--- just the array
    print("---------")
    #    
    y_pred5 = knn5.predict(X_test)
    percent4=np.mean(y_pred5 == y_test)
    print("Test set score(5): {:.2f}".format(np.mean(y_pred5 == y_test)))
    print("Test set predictions:\n",y_pred5)        #--- just the array
    print("---------")
    #
    y_pred7 = knn7.predict(X_test)
    percent5=np.mean(y_pred7 == y_test)
    print("Test set score(7): {:.2f}".format(np.mean(y_pred7 == y_test)))
    print("Test set predictions:\n",y_pred7)        #--- just the array
    print("---------")

    #Stats - how many of each kind did I end up with.
    print("********STATS**********")
    print(df1['level_of_Mg_Need_description'].value_counts())


    #************************* RECORD THE RESULTS *************************
    recordict={'k=1': [percent1,predictionKey[int(prediction1)]],
               'k=2' :[percent2,predictionKey[int(prediction2)]],
               'k=3' :[percent3,predictionKey[int(prediction3)]],
               'k=5' :[percent4,predictionKey[int(prediction5)]],
               'k=7' :[percent5,predictionKey[int(prediction7)]]}
    #######################################################################
    print("Here is the dictionary of recorded results:")
    print(recordict)
    getRecordOrganizePrintToFile(recordict)    
    #############################
    #   ||
    #   ||    'This is the end ... Beautiful friend'
    #  ----
    #  \  /
    #   \/
    #==========================>>
    return 0 #-------- end main>>>
    #==========================>>>>
    
  
# Using the special variable 
# __name__
if __name__=="__main__":
    main()
