"""
11/13/22
Machine Learning - Second Application: Classifying Magnesium need.
******//*************\\****
*****//***************\\****
****//=================\\***
***//Supervised Learning\\**
***\\===================//**
****\\*****************//***
*****\\***************//****
Measuring 4 things for classification:
OUTPUT: 1 of 3 classes
EACH DATAPOINT: its class is called a label.
- in ML -
individual items: samples
their properties: features
---------

n  category
--------------------
1) petal length [cm]............................................. [1.0 - 6.9]
2) petal width  [cm]............................................. [0.1 - 2.5]
3) sepal length [cm]............................................. [4.3 - 7.9]
4) sepal width  [cm]............................................. [2.0 - 4.4]
Belonging to 3 species: setosa, versicolor, or virgincia.   [complete set]
-----------------------------------
Iris plants dataset
--------------------

**Data Set Characteristics:**

    :Number of Instances: 150 (50 in each of three classes)
    :Number of Attributes: 4 numeric, pre
..
------------------------------------
********************************************************************
---<<<<<<<<<<<<<<<--------- Here we are! ----------------------<<<<<<<<<<<<<
Suppose Magnesium
n  category
-------------------
1) hours of sleep per day [hrs] .................................... [4 - 12 ]
2) water consumed day  [L] ......................................... [1 - 5.0]
3) Intense exercise min per week [min] ............................. [0 - 150 ]
4) muscle fatigue....... ...........0:none 5:severe................. [0  to  4 ]
Belonging to 3 categories: low need, moderate need, or severe need.
******************************************************************
"""
#Imports to always include
########################################
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from IPython.display import display
import IPython
import sys
import sklearn as skl
import matplotlib
import scipy as sp
import seaborn as sns
import random
#########################################



"""
* generateGaussian_hrSleepPerDay()
* params:
* returns:
* -
* Synopsis:
* Too little sleep could indicate Mg could be beneficial.
* Units:[Hours]
* Range: [4-12] , mean=8, sigma=1, n=10000000
* Any number less than 7 will trigger:
* 1 Mg need
* else:
* 0 No Mg need
* -
* how to do this:
* https://stackoverflow.com/questions/18441779/how-to-specify-upper-and-lower-limits-when-using-numpy-random-normal
"""
def generateGaussian_hrSleepPerDay():
    print("hrs of sleep")
    lower = 4
    upper = 12     
    mu = 8
    sigma = 1
    N = 10000000

    s = sp.stats.truncnorm.rvs(
          (lower-mu)/sigma,(upper-mu)/sigma,loc=mu,scale=sigma,size=N)
    #s = np.floor(s)
    print("Max",max(s))
    print("Min",min(s))

    #print(s)
    return s


"""
* generateGuassian_waterInLPerDay_men()
* params:
* returns:
* -
* Synopsis:
* Too much water consumption could indicate low Mg levels.
* Units:[Liters]
* Range: [1-4] , mean=3.7, sigma=0.3, n=10000000
* Any number greater than 3.7:
* 1 Mg need
* else:
* 0 No Mg need
* -
* how to do this:
* https://stackoverflow.com/questions/18441779/how-to-specify-upper-and-lower-limits-when-using-numpy-random-normal
"""
def generateGuassian_waterInLPerDay_men():
    print("Liters of water: men")
    lower = 1
    upper = 5   
    mu = 3.7
    sigma = 0.25
    N = 10000000

    s = sp.stats.truncnorm.rvs(
          (lower-mu)/sigma,(upper-mu)/sigma,loc=mu,scale=sigma,size=N)
    #s = np.floor(s)
    print("Max",max(s))
    print("Min",min(s))
    return s


"""
* generateGuassian_waterInLPerDay_women()
* params:
* returns:
* -
* Synopsis:
* Too much water consumption could indicate low Mg levels.
* Units:[Liters]
* Range: [1-4] , mean=2.7, sigma=0.3, n=10000000
* Any number greater than 2.7 will trigger:
* 1 Mg need
* else:
* 0 No Mg need
* -
* how to do this:
* https://stackoverflow.com/questions/18441779/how-to-specify-upper-and-lower-limits-when-using-numpy-random-normal
"""
def generateGuassian_waterInLPerDay_women():
    print("Liters of water: women")
    lower = 1
    upper = 4   
    mu = 2.7
    sigma = 0.25
    N = 10000000

    s = sp.stats.truncnorm.rvs(
          (lower-mu)/sigma,(upper-mu)/sigma,loc=mu,scale=sigma,size=N)
    #s = np.floor(s)
    print("Max",max(s))
    print("Min",min(s))
    
    return s

"""
* generateGuassian_intenseExerciseMinPerWeek()
* params:
* returns:
* -
* Synopsis:
* Intense exercise can increse urinary and sweat loss of electrolytes.
* Units:[hours]
* Range: [0-150] , mean=75, sigma=0.5, n=10000000
* Any number greater than 75 will trigger:
* 1 Mg need
* else:
* 0 No Mg need
* -
* how to do this:
* https://stackoverflow.com/questions/18441779/how-to-specify-upper-and-lower-limits-when-using-numpy-random-normal
"""
def generateGuassian_intenseExerciseMinPerWeek():
    print("Intense min exercise per week")
    lower = 0
    upper = 150     
    mu = 75
    sigma = 12.5
    N = 10000000

    s = sp.stats.truncnorm.rvs(
          (lower-mu)/sigma,(upper-mu)/sigma,loc=mu,scale=sigma,size=N)
    #s = np.floor(s)
    print("Max",max(s))
    print("Min",min(s))

    return s


"""
* generateGaussian_dailySenseMuscleFatigue()
* params:
* returns:
* -
* Synopsis:
* Mg is a vital mineral in muscle contraction.  Lack of it can
* cause symptoms including muscle fatigue.
* Units:[rubric]
* Range: [1-5] , mean=2.5, sigma=0.5, n=10000000
* Any number greater than 2.5 will trigger:
* 1 Mg need
* else:
* 0 No Mg need
* -
* how to do this:
* https://stackoverflow.com/questions/18441779/how-to-specify-upper-and-lower-limits-when-using-numpy-random-normal
"""
def generateGaussian_dailySenseMuscleFatigue():
    print("Daily sense of muscle fatigue")
    lower = 1
    upper = 5   
    mu = 2.5
    sigma = 0.25
    N = 10000000

    s = sp.stats.truncnorm.rvs(
          (lower-mu)/sigma,(upper-mu)/sigma,loc=mu,scale=sigma,size=N)
    #s = np.floor(s)
    print("Type",type(s))
    print("Max",max(s))
    print("Min",min(s))
    return s


"""
* getCreateDataFrame_1()
* params: all the guassian np arrays I created
* returns: a data frame
* -
* Synopsis:
* Gender|Intense_Exercise_Weekly_Min|Daily_Sense_Muscle_Fatigue|Daily_H20_Consumption|Daily_Sleep <--- column titles
* 
* I want 150 entries.
* For each entry assign a value from the appropriate np array.
* Since the data gets shuffled for the ML, do 50 men then 50 women.
* https://www.geeksforgeeks.org/different-ways-to-create-pandas-dataframe/
* https://www.statology.org/pandas-add-row-to-dataframe/#:~:text=You%20can%20use%20the%20df,loc%5Blen(df.
"""
def getCreateDataFrame_1(gHrsSleep,gH20_men,gH20_wom,gIntExWk,gDailyFat):

    df = pd.DataFrame(columns=['Gender','Intense_Exercise_Weekly_Min',
                               'Daily_Sense_Muscle_Fatigue','Daily_H20_Consumption',
                               'Daily_Sleep','level_of_Mg_Need_encode','level_of_Mg_Need_description'])

    #df.astype({'Gender':'int32'}).dtypes - did not work.
    #test this:
    #print(df)
    #print("Here?-->",gIntExWk[getRI()])

    for i in range(150):
        randyInt = random.randint(0,10000000)
        arg1 = int(1)                    #1 Stands for female.
        arg2 = gIntExWk[randyInt]
        arg3 = gDailyFat[randyInt]
        arg4 = gH20_wom[randyInt]
        arg5 = gHrsSleep[randyInt]
        arg6, arg7 = getDecision(arg1,arg2,arg3,arg4,arg5)

        df.loc[len(df.index)] = [arg1,arg2,arg3,arg4,arg5,int(arg6),str(arg7)] 

    for i in range(150):
        randyInt = random.randint(0,10000000)
        arg1 = int(0)                    #0 stands for male
        arg2 = gIntExWk[randyInt]
        arg3 = gDailyFat[randyInt]
        arg4 = gH20_men[randyInt]
        arg5 = gHrsSleep[randyInt]
        arg6, arg7 = getDecision(arg1,arg2,arg3,arg4,arg5)

        df.loc[len(df.index)] = [arg1,arg2,arg3,arg4,arg5,int(arg6),str(arg7)] 

                                 

    #print(df.to_string())
    return df

"""
getDecision()
* params: gender, exHr, dayFatigue, h20Intake, dailySleep
* returns: one of: low,moderate,high
-
Synopsis:
0/4 - low
1/4 - moderate
2/4 - moderate
3/4 - moderate
4/4 - high
"""
def getDecision(gender, exHr, dayFatigue, h20Intake, dailySleep):

    category = 0                #keep track of the number of categories triggered.
    if(gender==1):              #female
        if(dailySleep<=float(7)):
            category+=1
        if(h20Intake>float(2.7)):
            category+=1
        if(exHr>float(75)):
            category+=1
        if(dayFatigue>2.5):
            category+=1

    if(gender==0):              #male
        if(dailySleep<=float(7)):
            category+=1
        if(h20Intake>float(3.7)):
            category+=1
        if(exHr>float(75)):
            category+=1
        if(dayFatigue>2.5):
            category+=1

    if(category==0):                    #0/4 - low
        return 0, "low" 
    elif(0<category and category<4):    #1/4, 2/4, 3/4 - moderate
        return  1, "moderate"
    else:                               #4/4 - high
        return  2, "high"

    return -1

# Defining main function
def main():
    #Call this bad-boy
    gHrsSleep = generateGaussian_hrSleepPerDay()
    gH20_men = generateGuassian_waterInLPerDay_men()
    gH20_wom = generateGuassian_waterInLPerDay_women()
    gIntExWk = generateGuassian_intenseExerciseMinPerWeek()
    gDailyFat = generateGaussian_dailySenseMuscleFatigue()

    df1 = getCreateDataFrame_1(gHrsSleep,gH20_men,gH20_wom,gIntExWk,gDailyFat)
    print(df1.to_string())
    #ok, let's do some ML
    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test =\
                    train_test_split(df1[['Gender','Intense_Exercise_Weekly_Min',
                               'Daily_Sense_Muscle_Fatigue','Daily_H20_Consumption',
                               'Daily_Sleep']],df1['level_of_Mg_Need_encode'],random_state=0)

    y_train = y_train.astype('int')
    y_test = y_test.astype('int')    
    #-check the types of data in the columns
    results=df1.dtypes
    print(results)

    #examining output shape
    print("X_train type:",type(X_train))
    print("y_train type:",type(y_train))

    #
    print("X_train shape:",X_train.shape)
    print("y_train shape:",y_train.shape)
    

    #
    print("X_train:\n",X_train.to_string())
    print("y_train:\n",y_train.to_string())
    
    #df2 = pd.DataFrame(X_train,columns=df1.feature_names)
    # create a scatter matrix from the dataframe, color by y_train.

    #pd.plotting.scatter_matrix(df2, c=y_train, figsize=(12,12),
    #                           marker='o', hist_kwds={'bins':20},s=60,
    #                           alpha=.8)
    pd.plotting.scatter_matrix(df1)
    plt.show()
    #plt.savefig("pairPlot_Mk2.png")


   #knn encapsulates: the algorithm that will be used to build the model from the training data
    #as well as the algorithm to make predictions on new data points.  It will also hold all the information
    #that the algorithm has extracted from the training data.
    from sklearn.neighbors import KNeighborsClassifier
    knn1 = KNeighborsClassifier(n_neighbors=1)           #setting n=1
    knn2 = KNeighborsClassifier(n_neighbors=2)           #setting n=2
    knn3 = KNeighborsClassifier(n_neighbors=3)           #setting n=3
    knn5 = KNeighborsClassifier(n_neighbors=5)           #setting n=5
    knn7 = KNeighborsClassifier(n_neighbors=7)           #setting n=7

    #build the model.
    #---- no easy way to get feature importance for k-nearest neighbors
    knn1.fit(X_train,y_train)
    knn2.fit(X_train,y_train)
    knn3.fit(X_train,y_train)
    knn5.fit(X_train,y_train)
    knn7.fit(X_train,y_train)
    
    #suppose you've got some new info.
    
    data = {'Gender':[1],'Intense_Exercise_Weekly_Min':[30],
                               'Daily_Sense_Muscle_Fatigue':[5],'Daily_H20_Consumption':[5],
                               'Daily_Sleep':[3]}
    x_new = pd.DataFrame(data) #['Gender','Intense_Exercise_Weekly_Min',
                                         #'Daily_Sense_Muscle_Fatigue','Daily_H20_Consumption',
                                         #'Daily_Sleep']

    #make a prediction..
    prediction1 = knn1.predict(x_new)
    prediction2 = knn2.predict(x_new)
    prediction3 = knn3.predict(x_new)
    prediction5 = knn5.predict(x_new)
    prediction7 = knn7.predict(x_new)

    #I was having difficulty getting the 'below' to work - so, I just did this.
    #No shame in doing it this way?
    predictionKey=['low','moderate','high']
    print("Prediction1:",predictionKey[int(prediction1)])
    print("Prediction2:",predictionKey[int(prediction2)])
    print("Prediction3:",predictionKey[int(prediction3)])
    print("Prediction5:",predictionKey[int(prediction5)])
    print("Prediction7:",predictionKey[int(prediction7)])

    #--- I think I'd need to structure this differently to get exactly what I
    #--- want.  
    #print("Predicted target name:", df1['level_of_Mg_Need_description'][prediction1])        #Yes, worked.
    #print("Predicted target name:", df1['level_of_Mg_Need_description'][prediction2])        #Yes, worked.
    #print("Predicted target name:", df1['level_of_Mg_Need_description'][prediction3])        #Yes, worked.
    #print("Predicted target name:", df1['level_of_Mg_Need_description'][prediction5])        #Yes, worked.
    #print("Predicted target name:", df1['level_of_Mg_Need_description'][prediction7])        #Yes, worked.
    #How do we know we can trust our model?
    y_pred1 = knn1.predict(X_test)
    print("Test set predictions:\n",y_pred1)
    print("Test set score(1): {:.2f}".format(np.mean(y_pred1 == y_test)))

    #
    y_pred2 = knn2.predict(X_test)
    print("Test set predictions:\n",y_pred2)
    print("Test set score(2): {:.2f}".format(np.mean(y_pred2 == y_test)))
    #
    y_pred3 = knn3.predict(X_test)
    print("Test set predictions:\n",y_pred3)
    print("Test set score(3): {:.2f}".format(np.mean(y_pred3 == y_test)))
    #    
    y_pred5 = knn5.predict(X_test)
    print("Test set predictions:\n",y_pred5)
    print("Test set score(5): {:.2f}".format(np.mean(y_pred5 == y_test)))
    #
    y_pred7 = knn7.predict(X_test)
    print("Test set predictions:\n",y_pred7)
    print("Test set score(7): {:.2f}".format(np.mean(y_pred7 == y_test)))

    #Stats - how many of each kind did I end up with.
    print("********STATS**********")
    print(df1['level_of_Mg_Need_description'].value_counts())

        
    #############################
    #   ||
    #   ||    'This is the end ... Beautiful friend'
    #  ----
    #  \  /
    #   \/
    #==========================>>
    return 0 #-------- end main>>>
    #==========================>>>>
    
  
# Using the special variable 
# __name__
if __name__=="__main__":
    main()
