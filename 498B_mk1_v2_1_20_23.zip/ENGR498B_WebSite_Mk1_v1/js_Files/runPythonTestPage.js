/**
 * WebSite_Mk3
 * Nathan Herling, THE U of A
 * ENGR 498A - Fall 2022
 * 11/11/2022
 * JavaScript file to process input from: getTestPyScripts.html
 * activates via keypad touch from: getRunPython.js
 */

 
 //register all buttons as events from the .html file
 //I currently have 9 options to work with ... we'll see how long that lasts me!
 //-----------------------------------------------------------------//
var getPyScript1 = document.getElementById("getRunPythonBtn1");
getPyScript1.addEventListener("click", getPyTest);			//
var getPyScript2 = document.getElementById("getRunPythonBtn2"); 
getPyScript2.addEventListener("click", getPyTest);			//
var getPyScript3 = document.getElementById("getRunPythonBtn3");
getPyScript3.addEventListener("click", getPyTest);			//
var getPyScript4 = document.getElementById("getRunPythonBtn4");
getPyScript4.addEventListener("click", getPyTest);			//
var getPyScript5 = document.getElementById("getRunPythonBtn5");
getPyScript5.addEventListener("click", getPyTest);			//
var getPyScript6 = document.getElementById("getRunPythonBtn6");
getPyScript6.addEventListener("click", getPyTest);			//
var getPyScript7 = document.getElementById("getRunPythonBtn7");
getPyScript7.addEventListener("click", getPyTest);			//
var getPyScript8 = document.getElementById("getRunPythonBtn8");
getPyScript8.addEventListener("click", getPyTest);			//
var getPyScript9 = document.getElementById("getRunPythonBtn9");
getPyScript9.addEventListener("click", getPyTest);			//
 //-----------------------------------------------------------------//

//------ buton at the top of the page -----//
let backButton = document.getElementById("backButton");
backButton.addEventListener("click",getLoadTestPage);

let reWriteDiv = document.getElementById("reWriteDiv");


 
 
 
/*
 * getRunPyScript()
 * params : identifying string.
 * returns: html code to re-write the <div>
 * -
 * synopsis: 
 * I'll make a helper method switch function.
 * We'll identify the script by elementId, and we can pass the desired python file 
 * to the .php file that way.
 *
 */
 function getPyTest(element){
	console.log("You are in: getRunPyScript() [getRunPython.js]");
	//alert("made it to getTable()");
	let identifierStr = element.id;						//who knew it'd be that easy?
	let pyFileToLoad = getSwitchHelper(identifierStr);


	let ajax = new XMLHttpRequest();
	// Send a query parameter to a PHP program
	// Arguments: method (GET) and url with query param(s)
	console.log("Running: "+pyFileToLoad);
	ajax.open("GET", "../php_Files/runPyScriptTest.php?pyFileToLoad=" + pyFileToLoad);
	//an example of 'how' to send a variable.
	//ajax.open("GET","bestreads.php?n="+n)

	ajax.send();

	// This high order anonymous function will execute when the server responds (a callback)
	ajax.onreadystatechange = function() {
		//for information purposes:
		//console.log("State: " + ajax.readyState);
		if (ajax.readyState == 4 && ajax.status == 200) {
			//This is how we turn a JSON array into a JS array.
			retStr = "";
			retStr = ajax.responseText;
			console.log("Here is the response text: "+retStr);
			//re-write the div - make a div to put the question in <div></div> add the next button.
			//retStr += getPrintTestResultToDiv();
			reWriteDiv.innerHTML = ajax.responseText;
			//getCreateNextButton();

		} else {
			//At the moment, I have no way to test this.
			//I'm assuming \n characters will function as desired and strings work like this...
			//Below does work, but it throws alerts unnecessarily atm.
			//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
		}
	}; // End anonymous high order function

}//end_function
 
 
 /*
 * getSwitchHelper()
 * params: none - we have global variables.
 * returns: string of file name with python test.
 * -
 * Above sums it up.
 */
 function getSwitchHelper(identifierStr){
	
	switch(identifierStr) {
  case "getRunPythonBtn1":			//Test 1
  	console.log("You hit 1");
    return "pyTest1.py";
  case "getRunPythonBtn2":			//Test 2
  	console.log("You hit 2");
    return "pyTest2.py";
  case "getRunPythonBtn3":			//Test 3
    console.log("You hit 3");
  	return "pyTest3.py";
  case "getRunPythonBtn4":			//Test 4
    console.log("You hit 4");
  	return "pyTest4.py";
  case "getRunPythonBtn5":			//Test 5
    console.log("You hit 5");
  	return "pyTest5.py";
  case "getRunPythonBtn6":			//Test 6
    console.log("You hit 6");
  	return "pyTest6.py";
  case "getRunPythonBtn7":			//Test 7
    console.log("You hit 7");
  	return "pyTest7.py";
  case "getRunPythonBtn8":			//Test 8
    console.log("You hit 8");
  	return "pyTest8.py";
  case "getRunPythonBtn9":			//Test 9
    console.log("You hit 9");
  	return "pyTest9.py";
  default:
    alert("unrecognize input alert getSwitchHelper()"+String(identifierStr));
    }//end_switch
	
}//end_function 


/*
* function getTestPage()
* params: none.
* returns: none.
* -
* This needs to:
* (1) load when the page loads. [ done through html <body onload="getLoadTestPage()">]
* (2) load when the home button is clicked. [done through even listener]
* ----
* It's going to make an AJAX call.
* That AJAX call will print out the start page.
* The 'trick' here is that we want our html code to be in our php file.
* And, we'll echo it back...
*/
function getLoadTestPage(){
	//debugging
	console.log("You are in getLoadTestPage()");
	let ajax = new XMLHttpRequest();
	
	// Send a query parameter to a PHP program
	// Arguments: method (GET) and url with query param(s)
	ajax.open("GET", "../php_Files/onLoadPyTestPage.php");				//hey, look.  We ARE using GET
															//an example of 'how' to send a variable.
															//ajax.open("GET","bestreads.php?n="+n)
	ajax.send();

	// This high order anonymous function will execute when the server responds (a callback)
	ajax.onreadystatechange = function() {
		//for information purposes:
		//console.log("State: " + ajax.readyState);
		if (ajax.readyState == 4 && ajax.status == 200) {

			reWriteDiv.innerHTML=ajax.responseText;							//NOTE: all html is written in the .php file.
			//console.log("Here is the re-written html:"+ajax.responseText);

		} else {
			//At the moment, I have no way to test this.
			//I'm assuming \n characters will function as desired and strings work like this...
			//Below does work, but it throws alerts unnecessarily atm.
			//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
		}
	}; // End anonymous high order function
}//end_function

/*
* getPrintTestResultToDiv()
* params:
* returns:
* -
* synopsis:
* .. lol... what CAN'T it do?
*/
function getPrintTestResultToDiv(){
	console.log("You're in: getPrintTestResultToDiv()");
	return "<h4> Get F*cked </h4>";
}//end_funtion

