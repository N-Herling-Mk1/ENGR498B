 /*
 * ENGR  498A - Fall 2022
 * Nathan Herling
 * Attempting to organize questionnaire via a class structure.
 *
 *
 */
 
 //Class for question type.
 //Class for Magnesium.
 export class MagnesiumQuestions {
//	class MagnesiumQuestions {
  	
  constructor() {
    this.gender = "NA";
    this.dailyWaterCons = -1;
    this.dailySleepHrs = -1;
    this.weeklyIntenseExMin = -1;
    this.dailySenseOfMuscleFatigue=-1;
  }//end_constructor
  
  getQuestionName(){
	return "Magnesium Questions";
}
  
}//end_class