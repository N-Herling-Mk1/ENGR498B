/**
 * File: takeTheQuiz.js
 * 
 * WebSite_mk3
 * Nathan Herling, THE U of A
 * ENGR 498A - Fall 2022
 * 11/18/22
 * JavaScript file to process input from: takeTheQuiz.html
 * updating: 12/21/22
 */


let percentDone_Div = document.getElementById("PercentDone");			//record % of questions answered.
//question stats div
let questStatsAnswered_Div = document.getElementById("questionStatsText_Answered_id");
let questStatsUnAnswered_Div = document.getElementById("questionStatsText_UnAnswered_id");
let questStatsSkipped_Div = document.getElementById("questionStatsText_Skipped_id");


let reWriteProgress = document.getElementById("upDateQuestions");
let reWriteQDiv = document.getElementById("questionRewriteDiv");
let reWriteTEST = document.getElementById("reWriteTest");
let nextBtn = document.getElementById("getNextQuestionBtn");
nextBtn.addEventListener("click", getNextQuestion_js);			// .. toggle forward
let prvBtn = document.getElementById("getPrevQuestionBtn");
prvBtn.addEventListener("click", getPrevQuestion_js);			// .. toggle backwards
//
let radioVal = document.getElementsByName("radioQ");			// .. the radio buttons I think I can alter this size..
//
let updateBox = document.getElementById("upDateBoxText");
//
let submitBtn = document.getElementById("submit_Button");
submitBtn.addEventListener("click", getSubmit);

//Sweet -- I should be able to re-write the entire page with this bad-boy (or girl) ...(or non-binary)...
let masterPage = document.getElementById("masterControlQuizPage");

//keep track of question answers.
var qAnsArray = [];	//NUM_QUESTIONS qAnsArray
var formSubmitted=0;

//ok - here is a class.
//This class defines it's own question.  I think there will always be an element
//of hard-coding and an element of a state machine .. so couching questions
//as a class is a good idea.
class MagnesiumQuestions {

	constructor() {
		//Each of these will be connected to a question type.
		this.gender = "NA";					//n=1
		this.dailyWaterCons = -1;			//n=2
		this.dailySleepHrs = -1;			//n=3
		this.weeklyIntenseExMin = -1;		//n=4
		this.dailySenseOfMuscleFatigue = -1;//n=5
		//
		this.numberQuestions = 5;
		this.numberBtns = -1;
		this.btnCategories = [];
	}//end_constructor


	//*****Getters*****/
	//n=1
	getGender() {
		return this.gender;
	}//end_method

	//n=2
	getDailyWaterConsumption() {
		return this.dailyWaterCons;
	}//end_method

	//n=3
	getDailySleepHrs() {
		return this.dailySleepHrs;
	}//end_method

	//n=4
	getWklyHrsIntenseEx() {
		return this.weeklyIntenseExMin;
	}//end_method

	//n=5
	getDailySenseMuscleFatique() {
		return this.dailySenseOfMuscleFatigue;
	}//end_method

	//Non-param. Meta-Data
	getQuestionName() {
		return "Magnesium Questions";
	}//end_method

	//Non-param.
	getNumberQuetsions() {
		return this.numberQuestions;
	}//end_method	
	//*****end Getters ****/

	/**Setters ***/
	//n=1
	setGender(gender) {
		this.gender = gender;
	}//end_method

	//n=2
	setDailyWaterConsumption(dailyWaterConsumption) {
		this.dailyWaterCons = dailyWaterConsumption;
	}//end_method

	//n=3
	setDailySleepHrs(dailySleepHrs) {
		this.dailySleepHrs = dailySleepHrs;
	}//end_method

	//n=4
	setDailySenseMuscleFatique(dailySenseOfMuscleFatigue) {
		this.dailySenseOfMuscleFatigue = dailySenseOfMuscleFatigue;
	}//end_method

	//n=5
	setWklyHrsIntenseEx(weeklyIntenseExMin) {
		this.weeklyIntenseExMin = weeklyIntenseExMin;
	}//end_method	

	//*** END SETTERS */


	//The arrayVal is coming from the global array that keeps track of questions
	//if the val is 'NA' it's still in its initial state, otherwise it's been 
	//set to some value in the question array.
	getQuestionSelect(currQuestion, arrayVal) {

		//This is the current answer to the M/F question. -- it will always be at element 0.
		this.setGender(qAnsArray[0]);
		let rememberPrev = -1;
		console.log("??>>" + arrayVal);

		switch (currQuestion) {

			case 0:		//question 1
				this.btnCategories = ["Male", "Female"];
				rememberPrev = this.btnCategories.indexOf(arrayVal);		//this is the memory component.  Fin the index of the value in mem.
				break;

			case 1:		//question 2
				if (this.gender == "Male" || this.gender == "NA") {//set a default
					this.numberBtns = 7;
					this.btnCategories = ["[less]", "1", "2", "3", "4", "5", "[more]"];
					rememberPrev = this.btnCategories.indexOf(arrayVal);
					//then I could pass it to the php file - and, return the html code.
				}
				if (this.gender == "Female") {//set a default
					this.numberBtns = 6;
					this.btnCategories = ["[less]", "1", "2", "3", "4", "[more]"];
					rememberPrev = this.btnCategories.indexOf(arrayVal);
					//then I could pass it to the php file - and, return the html code.
				}

				break;

			case 2:		//question 3
				this.btnCategories = ["[less]", "4", "5", "6", "7", "8", "9", "10", "[more]"];
				rememberPrev = this.btnCategories.indexOf(arrayVal);
				break;

			case 3:		//question 4
				this.btnCategories = ["0-15", "15-30", "30-45", "45-60", "60-75", "75-90", "90-105",
					"105-120", "120-135", "135-150", "[more]"];
				rememberPrev = this.btnCategories.indexOf(arrayVal);
				break;

			case 4:		//question 5
				this.btnCategories = ["(1)-None", "(2)-Some", "(3)-Moderate", "(4)-Intense",
					"(5)-Severe"];
				rememberPrev = this.btnCategories.indexOf(arrayVal);
				break;

			default:
				console.log("Unrecognized Case: " + currQuestion);
		}//end_switch

		//pass the index of the 'remembered' value.
		this.get_PHP_reWriteCode(rememberPrev);
	}//end_method

	/*
	* get_PHP_reWriteCode()
	* use the param set in the method that calls this: getQuestionSelect(currQuestion)
	* to talk to a .php file to write back adjustable questionnaire.
	* -
	* checkBox is used in the .php function to select which of the radio buttons to 'initialize' as checked.
	* it's clever, since I'm basing it on array index, and from above, if the value isn't found, it will 
	* return '-1', hence it won't effect how the radio buttons are created in html [inside the .php file] 
	*/
	get_PHP_reWriteCode(checkBox) {
		let ajax = new XMLHttpRequest();
		// Send a query parameter to a PHP program
		// Arguments: method (GET) and url with query param(s)
		//console.log("^^^^Global Count "+globalCount);
		//console.log("^^^^RememberPrev "+checkBox);
		ajax.open("GET", "../php_Files/getQuestionDivReWrite.php?checkBox=" + checkBox
			+ "&btnCategories=" + JSON.stringify(this.btnCategories));	//hey, look.  We ARE using GET
		//an example of 'how' to send a variable.JSON.stringify(array)
		//ajax.open("GET","bestreads.php?n="+n)

		ajax.send();
		let retStr = "";
		// This high order anonymous function will execute when the server responds (a callback)
		ajax.onreadystatechange = function() {
			//for information purposes:
			console.log("State: " + ajax.readyState);
			if (ajax.readyState == 4 && ajax.status == 200) {
				//This is how we turn a JSON array into a JS array.

				retStr = ajax.responseText;
				//console.log("Here is the current question: " + retStr);

				//re-write the div - make a div to put the question in <div></div> add the next button.
				//retStr = '<div class="questionFormat"><b>#' + (currQuestion + 1) + '<br>' + retStr + "</div>";

				//retStr+=getHTML_forButton();
				reWriteTEST.innerHTML = retStr;
				//getCreateNextButton();

			} else {
				//At the moment, I have no way to test this.
				//I'm assuming \n characters will function as desired and strings work like this...
				//Below does work, but it throws alerts unnecessarily atm.
				//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
			}
		}; // End anonymous high order function
	}//end_method

}//end_class


//---- here is an instantiation of the class.
import {questionnaireSmartClass_mk1} from './questionnaireSmartClass_mk1.js';

const magnesiumQs = new MagnesiumQuestions();
const magnesiumQ_mk2 = new questionnairSmartClass_mk1("../txt_Files/Mg_Qs_Mk2.txt");
var globalCount = -1;		//A much simpler design starting a -1 as the initial state.
var NUM_QUESTIONS = magnesiumQs.getNumberQuetsions();		//manually set this to not read off end of question file.

console.log("The name of the class:" + magnesiumQs.getQuestionName());

/*
* getInitializeAnswerArray()
* params:
* returns:
* -
*  One time array initialization.
*/
function getInitializeAnswerArray() {
	console.log("Initialize Array");
	for (i = 0; i < NUM_QUESTIONS; i++) {
		qAnsArray[i] = "NA";
	}
	console.log(qAnsArray);
}//end_function


/*
* getPrevQuestion_js()
* params: 
* returns:
* -
* toggle backwards in question list.
*
*/
function getPrevQuestion_js() {
	console.log("You are in: getPrevQuestion_js()");
	//getCurrentRadioVal();
	getPrvQuestion_php();
	getRefreshUpDateBox_mk2();
	getReWriteQuestionStats();
	console.log("Is radioVal adjusting?: " + radioVal.length);
	//getCurrentRadioVal();

}//end_function

/*
* getNextQuestion_js()
* params:
* returns:
* -
* toggle forward in question list.
* Creats the current question in the list - 
*/

function getNextQuestion_js() {

	//Put this here for testing....

	if (globalCount === -1) {			//initial state.
		getInitializeAnswerArray();
	}

	//getCurrentRadioVal();

	getNextQuestion_php();
	getRefreshUpDateBox_mk2();
	getReWriteQuestionStats();
	console.log("You are in: getNextQuestion_js()");
	console.log("GlobalCount:" + globalCount);
	console.log("Is radioVal adjusting?: " + radioVal.length);


}//end_function


/*
* getLoadQuestions_php()
* use AJAX/PHP to load the questions.
*
* we want to check: week9-hw2
*/
function getNextQuestion_php() {


	//alert("made it to getTable()");
	if (globalCount < (NUM_QUESTIONS - 1)) {
		globalCount++;
	}
	magnesiumQs.getQuestionSelect(globalCount, qAnsArray[globalCount]);					//<<<<<<<<<<<<<<<<-----------------------


	//console.log("Global Count: " + globalCount);
	let currQuestion = globalCount;
	let ajax = new XMLHttpRequest();
	// Send a query parameter to a PHP program
	// Arguments: method (GET) and url with query param(s)
	ajax.open("GET", "../php_Files/getIndivQuestion.php?index=" + currQuestion);	//hey, look.  We ARE using GET
	//an example of 'how' to send a variable.
	//ajax.open("GET","bestreads.php?n="+n)

	ajax.send();

	// This high order anonymous function will execute when the server responds (a callback)
	ajax.onreadystatechange = function() {
		//for information purposes:
		//console.log("State: " + ajax.readyState);
		if (ajax.readyState == 4 && ajax.status == 200) {
			//This is how we turn a JSON array into a JS array.
			retStr = "";
			retStr = ajax.responseText;
			//console.log("Here is the current question: " + retStr);

			//re-write the div - make a div to put the question in <div></div> add the next button.
			retStr = '<div class="questionFormat"><b>#' + (currQuestion + 1) + '<br>' + retStr + "</div>";

			//retStr+=getHTML_forButton();
			reWriteQDiv.innerHTML = retStr;
			//getCreateNextButton();

		} else {
			//At the moment, I have no way to test this.
			//I'm assuming \n characters will function as desired and strings work like this...
			//Below does work, but it throws alerts unnecessarily atm.
			//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
		}
	}; // End anonymous high order function
	getPrintArray();
}//end_function


/*
* getPrvQuestion_php()
* use AJAX/PHP to load the questions.
*
* we want to check: week9-hw2
*/
function getPrvQuestion_php() {

	//alert("made it to getTable()");
	console.log("You are in getPrvQuestion_php()");
	console.log("GC here: " + globalCount);
	if (parseInt(globalCount) > 0) {						//don't toggle past list start.
		globalCount--;
	}

	magnesiumQs.getQuestionSelect(globalCount, qAnsArray[globalCount]);					//<<<<<<<<<<<<<<<<-----------------------

	console.log("Global Count: " + globalCount);
	let currQuestion = globalCount;
	let ajax = new XMLHttpRequest();
	// Send a query parameter to a PHP program
	// Arguments: method (GET) and url with query param(s)
	ajax.open("GET", "../php_Files/getIndivQuestion.php?index=" + currQuestion);	//hey, look.  We ARE using GET
	//an example of 'how' to send a variable.
	//ajax.open("GET","bestreads.php?n="+n)

	ajax.send();

	// This high order anonymous function will execute when the server responds (a callback)
	ajax.onreadystatechange = function() {
		//for information purposes:
		//console.log("State: " + ajax.readyState);
		if (ajax.readyState == 4 && ajax.status == 200) {
			//This is how we turn a JSON array into a JS array.
			retStr = "";
			retStr = ajax.responseText;
			//console.log("Here is the current question: " + retStr);

			//re-write the div - make a div to put the question in <div></div> add the next button.
			retStr = '<div class="questionFormat"><b>#' + (currQuestion + 1) + '<br>' + retStr + "</div>";

			//retStr+=getHTML_forButton();
			reWriteQDiv.innerHTML = retStr;
			//getCreateNextButton();

		} else {
			//At the moment, I have no way to test this.
			//I'm assuming \n characters will function as desired and strings work like this...
			//Below does work, but it throws alerts unnecessarily atm.
			//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
		}
	}; // End anonymous high order function
	//If you were at question 0, you'll expect 'next' to take you to question 1.
	getPrintArray();
}//end_function 

/*
* getHTML_forButton()
* params:
* returns:
* -
* 
*/
function getHTML_forButton() {
	//<button type="button" id="getNextQuestionBtn">
	return '<button type="button" id="getNextQuestionBtn">next</button>';

}//end_function

/*
* getCurrentRadioVal()
* params:
* returns:
* -
* This populates the spot with the answer.
* Dependent on radioVal.length
* https://www.geeksforgeeks.org/how-to-get-value-of-selected-radio-button-using-javascript/
*/
function getCurrentRadioVal() {//getCurrentRadioVal
	console.log("You are here: getCurrentRadioVal()");
	for (i = 0; i < radioVal.length; i++) {
		if (radioVal[i].checked) {
			//document.getElementById("result").innerHTML = "Gender: "+ele[i].value;
			console.log("CurrVal Checked: " + radioVal[i].value);
			qAnsArray[globalCount] = radioVal[i].value;
		}
	}
}//end_function



//>>>>>> mark 2
/*
https://bobbyhadz.com/blog/javascript-change-text-of-div-element
*/
/*
* getRefreshUpDateBox_mk2()
* params: none
* returns: none
* -
* Synopsis:
* creates the %-complete bar for the questionnaire
*/
function getRefreshUpDateBox_mk2() {
	let percentDone = 0;
	for (i = 0; i < qAnsArray.length; i++) {
		if (qAnsArray[i] != "NA") {
			percentDone++;
		} 
	}//end_for_loop
	percentDone = parseFloat(percentDone/qAnsArray.length)*100;
	//console.log("% done (1): "+percentDone+"%");
	//percentDone_Div.textContent=percentDone+"%";
	percentDone_Div.innerHTML = percentDone+"%";
	if(percentDone===100){//adjust so it doesn't go off the <div>
		console.log("Hit Flag!");
		percentDone_Div.style.textAlign = "center";
		percentDone_Div.style.color="gold";
		percentDone_Div.style.fontSize  = "2.25em";
	}

	//console.log("% done (2): "+percentDone+"%");	
	percentDone_Div.style.width=percentDone+"%";
	//percentDone.innerHTML = retStr;

}//end_function

/*
* getReWriteQuestionStats()
* params: none
* returns: none
* -
* Synopsis:
* Addresses the categories on the main page of:
*		Questionnaire stats
*	Answered:
* UnAnswered:
*    Skipped:
* --
* The Answered/Unanswered will always be fraction of the total questions
* The Skipped field has a max of 3, then will say (e.g.)
* Skipped: 1,2,3, .. + more
* -
* Formatting:
questStatsAnswered_Div
questStatsUnAnswered_Div
questStatsSkipped_Div 
*/
function getReWriteQuestionStats(){
	let total =qAnsArray.length;
	let answered = 0;
	let unAnswered = 0;
	let greatestAnsQuestionNum = 0;
	let skippedArr = [];
	for (i = 0; i < qAnsArray.length; i++) {
		if (qAnsArray[i] != "NA") {
			answered++;
		}else{
			unAnswered++;
			}
		}
	//Find the highest numbered question that doesn't have an 'NA'
	for(let i=0;i<(qAnsArray.length);i++){
		if((qAnsArray[i]!="NA")){
			greatestAnsQuestionNum=i;	
		}
	}	
	console.log("Largest skipped number: "+greatestAnsQuestionNum);
	//Go back, and check each question less than the numerically largest answered question
	//if it is 'NA' it was skipped.
	for(let i=0;i<greatestAnsQuestionNum;i++){
		if(qAnsArray[i]==="NA"){
			skippedArr.push(i);	
		}
	}
	questStatsAnswered_Div.innerHTML = "&nbsp;&nbsp;&nbsp;&nbsp;Answered: "+answered+"/"+total;
	questStatsUnAnswered_Div.textContent="Unanswered: "+unAnswered+"/"+total;
	let retStr="";
	
	for(i=0;i<skippedArr.length;i++){
		retStr+=(skippedArr[i]+1)+",";
		if(i===2){break;}
		}
	retStr=retStr.substring(0,retStr.length-1);		//take off last comma.		
	
	if(skippedArr.length>=4){
		retStr+="..+more";
	}
	console.log("Skipped Array>>: "+skippedArr);	
	questStatsSkipped_Div.innerHTML = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Skipped: "+retStr;
}//end_function


/* 
* getSubmit()
* params: none
* returns: none
* -
* Synopsis:
* when the sumbit button is hit..
* (1) Check to see if all questions are complete.  If not throw an alert indicating which questions need to be answered.
* (2) If every question is done - proceed to the ML!
*/
function getSubmit() {
	console.log("You are in <submit>");

	percentDone = 0;
	for (i = 0; i < qAnsArray.length; i++) {
		if (qAnsArray[i] != "NA") {
			percentDone++;
		}
	}
	percentDone = percentDone / qAnsArray.length;
	percentDone = 100 * percentDone;
	index = qAnsArray.indexOf("NA");
	if (index != -1) {
		alertStr = "";
		j = index + 1;
		alertStr = "Question: " + j + " needs to be answered.\n"
		alertStr += "You are " + percentDone + "% complete."
		alert(alertStr);
	} else {
		getRefreshUpDateBox_mk2();
		getReWriteQuestionStats();
		if(formSubmitted===0){
			alertStr = "You're done hit [ok] to calculate results!";
			alert(alertStr);
		}
		formSubmitted=1;
		getHelperForSubmitToText();
		//Now make a method to call the python ML file, to read in the text fields as a 'use case'
		getRunPythonML();
		getReWriteMasterDocDiv();
	}
}//end_function


/*
* getHelperForSubmitToText()
* params:
* returns:
* -
* Synopsis: do the ajax php call here - to make overall code cleaner.
*/
function getHelperForSubmitToText() {
	console.log("You are in: getHelperForSubmitToText()");
	let ajax = new XMLHttpRequest();
	ajax.open("GET", "../php_Files/getWriteTextToFile.php?outputArray=" + JSON.stringify(qAnsArray));	

	ajax.send();
	// This high order anonymous function will execute when the server responds (a callback)
	ajax.onreadystatechange = function() {

		if (ajax.readyState == 4 && ajax.status == 200) {
			//do nothing I don't care about the reponse text.. I just want to print to a file.
		} else {
			//At the moment, I have no way to test this.
			//I'm assuming \n characters will function as desired and strings work like this...
			//Below does work, but it throws alerts unnecessarily atm.
			//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
		}
	}; // End anonymous high order function	


}//end_function


/*
* getRunPythonML()
* params: none
* returns: none
* -
* Synopsis:
* execute the ML python script
* Pre-condition: the .txt file with all the question answers has already been generated.
*
*/
function getRunPythonML(){
	console.log("You are in: getHelperForSubmitToText()");
	let ajax = new XMLHttpRequest();
	ajax.open("GET", "../php_Files/runPyScript.php?pyFileToLoad=" + 'run_ML.py');	

	ajax.send();
	// This high order anonymous function will execute when the server responds (a callback)
	ajax.onreadystatechange = function() {

		if (ajax.readyState == 4 && ajax.status == 200) {
			//do nothing I don't care about the reponse text.. I just want to print to a file.
		} else {
			//At the moment, I have no way to test this.
			//I'm assuming \n characters will function as desired and strings work like this...
			//Below does work, but it throws alerts unnecessarily atm.
			//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
		}
	}; // End anonymous high order function	
	
}//end_function



/*
* getReWriteMasterDocDiv() --------------- get those f'ing results!
* params: none
* returns: none
* -
* Synopsis:
* When the quiz is over, and the python script has been run.. this page prints.
*
*/
function getReWriteMasterDocDiv(){
	//I need the python text file data - AJAX CALL - read back a JSON array - getTxtFileAsJSONArray.php
	let ajax = new XMLHttpRequest();
	ajax.open("GET", "../php_Files/getTxtFileAsJSONArray.php?txtfileName=" + 'MLResults.txt');	//hey, look.  We ARE using GET
	ajax.send();

	let arrayLoc=[];
	// This high order anonymous function will execute when the server responds (a callback)
	ajax.onreadystatechange = function() {

		if (ajax.readyState == 4 && ajax.status == 200) {
			//This is how we turn a JSON array into a JS array.
			arrayLoc=JSON.parse(ajax.responseText);
			//console.log("Here is the current question: " + retStr);
			console.log("Here are the results>>:"+arrayLoc);
			//retStrLoc="";
			//for(i=0;i<arrayLoc.length;i++){
			//	retStrLoc+="<h1>"+arrayLoc[i]+"</h1>";
			//	}
			//console.log("Get fucked:"+retStrLoc);
			retStr="";
			retStr=getConstructHTMLResults(arrayLoc);
			retStr+=getConstructHTMLSupplementRec();
			masterPage.innerHTML=retStr;
	
		} else {
			//At the moment, Keep this clear.
		}
	}; // End anonymous high order function
	//If you were at question 0, you'll expect 'next' to take you to question 1.

	//I need to format the data
	
	//I need a table with supplement recommendations
	
	//Then I'm done!
	
}//end_function


/*
* getConstructHTMLResults(arrayLoc)
* params:
* returns: html string
* -
* Synopsis:
* reads in the two values in the array: 
* [0]: %
* [1]: low/moderate/high
*/
function getConstructHTMLResults(arrayLoc){
	retStr="";

	retStr+="<br><table class=table1>"
	retStr+="<tr><th class=th1>Supplement</th><td class=td1><span class=lightBlue>Magnesium</span></td></tr>";
	retStr+="<tr><th class=th1>Need score</th><td class=td1><span class=yellowText>"+arrayLoc[1]+"</span></td></tr>";
	retStr+="<tr><th class=th1>Accuracy score</th><td class=td1><span class=greenText2>"+arrayLoc[0]+"</span></td></tr>";
	retStr+="</table>";
	
	retStr+="<br><br><div class=outputTexDiv><span class=regularText> For <i>Magnesium</i>, our model scores you in the <i>"+arrayLoc[1]+"</i> need category."+
	        "<br>According to our model, this prediction is <i>"+arrayLoc[0]+"</i> accurate.</span></div>";
	return retStr;
}//end_function


/*
* getConstructHTMLSupplementRec(arrayLoc)
* params: ?
* returns: formatted HTML string
* -
* Design the recommendation table - hard coded atm.
*/
function getConstructHTMLSupplementRec(){
	retStr="";

	retStr+="<br><br><table class=table1>"
	retStr+="<tr class=tr1><th class=th1>Products</th><th class=th1>Available Vendors</th></tr>";
	retStr+="<tr class=tr1>";
	retStr+="<td class=td1><span class=tableText>A</span></td><td class=td1><span class=tableText>Company A, Company B</span></td>";
	retStr+="</tr><tr class=tr1>";
	retStr+="<td class=td1><span class=tableText>B</span></td><td class=td1><span class=tableText>Company A, Company C</span></td>";
	retStr+="</tr><tr class=tr1>";
	retStr+="<td class=td1><span class=tableText>C</span></td><td class=td1><span class=tableText>Company B, Company C</span></td>";
	retStr+="</tr><tr class=tr1>";
	retStr+="<td class=td1><span class=tableText>D</span></td><td class=td1><span class=tableText>Company A, Company B, Company C</span></td>";
	retStr+="</table>";

	return retStr;
}//end_function
/*
* getPrintArray()
* params: none
* returns: none
* -
* prints contents of array to console.
*/
function getPrintArray() {
	console.log("**********Printing Array****");
	//console.log(qAnsArray);
	for (var i = 0; i < NUM_QUESTIONS; i++) {
		console.log("(" + i + ")" + qAnsArray[i]);
	}
	console.log("*** END PRINT ****")
}//end_function