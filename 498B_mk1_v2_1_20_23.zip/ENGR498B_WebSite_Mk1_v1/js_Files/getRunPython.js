/**
 * WebSite_Mk1_v2
 * Nathan Herling, THE U of A
 * ENGR 498A - Fall 2022
 * 11/1/11
 * JavaScript file to process input from: getTestPyScripts.html
 */

 
 //register button event from the .html file
let getPyScript1 = document.getElementById("getRunPythonBtn1");
getPyScript1.addEventListener("click", getTestPyScript1);			//

let getPyScript2 = document.getElementById("getRunPythonBtn2");
getPyScript2.addEventListener("click", getTestPyScript2);			//


let reWriteDiv = document.getElementById("reWriteDiv");


 
 /*
 * getTestPyScript1()
 *
 *
 *
 *
 *
 */
 function getTestPyScript1(){
	console.log("You are in: getTestPyScript1() [getRunPython.js]");
		//alert("made it to getTable()");

	let ajax = new XMLHttpRequest();
	// Send a query parameter to a PHP program
	// Arguments: method (GET) and url with query param(s)
	ajax.open("GET", "runPyScript.php");	//hey, look.  We ARE using GET
	//an example of 'how' to send a variable.
	//ajax.open("GET","bestreads.php?n="+n)

	ajax.send();

	// This high order anonymous function will execute when the server responds (a callback)
	ajax.onreadystatechange = function() {
		//for information purposes:
		//console.log("State: " + ajax.readyState);
		if (ajax.readyState == 4 && ajax.status == 200) {
			//This is how we turn a JSON array into a JS array.
			retStr = "";
			retStr = ajax.responseText;
			//re-write the div - make a div to put the question in <div></div> add the next button.
			retStr = '<div class="questionFormat"><b>#'+ retStr + "</div>";
			console.log(retStr);
			//retStr+=getHTML_forButton();
			reWriteDiv.innerHTML = retStr;
			//getCreateNextButton();

		} else {
			//At the moment, I have no way to test this.
			//I'm assuming \n characters will function as desired and strings work like this...
			//Below does work, but it throws alerts unnecessarily atm.
			//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
		}
	}; // End anonymous high order function

}//end_function
 
 
/*
 * getTestPyScript1()
 *
 *
 *
 *
 *
 */
 function getTestPyScript2(){
	console.log("You are in: getTestPyScript2() [getRunPython.js]");
		//alert("made it to getTable()");

	let ajax = new XMLHttpRequest();
	// Send a query parameter to a PHP program
	// Arguments: method (GET) and url with query param(s)
	ajax.open("GET", "runPyScript2.php");	//hey, look.  We ARE using GET
	//an example of 'how' to send a variable.
	//ajax.open("GET","bestreads.php?n="+n)

	ajax.send();

	// This high order anonymous function will execute when the server responds (a callback)
	ajax.onreadystatechange = function() {
		//for information purposes:
		//console.log("State: " + ajax.readyState);
		if (ajax.readyState == 4 && ajax.status == 200) {
			//This is how we turn a JSON array into a JS array.
			retStr = "";
			retStr = ajax.responseText;
			//re-write the div - make a div to put the question in <div></div> add the next button.
			retStr = '<div>--2--'+retStr+'</div>';
			console.log(retStr);
			//retStr+=getHTML_forButton();
			reWriteDiv.innerHTML = retStr;
			//getCreateNextButton();

		} else {
			//At the moment, I have no way to test this.
			//I'm assuming \n characters will function as desired and strings work like this...
			//Below does work, but it throws alerts unnecessarily atm.
			//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
		}
	}; // End anonymous high order function

}//end_function
 