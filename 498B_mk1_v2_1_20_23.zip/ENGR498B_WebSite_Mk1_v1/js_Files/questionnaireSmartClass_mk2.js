/*
* File: ManesiumQuestions.js
*
* ENGR_498B, Spring 2023
* Nathan Herling
* The University of Arizona
* init date: 12/22/2022
* -
* Attempting to make a 'smart class'
* [] load in the questionnaire as a .txt file.
* [] process the question file:
*	[] store comments
*	[] store question tree
*	[] store questions
*	[] sanity check: does the number of questions equal the size of the question tree. 
*/


//Smart class will, in design, be able to handle all the questionnaires.
//Data for the questionnaires will be stored in the text file.
export class questionnaireSmartClass_mk2 {
	//public field?
	//#retArr=[];
	#inputFileName="";
	//questionnaireContents=[];
	#storeComments = [];
	#storeQuestionTree = [];
	#storeQuestions = [];
	//We'll put the name of the file we want to read in the constructor  	
	constructor(inputFileName) {
		this.#inputFileName = inputFileName;
		this.questionnaireContents=[];
		//this.questionnaireContents = [];	//will hold the .txt file contents for the questionnaire.
		//this.storeComments = [];
		//this.storeQuestionTree = [];
		//this.storeQuestions = [];
		//My 'safest' thing to do is to open the file and read it in through php.
		
		//this.getQuestionnaireContents();			//I had to use this. to make the method call.
		//process the questionnaire
		//this.getProcessQuestionnaire();
		//*******************************
		this.toString();
		//****************************** 
	}//end_constructor


	/*
	* toString()
	* params : none
	* returns: none
	* Synopsis:
	* print out the contents of the class fields.
	* https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/forEach
	*/
	toString(){
		console.log("toString - contents");
		console.log("Input File Name:"+this.#inputFileName);
		//console.log("Questionnaire Contents:"+this.#inputFileName);
		console.log("Question Tree Contents:"+this.#storeQuestionTree);//#storeQuestions.
		console.log(this.questionnaireContents);
		
	}//end_method

	/*
	* getProcessQuestionnaire()
	* params : none
	* returns: none
	* effects class variables:
	* this.questionnaireContents = [];	
	* this.storeComments = [];
	* this.storeQuestionTree = [];
	* this.storeQuestions = [];
	* -
	* Synopsis:
	* 
	*
	*/
	getProcessQuestionnaire(){
		console.log("You are in getProcessQuestionnaire()..");
		console.log("The array in question:")
		console.log(this.questionnaireContents);
		let size = this.questionnaireContents.length;
		console.log("size->"+size);
		console.log("(1)"+this.questionnaireContents[0]);
		console.log(">>Bip>>");
		for(let i=0;i<this.questionnaireContents.length;i++){
			console.log("--Here!--");
			let letter = this.questionnaireContents[i].charAt(0);
			console.log(letter);
			switch(letter) {
				  case '#':	//The line is a comment
				    this.#storeComments.push(this.questionnaireContents[i]);
				    break;
				  case '$':	//The line is the question tree
				    this.#storeQuestionTree.push(this.questionnaireContents[i]);
				    break;
				  default:	//We'll treat this as a 'question'
				  	this.#storeQuestions.push(this.questionnaireContents[i]);
				    // code block
				}
		}//end_for_loop
	
		//do a sanity check: is size of q-tree===number of questions
		if(this.#storeQuestions.length!=this.#storeQuestionTree.length){
				let alertString="";
				alertString +="The number of questions doesn't equal the length of the question tree"+
							  "\nLocation: questionnaireSmartClass_mk1.js";
				alert(alertString);
		}//end_run_alert
		console.log("**File processing complete**");
		console.log("STATS");
		console.log("# Comments    ->:"+this.#storeComments.length);
		console.log("# Q-tree len. ->:"+this.#storeQuestionTree.length);
		console.log("# num. Quest. ->:"+this.#storeQuestions.length);
	}//end_method




	//A 'sanity check' - if needed.
	//questionnaire name.
	getQuestionName() {
		return "NA-atm";
	}//end_method

	
	/*
	*/
	getFileName(){
		return this.#inputFileName;
	}//end_method
}//end_class