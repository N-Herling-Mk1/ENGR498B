/*
* File: js_Controller_mk1.js
*
* ENGR_498B, Spring 2023
* Nathan Herling
* The University of Arizona
* init date: 12/22/2022
*
* -
* Synopsis: Controller for the questionnaire - mk1 (formerly takeTheQuiz.js)
* 
* I'm calling it a 'controller' - despite not necessarily having the 'model' component clearly defined.
* (obviously) the 'view' is the html.
* MAYBE.. I can settle on the nomemclature of: questionairre_view.x, questionnaire_model.x, questionnaire_controler.x
* I do like the js_ idea, then it would be:
* html_questionnaire_view.html ...?
*
*/


import { questionnaireSmartClass_mk2 } from '../js_Files/questionnaireSmartClass_mk2.js';

const magnesiumQ_mk2 = new questionnaireSmartClass_mk2("../txt_Files/Mg_Qs_Mk2.txt");
const inputFileName = "../txt_Files/Mg_Qs_Mk2.txt";
var anArray =[];
export function getRunJS_Controller() {
	console.log("Yo-fucking-lo");
	console.log(">>You are 'onloading' this MF'er");
	getQuestionnaireContents();
	console.log(magnesiumQ_mk2.getQuestionName());
	//getQuestionnaireContents_mk2();
	//console.log("FileName:");
	//console.log(magnesiumQ_mk2.getFileName());
}//end_function



//opens the text file that holds the questionnaire data/contents
//stores it in the field: questionnaireContents
//accomplishes this via a AJAX/php call.
/*
* getQuestionnaireContents(inputFileName)
* params : inputFileName (name of the .txt file to be opened)
* returns: Nada - but, does change value of global variable: this.questionnaireContents.
* -
* Synopsis
* opens the .txt file (which is intended to be the questionnaire)
* No format here is required for the questionnaire.
* This method could be used generically to open any text file.
* Note:
* File is opened through a AJAX/.php call.
* All class variables are 'global' to the class - no return is used.
*/
function getQuestionnaireContents() {
	let ajax = new XMLHttpRequest();
	// Send a query parameter to a PHP program
	//hey, look.  We ARE using GET, the global array.
	//Send the filename as a variable to the .php file.
	ajax.open("GET", "../php_Files/php_openTxtFileRetAsArray.php?inputFileName=" + inputFileName);
	//send the request
	ajax.send();

	let arrLocal = [];
	//this.getArray();
	// This high order anonymous function will execute when the server responds (a callback)
	ajax.onreadystatechange = function() {
		//for information purposes:
		//console.log("State: " + ajax.readyState);
		if (ajax.readyState == 4 && ajax.status == 200) {
			//This is how we turn a JSON array into a JS array.
			anArray = JSON.parse(ajax.responseText);
			console.log("Here is the current question: " + anArray);
			//console.log("Size of the array?:"+arrLocal.length);
			//console.log("First row?: "+arrLocal[0]);
			//this.questionnaireContents.push.apply(this.#questionnaireContents,arrLocal);
			//console.log(questionnaireContents);
		} else {
			//At the moment, I have no way to test this.
			//I'm assuming \n characters will function as desired and strings work like this...
			//Below does work, but it throws alerts unnecessarily atm.
			//alert("Request failed!\nState: "+ajax.readyState+"\nStatus:"+ajax.status);
		}
	};// End anonymous high order function
	//-------------- test success -----------
	//console.log("Returned Array information:");
	//console.log(typeof(retArr));

	//this.questionnaireContents.push.apply(retArr);// = retArr;
	console.log(">>>>>>>>>>>>");
	console.log(anArray);
	console.log(">>>>>>>>>>>>");
	//console.log("QuestionnaireContents_Dump:");
	//console.log(this.questionnaireContents);
	//console.log(questionnaireContents);
	//console.log(">>>>>>>>>>>>");
}//end_method

